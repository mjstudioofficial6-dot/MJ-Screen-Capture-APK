package com.mjthakur.screencapture

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class HistoryActivity : Activity() {
    private lateinit var content: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var exportButton: Button
    private lateinit var exportStatus: TextView
    private val database by lazy { CaptureDatabase(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        root.addView(TextView(this).apply {
            text = "Saved History"
            textSize = 24f
            setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "Images are numbered in saved database order. No card names or dates are shown."
            textSize = 13f
            setPadding(0, dp(4), 0, dp(8))
        })
        searchInput = EditText(this).apply {
            hint = "Search sequence or side (001, RIGHT, LEFT)"
            singleLine = true
        }
        root.addView(searchInput)
        exportButton = Button(this).apply {
            text = "Export All Images (ZIP)"
            setOnClickListener { requestExportDestination() }
        }
        root.addView(exportButton)
        exportStatus = TextView(this).apply { textSize = 12f; setTextColor(Color.DKGRAY) }
        root.addView(exportStatus)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply {
            text = "Refresh"
            setOnClickListener { renderHistory() }
        })
        root.addView(Button(this).apply {
            text = "Back"
            setOnClickListener { finish() }
        })
        setContentView(root)
        InsetsHelper.applySystemBarPadding(root)
        searchInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = renderHistory()
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })
        renderHistory()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) renderHistory()
    }

    private fun renderHistory() {
        if (!::content.isInitialized) return
        content.removeAllViews()
        val allRecords = database.getAllCaptures()
        val query = if (::searchInput.isInitialized) searchInput.text.toString().trim().uppercase() else ""
        val records = if (query.isEmpty()) allRecords else allRecords.filter { record ->
            record.sequenceNumber.toString().padStart(3, '0').contains(query) ||
                record.sequenceNumber.toString().contains(query) || record.side.uppercase().contains(query)
        }
        if (records.isEmpty()) {
            content.addView(TextView(this).apply {
                text = if (allRecords.isEmpty()) {
                    "No images saved yet. Start capture, set areas, and Calibrate Empty."
                } else {
                    "No saved images match this search."
                }
                textSize = 16f
                setPadding(0, dp(20), 0, dp(20))
            })
            return
        }
        records.chunked(3).forEach { items -> content.addView(rowForRecords(items)) }
    }

    private fun rowForRecords(records: List<CaptureRecord>): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        records.forEach { record ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(6), dp(4), dp(6))
                setBackgroundColor(0xFFF1F1F1.toInt())
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    startActivity(Intent(this@HistoryActivity, ImageDetailActivity::class.java)
                        .putExtra(ImageDetailActivity.EXTRA_CAPTURE_ID, record.id))
                }
            }
            val image = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                val bitmap = ImageUtils.decodeSampledFile(record.imagePath, dp(112), dp(128))
                if (bitmap != null) setImageBitmap(bitmap)
                else setBackgroundColor(0xFFCCCCCC.toInt())
                contentDescription = "Saved image ${record.sequenceNumber}"
            }
            tile.addView(image, LinearLayout.LayoutParams(-1, dp(128)))
            tile.addView(TextView(this).apply {
                text = "${record.sequenceNumber.toString().padStart(3, '0')} · ${record.side}"
                textSize = 12f
                setTextColor(Color.BLACK)
                gravity = Gravity.CENTER
                setPadding(0, dp(4), 0, 0)
            })
            row.addView(tile, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(3), dp(3), dp(3), dp(3))
            })
        }
        repeat(3 - records.size) {
            row.addView(LinearLayout(this), LinearLayout.LayoutParams(0, 1, 1f))
        }
        return row
    }

    private fun requestExportDestination() {
        val records = database.getAllCaptures()
        if (records.isEmpty()) {
            exportStatus.text = "There are no images to export."
            return
        }
        getSharedPreferences(CaptureConfig.APP_STATE_PREFS, MODE_PRIVATE).edit()
            .putBoolean(CaptureConfig.KEY_DETECTION_PAUSED, true).apply()
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_TITLE, "MJ_Screen_Capture_Export.zip")
        }
        startActivityForResult(intent, REQUEST_EXPORT)
    }

    @Deprecated("Export destination is selected through Android's document picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_EXPORT || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val records = database.getAllCaptures()
        exportButton.isEnabled = false
        exportStatus.text = "Exporting ${records.size} image(s)..."
        Thread({
            var exported = 0
            var failure: String? = null
            try {
                val output = applicationContext.contentResolver.openOutputStream(uri)
                    ?: throw IllegalStateException("Could not open the chosen export location")
                ZipOutputStream(output.buffered()).use { zip ->
                    val csv = buildString {
                        append("sequence,side,image_file\n")
                        records.forEach { record ->
                            val name = "${record.sequenceNumber.toString().padStart(3, '0')}_${record.side}.jpg"
                            append(record.sequenceNumber).append(',')
                                .append(record.side).append(',')
                                .append(name).append('\n')
                        }
                    }
                    zip.putNextEntry(ZipEntry("history.csv"))
                    zip.write(csv.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                    records.forEach { record ->
                        val file = File(record.imagePath)
                        if (file.isFile) {
                            val name = "images/${record.sequenceNumber.toString().padStart(3, '0')}_${record.side}.jpg"
                            zip.putNextEntry(ZipEntry(name))
                            file.inputStream().buffered().use { it.copyTo(zip) }
                            zip.closeEntry()
                            exported++
                        }
                    }
                }
            } catch (e: Exception) {
                failure = e.message ?: "Unknown export error"
            }
            runOnUiThread {
                exportButton.isEnabled = true
                exportStatus.text = if (failure == null) {
                    "Export complete: $exported image(s) plus history.csv."
                } else {
                    "Export failed: $failure"
                }
            }
        }, "MJ-HistoryExport").start()
    }

    override fun onDestroy() {
        database.close()
        super.onDestroy()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object { private const val REQUEST_EXPORT = 5201 }
}
