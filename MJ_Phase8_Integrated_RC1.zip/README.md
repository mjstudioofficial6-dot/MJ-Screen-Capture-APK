# MJ Screen Capture — Integrated Phase 8 Release Candidate 1

**Purpose:** One integrated offline Android project containing the required Phase 3–6 work and the optional manual Reference screen from Phase 7, ready for Phase 8 end-to-end testing. This is a test candidate, not a claim of a successful final build or verified detection accuracy.

## Locked successful baseline

Phase 1 was previously built by GitHub Actions, installed and opened on the target phone. Phase 2 was previously installed and tested on-device: the MediaProjection consent dialog appeared, the ongoing capture started, its frame counter increased (the user observed at least 60 and 690 frames), and Stop Capture returned to `Screen capture stopped.` Preserve these behaviours.

Technical baseline: package `com.mjthakur.screencapture`; Kotlin + XML Views; `compileSdk = 36`, `targetSdk = 36`, `minSdk = 26`; JDK 17; Android Gradle Plugin 9.4.0; Gradle 9.6.0. AGP 9 built-in Kotlin is used. Do not add `org.jetbrains.kotlin.android`.

## Project decisions / constraints

- The app’s screens apply system-bar insets so Android 15/16 edge-to-edge drawing should not place the controls underneath the status/navigation bars. This needs visual confirmation on the target phone.

- The APK itself has no Internet permission, accounts, Firebase, server, cloud AI, analytics, OCR or YOLO.
- The app only detects present/absent visual changes in the two configured rectangles. It does not read card rank, suit, name, denomination or identity.
- Captures, calibration images, reference images and the SQLite database are kept inside app-private storage. They are not automatically copied to the gallery.
- The separate video app may itself require internet to display a live stream; this APK does not make network requests.
- Only analyse frames while another app is visible. Frames showing MJ Screen Capture's own screens are ignored to avoid saving its UI as a card.
- If display dimensions, density or orientation change during capture, the capture session stops rather than trusting potentially wrong crop coordinates. Restart capture and reconfigure/calibrate if the target layout changed.

## Phase 3 — Capture Area and calibration

1. Tap Start Capture. In Android’s consent dialog, select **Entire screen** and grant permission for this full-screen workflow. A single-app capture mode is not the tested configuration.
2. Open the target video and tap **Capture Area Sample** in the ongoing MJ Screen Capture notification.
3. The service waits briefly for the notification shade to close, saves a frozen full-screen sample privately, and opens the area editor when you return to the app.
4. Draw **Right Area** and **Left Area** rectangles. Coordinates are stored normalized to frame width/height.
5. Use **Test Right** and **Test Left** to inspect each crop.
6. With both monitored areas empty in the sample, tap **Calibrate Empty**. This saves the two reference crops privately.
7. Tap **Save Areas**. If the rectangle coordinates changed later, the previous calibration is invalidated and must be done again. **Reset Areas** removes area/calibration settings.

## Phase 4 — Presence-only detector

- Compare each selected area against its calibrated empty reference using a small sampled pixel grid.
- Right and Left have independent state machines.
- A presence change must be stable for 3 analysed samples before saving one appearance.
- After a saved appearance, that area stays locked until 2 consecutive analysed samples match the empty baseline; then it can save the next appearance.
- Analysis runs every third received frame to reduce overhead. Actual timing varies with device load and source frame rate.
- If both sides become stable on the same analysed frame, Right is queued first. A Left event that stabilizes on an earlier frame is not held back for Right.
- Frames are ignored while this app's own UI is foreground or while its manual image picker is open.

The comparison threshold is an initial fixed value, not a promise of perfect detection. Moving animated backgrounds, scaling, compression, screen glare or incorrect rectangles can create missed detections or false positives; this is why Phase 8 real-video testing is required.

## Phase 5 — Automatic crop saving and SQLite

- Each stable appearance creates one crop for that appearance.
- The crop is saved to app-private `files/captured/` storage.
- SQLite stores internal ID, sequence number, side, image path and internal timestamp.
- The displayed number comes from database order, not filenames. New captures are inserted sequentially; Right is queued before Left when both stabilize on the same analysed frame.
- No date/time or card-name text is displayed in History.

## Phase 6 — History and image management

- History grid shows numbered thumbnails and `RIGHT`/`LEFT` side labels; search filters by sequence number or side.
- Tap a thumbnail for the larger image and controls: Rotate 90°, Crop, Move Earlier, Move Later, Change/Replace and Delete.
- Deleting re-compacts sequence numbers. Move changes the manual display order.
- **Export All Images (ZIP)** uses Android’s document picker to save a ZIP containing the private capture images and a `history.csv` index.
- Crop and replacement update the app-private image file.

## Phase 7 — Optional Reference library

- Contains 52 manually managed slots for A–K and the four suits.
- Tap a slot to add or replace a local image.
- This is a manual library only. The detector never compares against these slots and never performs card recognition. The screen may be omitted later without affecting automatic capture.

## Phase 8 — required manual test plan

### A. Install and baseline
- [ ] GitHub Actions build is green and APK artifact exists.
- [ ] APK installs and opens on the target Android phone.
- [ ] Start Capture shows the Android consent prompt.
- [ ] Frame count increases while any screen is shared.
- [ ] Stop Capture ends sharing and the status returns to stopped.

### B. Area setup
- [ ] Start capture and capture a sample from the notification while the target video is visible.
- [ ] Return to MJ Screen Capture; the correct target-video sample opens (not the MJ home screen).
- [ ] Draw Right and Left rectangles and visually verify Test Right/Left crops.
- [ ] Calibrate Empty with both areas empty and Save Areas.
- [ ] Close/reopen area setup and verify coordinates restore relative to a fresh sample.
- [ ] Change an area and confirm its old empty calibration is invalidated.
- [ ] Reset Areas removes selections and references.

### C. 10-round functional run
- [ ] With both empty references calibrated, leave the target video app visible and the MJ app backgrounded.
- [ ] Run 10 rounds with one expected appearance per side per round. If each round shows both cards and both disappear between rounds, expected total = 20 saved images.
- [ ] Verify every distinct appearance has one crop, no duplicate while a card remains visible, and the expected side/order.
- [ ] Verify the MJ app's own UI and image picker do not produce new captures.

### D. 50-round run
- [ ] Repeat after checking calibration and storage; record expected appearances and actual History count.
- [ ] Confirm no app crash, frozen service, repeated duplicate bursts or out-of-order DB numbering.

### E. 100-round run
- [ ] Repeat only after the 50-round run passes.
- [ ] Compare expected and actual per-side counts. Review every mismatch in History.
- [ ] Check Stop Capture while idle and while images have recently been saved.

### F. History / Reference / offline
- [ ] Open a saved thumbnail, rotate, crop, move earlier/later, replace, then delete a test record.
- [ ] Confirm database order and images stay consistent after edits/deletes.
- [ ] Export All Images (ZIP); verify the archive contains numbered image files and `history.csv`.
- [ ] Add or replace a few optional Reference slots; confirm they do not affect automatic detection.
- [ ] Confirm the APK's own capture, saving and history functions do not require its own internet connection. A live-stream provider may still require internet to play the source video.

## Acceptance rule

Do **not** mark this package successful merely because the ZIP validates. Phase 8 passes only after GitHub Actions builds it and the target phone passes the manual checks. If a test fails, capture the exact GitHub Actions error or describe the exact phone behaviour and patch only the relevant file(s). Preserve the Phase 1/2 successful baseline.
