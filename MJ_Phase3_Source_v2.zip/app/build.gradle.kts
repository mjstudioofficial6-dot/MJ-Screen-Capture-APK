plugins {
    id("com.android.application")
}

android {
    namespace = "com.mjthakur.screencapture"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.mjthakur.screencapture"
        minSdk = 26
        targetSdk = 36
        versionCode = 6
        versionName = "1.4-phase3"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
