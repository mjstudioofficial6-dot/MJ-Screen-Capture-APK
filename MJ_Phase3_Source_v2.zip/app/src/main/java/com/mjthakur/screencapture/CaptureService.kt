package com.mjthakur.screencapture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.WindowManager
import android.util.DisplayMetrics
import java.io.File
import java.io.FileOutputStream

class CaptureService : Service() {
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    private var frameCount = 0L
    private var stopped = false
    @Volatile private var sampleRequestPending = false

    private val mediaProjectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stopCapture()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startCapture(intent)
            ACTION_STOP -> stopCapture()
            ACTION_CAPTURE_SAMPLE -> requestCaptureSample()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent) {
        if (mediaProjection != null) {
            sendStatus("Screen capture is already running. Frames received: $frameCount")
            return
        }

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
        val resultData = getParcelableIntentExtra(intent, EXTRA_RESULT_DATA)
        if (resultCode != Activity.RESULT_OK || resultData == null) {
            sendStatus("Screen capture could not start: missing permission data.")
            stopSelf()
            return
        }

        stopped = false
        frameCount = 0L
        startForegroundNotification("Screen capture is running")

        try {
            val projectionManager = getSystemService(MediaProjectionManager::class.java)
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)

            val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)

            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val densityDpi = metrics.densityDpi

            captureThread = HandlerThread("MJ-CaptureThread").also { it.start() }
            captureHandler = Handler(captureThread!!.looper)
            mediaProjection!!.registerCallback(mediaProjectionCallback, captureHandler)

            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            imageReader!!.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    frameCount++
                    if (sampleRequestPending) {
                        sampleRequestPending = false
                        saveRequestedAreaSample(image)
                    }
                    if (frameCount == 1L || frameCount % 30L == 0L) {
                        sendStatus("Screen capture running. Frames received: $frameCount")
                    }
                } finally {
                    image.close()
                }
            }, captureHandler)

            virtualDisplay = mediaProjection!!.createVirtualDisplay(
                "MJ Screen Capture",
                width,
                height,
                densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader!!.surface,
                null,
                captureHandler
            )

            getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_CAPTURE_RUNNING, true)
                .apply()
            sendStatus("Screen capture running. Waiting for frames...")
        } catch (e: Exception) {
            sendStatus("Screen capture failed: ${e.message}")
            stopCapture()
        }
    }

    /** Invoked by the action on the ongoing capture notification while the target video is visible. */
    private fun requestCaptureSample() {
        if (mediaProjection == null || captureHandler == null) {
            sendStatus("Capture Area sample needs an active screen-capture session.")
            return
        }
        captureHandler?.postDelayed({
            // Allow Android to collapse the notification shade back to the target video first.
            sampleRequestPending = true
            sendStatus("Capturing the target screen frame now...")
        }, SAMPLE_CAPTURE_DELAY_MS)
    }

    private fun saveRequestedAreaSample(image: Image) {
        val capturedBitmap = imageToBitmap(image) ?: run {
            sendStatus("Area sample failed: could not convert the captured frame.")
            return
        }
        try {
            val folder = File(filesDir, "capture_area").apply { mkdirs() }
            val file = File(folder, "area_sample.jpg")
            FileOutputStream(file).use { output ->
                if (!capturedBitmap.compress(Bitmap.CompressFormat.JPEG, 95, output)) {
                    throw IllegalStateException("JPEG compression failed")
                }
            }
            getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_PENDING_SAMPLE_PATH, file.absolutePath)
                .apply()
            val broadcast = Intent(ACTION_SAMPLE_SAVED).apply {
                setPackage(packageName)
                putExtra(EXTRA_SAMPLE_PATH, file.absolutePath)
            }
            sendBroadcast(broadcast)
            sendStatus("Area sample captured. Return to MJ Screen Capture to select the areas.")
            updateForegroundNotification("Area sample captured • Return to MJ Screen Capture")
        } catch (e: Exception) {
            sendStatus("Area sample failed: ${e.message}")
        } finally {
            capturedBitmap.recycle()
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        if (pixelStride <= 0 || rowStride <= 0) return null
        val rowPadding = rowStride - pixelStride * image.width
        val bitmapWidth = image.width + (rowPadding / pixelStride)
        val fullBitmap = Bitmap.createBitmap(bitmapWidth, image.height, Bitmap.Config.ARGB_8888)
        buffer.rewind()
        fullBitmap.copyPixelsFromBuffer(buffer)
        return if (bitmapWidth == image.width) {
            fullBitmap
        } else {
            Bitmap.createBitmap(fullBitmap, 0, 0, image.width, image.height).also {
                fullBitmap.recycle()
            }
        }
    }

    private fun buildNotification(content: String): Notification {
        val sampleIntent = Intent(this, CaptureService::class.java).apply {
            action = ACTION_CAPTURE_SAMPLE
        }
        val samplePendingIntent = PendingIntent.getService(
            this,
            REQUEST_CAPTURE_SAMPLE,
            sampleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("MJ Screen Capture")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .addAction(
                Icon.createWithResource(this, android.R.drawable.ic_menu_camera),
                "Capture Area Sample",
                samplePendingIntent
            )
            .build()
    }

    private fun startForegroundNotification(content: String) {
        val notification = buildNotification(content)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateForegroundNotification(content: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(content))
    }

    private fun stopCapture() {
        if (stopped) return
        stopped = true
        sampleRequestPending = false

        virtualDisplay?.release()
        virtualDisplay = null

        imageReader?.setOnImageAvailableListener(null, null)
        imageReader?.close()
        imageReader = null

        mediaProjection?.let { projection ->
            try {
                projection.unregisterCallback(mediaProjectionCallback)
            } catch (_: Exception) {
                // Ignore cleanup errors.
            }
            try {
                projection.stop()
            } catch (_: Exception) {
                // Ignore cleanup errors.
            }
        }
        mediaProjection = null

        captureThread?.quitSafely()
        captureThread = null
        captureHandler = null
        frameCount = 0L
        getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_CAPTURE_RUNNING, false)
            .apply()
        sendStatus("Screen capture stopped.")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun sendStatus(message: String) {
        val intent = Intent(ACTION_STATUS).apply {
            setPackage(packageName)
            putExtra(EXTRA_STATUS, message)
        }
        sendBroadcast(intent)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Screen Capture",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Screen capture and area-sample controls"
        }
        manager.createNotificationChannel(channel)
    }

    @Suppress("DEPRECATION")
    private fun getParcelableIntentExtra(intent: Intent, key: String): Intent? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(key, Intent::class.java)
        } else {
            intent.getParcelableExtra(key)
        }
    }

    override fun onDestroy() {
        if (!stopped) stopCapture()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.mjthakur.screencapture.action.START"
        const val ACTION_STOP = "com.mjthakur.screencapture.action.STOP"
        const val ACTION_CAPTURE_SAMPLE = "com.mjthakur.screencapture.action.CAPTURE_SAMPLE"
        const val ACTION_STATUS = "com.mjthakur.screencapture.action.STATUS"
        const val ACTION_SAMPLE_SAVED = "com.mjthakur.screencapture.action.SAMPLE_SAVED"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_STATUS = "extra_status"
        const val EXTRA_SAMPLE_PATH = "extra_sample_path"
        const val STATE_PREFS = "capture_app_state"
        const val KEY_CAPTURE_RUNNING = "capture_running"
        const val KEY_PENDING_SAMPLE_PATH = "pending_area_sample_path"

        private const val CHANNEL_ID = "mj_screen_capture"
        private const val NOTIFICATION_ID = 1001
        private const val REQUEST_CAPTURE_SAMPLE = 1002
        private const val SAMPLE_CAPTURE_DELAY_MS = 900L
    }
}
