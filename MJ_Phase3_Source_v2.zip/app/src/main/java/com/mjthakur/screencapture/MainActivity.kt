package com.mjthakur.screencapture

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var projectionManager: MediaProjectionManager
    private var areaSetupOpening = false

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                CaptureService.ACTION_STATUS -> {
                    val message = intent.getStringExtra(CaptureService.EXTRA_STATUS) ?: return
                    statusText.text = message
                }
                CaptureService.ACTION_SAMPLE_SAVED -> {
                    statusText.text = "Area sample captured. Return here to select the areas."
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        projectionManager = getSystemService(MediaProjectionManager::class.java)
        statusText.text = "Phase 3 ready: start capture to set up monitored areas."

        findViewById<Button>(R.id.startCaptureButton).setOnClickListener {
            requestScreenCapturePermission()
        }

        findViewById<Button>(R.id.stopCaptureButton).setOnClickListener {
            stopCapture()
        }

        findViewById<Button>(R.id.captureAreaButton).setOnClickListener {
            openPendingAreaSampleIfAny()
            if (areaSetupOpening) return@setOnClickListener

            val state = getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE)
            val captureRunning = state.getBoolean(CaptureService.KEY_CAPTURE_RUNNING, false)
            if (!captureRunning) {
                Toast.makeText(this, "Start Capture first.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(
                    this,
                    "Open the target video, then tap 'Capture Area Sample' in the MJ Screen Capture notification. Return here to select the areas.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        findViewById<Button>(R.id.historyButton).setOnClickListener {
            Toast.makeText(this, "History comes in Phase 6.", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.referenceButton).setOnClickListener {
            Toast.makeText(this, "Reference is optional and is not required for area setup.", Toast.LENGTH_SHORT).show()
        }

        registerStatusReceiver()
    }

    private fun requestScreenCapturePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                REQUEST_POST_NOTIFICATIONS
            )
            return
        }
        launchScreenCaptureConsent()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_POST_NOTIFICATIONS) {
            if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(
                    this,
                    "Screen capture can still start, but Phase 3 needs app notifications enabled to capture an area sample from another app.",
                    Toast.LENGTH_LONG
                ).show()
            }
            launchScreenCaptureConsent()
        }
    }

    private fun launchScreenCaptureConsent() {
        try {
            val intent = projectionManager.createScreenCaptureIntent()
            startActivityForResult(intent, REQUEST_MEDIA_PROJECTION)
        } catch (e: Exception) {
            statusText.text = "Unable to start screen-capture permission: ${e.message}"
            Toast.makeText(this, "Screen capture permission could not be opened.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Activity Result API is not required for this phase")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_MEDIA_PROJECTION) return

        if (resultCode != RESULT_OK || data == null) {
            statusText.text = "Screen capture permission was cancelled."
            return
        }

        val serviceIntent = Intent(this, CaptureService::class.java).apply {
            action = CaptureService.ACTION_START
            putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(CaptureService.EXTRA_RESULT_DATA, data)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        statusText.text = "Starting screen capture..."
    }

    private fun stopCapture() {
        val intent = Intent(this, CaptureService::class.java).apply {
            action = CaptureService.ACTION_STOP
        }
        startService(intent)
        statusText.text = "Stopping screen capture..."
    }

    override fun onResume() {
        super.onResume()
        openPendingAreaSampleIfAny()
    }

    private fun openPendingAreaSampleIfAny() {
        if (areaSetupOpening) return
        val state = getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE)
        val path = state.getString(CaptureService.KEY_PENDING_SAMPLE_PATH, null)
        if (!path.isNullOrBlank() && File(path).isFile) {
            state.edit().remove(CaptureService.KEY_PENDING_SAMPLE_PATH).apply()
            areaSetupOpening = true
            startActivity(Intent(this, AreaSetupActivity::class.java).apply {
                putExtra(AreaSetupActivity.EXTRA_SAMPLE_PATH, path)
            })
        } else {
            if (!path.isNullOrBlank()) {
                state.edit().remove(CaptureService.KEY_PENDING_SAMPLE_PATH).apply()
            }
            areaSetupOpening = false
        }
    }

    override fun onDestroy() {
        unregisterReceiver(statusReceiver)
        super.onDestroy()
    }

    private fun registerStatusReceiver() {
        val filter = IntentFilter().apply {
            addAction(CaptureService.ACTION_STATUS)
            addAction(CaptureService.ACTION_SAMPLE_SAVED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(statusReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(statusReceiver, filter)
        }
    }

    companion object {
        private const val REQUEST_MEDIA_PROJECTION = 4101
        private const val REQUEST_POST_NOTIFICATIONS = 4102
    }
}
