package com.mjthakur.screencapture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

class AreaSelectionView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Side { RIGHT, LEFT }

    private var bitmap: Bitmap? = null
    private var activeSide = Side.RIGHT
    private var drawing = false
    private var startX = 0f
    private var startY = 0f
    private var currentX = 0f
    private var currentY = 0f
    private var rightRect: RectF? = null
    private var leftRect: RectF? = null

    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val rectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        color = Color.GREEN
    }
    private val activePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 8f
        color = Color.RED
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 34f
        style = Paint.Style.FILL
        setShadowLayer(4f, 1f, 1f, Color.BLACK)
    }

    fun setBitmap(value: Bitmap) {
        bitmap = value
        invalidate()
    }

    fun setActiveSide(side: Side) {
        activeSide = side
        invalidate()
    }

    fun setSavedRectangles(right: RectF?, left: RectF?) {
        rightRect = right?.let { RectF(it) }
        leftRect = left?.let { RectF(it) }
        invalidate()
    }

    fun getRightRect(): RectF? = rightRect?.let { RectF(it) }
    fun getLeftRect(): RectF? = leftRect?.let { RectF(it) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val source = bitmap ?: return
        val imageRect = getImageRect(source)
        canvas.drawBitmap(source, null, imageRect, imagePaint)
        drawRectangle(canvas, rightRect, activeSide == Side.RIGHT, "RIGHT")
        drawRectangle(canvas, leftRect, activeSide == Side.LEFT, "LEFT")
        if (drawing) {
            val draft = normalizedRect(startX, startY, currentX, currentY)
            canvas.drawRect(bitmapToViewRect(draft), activePaint)
        }
    }

    private fun drawRectangle(canvas: Canvas, bitmapRect: RectF?, active: Boolean, label: String) {
        if (bitmapRect == null || bitmap == null) return
        val viewRect = bitmapToViewRect(bitmapRect)
        canvas.drawRect(viewRect, if (active) activePaint else rectPaint)
        canvas.drawText(label, viewRect.left + 8f, viewRect.top + 36f, labelPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val source = bitmap ?: return false
        val imageRect = getImageRect(source)
        if (imageRect.width() <= 0f || imageRect.height() <= 0f) return false
        if (!imageRect.contains(event.x, event.y)) return true

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val point = viewToBitmapPoint(event.x, event.y, imageRect)
                startX = point.first
                startY = point.second
                currentX = startX
                currentY = startY
                drawing = true
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val point = viewToBitmapPoint(event.x, event.y, imageRect)
                currentX = point.first
                currentY = point.second
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val point = viewToBitmapPoint(event.x, event.y, imageRect)
                currentX = point.first
                currentY = point.second
                val rect = normalizedRect(startX, startY, currentX, currentY)
                drawing = false
                if (rect.width() >= 20f && rect.height() >= 20f) {
                    if (activeSide == Side.RIGHT) rightRect = rect else leftRect = rect
                }
                invalidate()
                return true
            }
        }
        return true
    }

    private fun normalizedRect(x1: Float, y1: Float, x2: Float, y2: Float): RectF {
        val source = bitmap ?: return RectF()
        return RectF(
            min(x1, x2).coerceIn(0f, source.width.toFloat()),
            min(y1, y2).coerceIn(0f, source.height.toFloat()),
            max(x1, x2).coerceIn(0f, source.width.toFloat()),
            max(y1, y2).coerceIn(0f, source.height.toFloat())
        )
    }

    private fun getImageRect(source: Bitmap): RectF {
        if (width == 0 || height == 0) return RectF()
        val scale = min(width.toFloat() / source.width, height.toFloat() / source.height)
        val drawWidth = source.width * scale
        val drawHeight = source.height * scale
        val left = (width - drawWidth) / 2f
        val top = (height - drawHeight) / 2f
        return RectF(left, top, left + drawWidth, top + drawHeight)
    }

    private fun bitmapToViewRect(rect: RectF): RectF {
        val source = bitmap ?: return RectF()
        val imageRect = getImageRect(source)
        val sx = imageRect.width() / source.width
        val sy = imageRect.height() / source.height
        return RectF(
            imageRect.left + rect.left * sx,
            imageRect.top + rect.top * sy,
            imageRect.left + rect.right * sx,
            imageRect.top + rect.bottom * sy
        )
    }

    private fun viewToBitmapPoint(x: Float, y: Float, imageRect: RectF): Pair<Float, Float> {
        val source = bitmap ?: return 0f to 0f
        val bx = ((x - imageRect.left) / imageRect.width() * source.width)
            .coerceIn(0f, source.width.toFloat())
        val by = ((y - imageRect.top) / imageRect.height() * source.height)
            .coerceIn(0f, source.height.toFloat())
        return bx to by
    }
}
