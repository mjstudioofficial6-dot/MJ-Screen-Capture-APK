# MJ Screen Capture APK — Phase 3 (Corrected v2)

## Locked baseline
Phase 1 and Phase 2 were built, installed and tested on the user's phone. Preserve the existing native Kotlin/XML project, package `com.mjthakur.screencapture`, `compileSdk 36`, `targetSdk 36`, `minSdk 26`, JDK 17, AGP 9.4.0, and Gradle 9.6.0. Do not add `org.jetbrains.kotlin.android` with AGP 9.

## Confirmed Phase 1/2 behaviour to preserve
- Native app shell and buttons.
- MediaProjection consent flow.
- Foreground media-projection service.
- `MediaProjection.Callback` registered before `createVirtualDisplay()`.
- ImageReader receives frames; on-screen frame counter updates.
- Stop Capture releases VirtualDisplay, ImageReader, MediaProjection and capture thread.
- A fresh MediaProjection consent result is required for each new session.

## Phase 3 scope
- Capture a sample from the actual screen currently showing the target live video. Do this through the **Capture Area Sample** action in the ongoing MJ Screen Capture notification while the target video is visible. This avoids accidentally using the MJ app's own home screen as the calibration sample.
- The user returns to MJ Screen Capture; the pending sample automatically opens in the area editor.
- Frozen sample editor with Set Right Area and Set Left Area.
- Drag rectangles on the sample. Store coordinates normalized to sample width/height, not absolute screen pixels.
- Test Right and Test Left preview the selected crop; these are visual previews only, not detection.
- Calibrate Empty saves the two selected crops as private app files, to be used as empty references by a later detection phase. The user must use a sample in which both areas are empty.
- Save Areas persists normalized coordinates and sample dimensions in SharedPreferences.
- Reset Areas clears coordinates and empty references.
- The app requests Android notification permission on start if needed, because Phase 3 uses an action on the capture service notification. Screen capture itself can still start if permission is denied, but the notification sample action may be unavailable until notifications are enabled.

## Not included in Phase 3
No card recognition, OCR, YOLO, AI model, automatic appearance detection, automatic crop saving, duplicate suppression, SQLite, history or cloud API. Those remain later phases.

## Manual test after build
1. Install the Phase 3 APK.
2. Tap Start Capture; allow notification permission and Android screen-capture permission.
3. Confirm the frame count increases.
4. Switch to the target video app and wait until the target screen is visible.
5. Open the notification shade and tap **Capture Area Sample** in the ongoing **MJ Screen Capture** notification. The service waits briefly for Android to close the shade, then captures the next frame.
6. After the action runs, return to MJ Screen Capture; the frozen target-video frame should open in Phase 3 area setup.
7. Set Right Area and drag a rectangle around the right-side monitored region. Set Left Area and draw the left region.
8. Use Test Right and Test Left to confirm each crop preview is correct.
9. With both regions empty in the captured sample, tap Calibrate Empty and confirm.
10. Tap Save Areas. Reopen Capture Area using a fresh sample and verify rectangles are restored in the correct relative positions.
11. Confirm Start/Stop and the frame counter still work. Stop must not crash.

Do not mark Phase 3 successful until GitHub Actions succeeds and these tests are completed on the phone. If build/test fails, inspect the exact error and patch only the necessary files.
