package com.mjthakur.screencapture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.RectF
import android.media.Image
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Present/absent comparison only. This class never recognizes ranks, suits, or denominations. */
class DetectionEngine(
    private val context: Context,
    private val onStableAppearance: (String, Bitmap) -> Unit,
    private val onMessage: (String) -> Unit
) {
    private data class AreaConfig(val normalizedRect: RectF, val emptyReference: Bitmap)
    private var rightConfig: AreaConfig? = null
    private var leftConfig: AreaConfig? = null
    private var lastConfigurationSignature: String? = null
    private var lastNotReadyMessageAt = 0L
    private val rightState = PresenceState()
    private val leftState = PresenceState()

    fun isConfiguredNow(): Boolean = CaptureConfig.isDetectionConfigured(context)

    /** Called synchronously while the ImageReader Image is open; samples only small ROI grids. */
    fun processImage(image: Image) {
        if (CaptureConfig.shouldPauseDetection(context)) return
        ensureConfiguration()
        val right = rightConfig
        val left = leftConfig
        if (right == null || left == null) {
            val now = System.currentTimeMillis()
            if (now - lastNotReadyMessageAt > 10_000L) {
                lastNotReadyMessageAt = now
                onMessage("Auto-save is waiting: set both areas and calibrate them empty.")
            }
            return
        }
        val plane = image.planes.firstOrNull() ?: return
        val buffer = plane.buffer.duplicate().apply { rewind() }
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        if (pixelStride < 3 || rowStride <= 0) return

        val rightPixels = toPixelRect(right.normalizedRect, image.width, image.height)
        val leftPixels = toPixelRect(left.normalizedRect, image.width, image.height)
        val rightPresent = differsFromEmpty(buffer, pixelStride, rowStride, rightPixels, right.emptyReference)
        val leftPresent = differsFromEmpty(buffer, pixelStride, rowStride, leftPixels, left.emptyReference)

        // Evaluating Right first guarantees Right is queued first if both become stable on this frame.
        if (rightState.observe(rightPresent)) {
            createCrop(buffer, pixelStride, rowStride, rightPixels)?.let { onStableAppearance("RIGHT", it) }
        }
        if (leftState.observe(leftPresent)) {
            createCrop(buffer, pixelStride, rowStride, leftPixels)?.let { onStableAppearance("LEFT", it) }
        }
    }

    private fun ensureConfiguration() {
        val prefs = CaptureConfig.prefs(context)
        val rightPath = prefs.getString(CaptureConfig.KEY_RIGHT_EMPTY_PATH, null)
        val leftPath = prefs.getString(CaptureConfig.KEY_LEFT_EMPTY_PATH, null)
        val signature = listOf(
            prefs.getBoolean(CaptureConfig.KEY_AREAS_SAVED, false),
            prefs.getBoolean(CaptureConfig.KEY_EMPTY_CALIBRATION_SAVED, false),
            prefs.getFloat("right_left", -1f), prefs.getFloat("right_top", -1f),
            prefs.getFloat("right_right", -1f), prefs.getFloat("right_bottom", -1f),
            prefs.getFloat("left_left", -1f), prefs.getFloat("left_top", -1f),
            prefs.getFloat("left_right", -1f), prefs.getFloat("left_bottom", -1f),
            rightPath ?: "", leftPath ?: "",
            rightPath?.let { File(it).lastModified() } ?: -1L,
            rightPath?.let { File(it).length() } ?: -1L,
            leftPath?.let { File(it).lastModified() } ?: -1L,
            leftPath?.let { File(it).length() } ?: -1L
        ).joinToString("|")
        if (signature == lastConfigurationSignature) return

        rightConfig?.emptyReference?.recycle()
        leftConfig?.emptyReference?.recycle()
        rightConfig = null
        leftConfig = null
        rightState.reset()
        leftState.reset()
        lastConfigurationSignature = signature

        if (!CaptureConfig.isDetectionConfigured(context)) return
        val rightRect = CaptureConfig.readNormalizedRect(prefs, "right") ?: return
        val leftRect = CaptureConfig.readNormalizedRect(prefs, "left") ?: return
        val rightReference = rightPath?.let { BitmapFactory.decodeFile(it) } ?: return
        val leftReference = leftPath?.let { BitmapFactory.decodeFile(it) }
        if (leftReference == null) {
            rightReference.recycle()
            return
        }
        rightConfig = AreaConfig(rightRect, rightReference)
        leftConfig = AreaConfig(leftRect, leftReference)
        onMessage("Automatic presence detection enabled. No card names or suits are read.")
    }

    private fun toPixelRect(rect: RectF, width: Int, height: Int): PixelRect {
        val left = (rect.left * width).toInt().coerceIn(0, width - 1)
        val top = (rect.top * height).toInt().coerceIn(0, height - 1)
        val right = (rect.right * width).toInt().coerceIn(left + 1, width)
        val bottom = (rect.bottom * height).toInt().coerceIn(top + 1, height)
        return PixelRect(left, top, right, bottom)
    }

    private fun differsFromEmpty(
        buffer: ByteBuffer,
        pixelStride: Int,
        rowStride: Int,
        rect: PixelRect,
        reference: Bitmap
    ): Boolean {
        val gridWidth = GRID_SIZE
        val gridHeight = GRID_SIZE
        var changed = 0
        var sumDiff = 0L
        val count = gridWidth * gridHeight
        for (gy in 0 until gridHeight) {
            val y = (rect.top + ((gy + 0.5f) * rect.height / gridHeight).toInt()).coerceIn(rect.top, rect.bottom - 1)
            val refY = (((gy + 0.5f) * reference.height / gridHeight).toInt()).coerceIn(0, reference.height - 1)
            for (gx in 0 until gridWidth) {
                val x = (rect.left + ((gx + 0.5f) * rect.width / gridWidth).toInt()).coerceIn(rect.left, rect.right - 1)
                val refX = (((gx + 0.5f) * reference.width / gridWidth).toInt()).coerceIn(0, reference.width - 1)
                val currentColor = readRgba(buffer, x, y, pixelStride, rowStride)
                val referenceColor = reference.getPixel(refX, refY)
                val diff = (
                    abs(Color.red(currentColor) - Color.red(referenceColor)) +
                        abs(Color.green(currentColor) - Color.green(referenceColor)) +
                        abs(Color.blue(currentColor) - Color.blue(referenceColor))
                    ) / 3
                sumDiff += diff
                if (diff >= PIXEL_DIFFERENCE_THRESHOLD) changed++
            }
        }
        val ratio = changed.toFloat() / count
        val mean = sumDiff.toFloat() / count
        return ratio >= CHANGED_PIXEL_RATIO_THRESHOLD && mean >= MEAN_DIFFERENCE_THRESHOLD
    }

    private fun createCrop(buffer: ByteBuffer, pixelStride: Int, rowStride: Int, rect: PixelRect): Bitmap? {
        val width = rect.width
        val height = rect.height
        if (width <= 1 || height <= 1 || width.toLong() * height.toLong() > MAX_CROP_PIXELS) return null
        val pixels = IntArray(width * height)
        for (y in 0 until height) {
            var sourceIndex = (rect.top + y) * rowStride + rect.left * pixelStride
            val destinationRow = y * width
            for (x in 0 until width) {
                val r = buffer.get(sourceIndex).toInt() and 0xFF
                val g = buffer.get(sourceIndex + 1).toInt() and 0xFF
                val b = buffer.get(sourceIndex + 2).toInt() and 0xFF
                val a = if (pixelStride >= 4) buffer.get(sourceIndex + 3).toInt() and 0xFF else 255
                pixels[destinationRow + x] = Color.argb(a, r, g, b)
                sourceIndex += pixelStride
            }
        }
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also {
            it.setPixels(pixels, 0, width, 0, 0, width, height)
        }
    }

    private fun readRgba(buffer: ByteBuffer, x: Int, y: Int, pixelStride: Int, rowStride: Int): Int {
        val index = y * rowStride + x * pixelStride
        val r = buffer.get(index).toInt() and 0xFF
        val g = buffer.get(index + 1).toInt() and 0xFF
        val b = buffer.get(index + 2).toInt() and 0xFF
        val a = if (pixelStride >= 4) buffer.get(index + 3).toInt() and 0xFF else 255
        return Color.argb(a, r, g, b)
    }

    private data class PixelRect(val left: Int, val top: Int, val right: Int, val bottom: Int) {
        val width get() = right - left
        val height get() = bottom - top
    }

    private class PresenceState {
        private var armed = true
        private var presentSamples = 0
        private var emptySamples = 0

        /** Returns true exactly once per appearance after consecutive stable samples. */
        fun observe(present: Boolean): Boolean {
            if (armed) {
                emptySamples = 0
                if (present) {
                    presentSamples++
                    if (presentSamples >= REQUIRED_STABLE_PRESENT_SAMPLES) {
                        armed = false
                        presentSamples = 0
                        emptySamples = 0
                        return true
                    }
                } else presentSamples = 0
            } else {
                presentSamples = 0
                if (present) emptySamples = 0 else {
                    emptySamples++
                    if (emptySamples >= REQUIRED_STABLE_EMPTY_SAMPLES) {
                        armed = true
                        emptySamples = 0
                    }
                }
            }
            return false
        }

        fun reset() {
            armed = true
            presentSamples = 0
            emptySamples = 0
        }
    }

    fun release() {
        rightConfig?.emptyReference?.recycle()
        leftConfig?.emptyReference?.recycle()
        rightConfig = null
        leftConfig = null
    }

    companion object {
        private const val GRID_SIZE = 48
        private const val PIXEL_DIFFERENCE_THRESHOLD = 26
        private const val CHANGED_PIXEL_RATIO_THRESHOLD = 0.16f
        private const val MEAN_DIFFERENCE_THRESHOLD = 16f
        private const val REQUIRED_STABLE_PRESENT_SAMPLES = 3
        private const val REQUIRED_STABLE_EMPTY_SAMPLES = 2
        private const val MAX_CROP_PIXELS = 12_000_000L
    }
}
