package com.mjthakur.screencapture

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

 data class CaptureRecord(
    val id: Long,
    val sequenceNumber: Int,
    val side: String,
    val imagePath: String,
    val createdAt: Long
)

class CaptureDatabase(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE captures (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "sequence_no INTEGER NOT NULL," +
                "side TEXT NOT NULL," +
                "image_path TEXT NOT NULL," +
                "created_at INTEGER NOT NULL)"
        )
        db.execSQL("CREATE INDEX idx_captures_sequence ON captures(sequence_no, id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // This is the first released data schema. Future schema changes must use additive migrations.
        if (oldVersion < 1) onCreate(db)
    }

    fun insertCapture(side: String, imagePath: String): CaptureRecord {
        val db = writableDatabase
        var created: CaptureRecord? = null
        db.beginTransaction()
        try {
            val sequence = (db.rawQuery("SELECT COALESCE(MAX(sequence_no), 0) + 1 FROM captures", null).use { c ->
                if (c.moveToFirst()) c.getInt(0) else 1
            }).coerceAtLeast(1)
            val now = System.currentTimeMillis()
            val values = ContentValues().apply {
                put("sequence_no", sequence)
                put("side", side)
                put("image_path", imagePath)
                put("created_at", now)
            }
            val id = db.insertOrThrow("captures", null, values)
            created = CaptureRecord(id, sequence, side, imagePath, now)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return created ?: throw IllegalStateException("Capture database insert failed")
    }

    fun getAllCaptures(): List<CaptureRecord> {
        val result = mutableListOf<CaptureRecord>()
        readableDatabase.query(
            "captures",
            arrayOf("id", "sequence_no", "side", "image_path", "created_at"),
            null, null, null, null,
            "sequence_no ASC, id ASC"
        ).use { cursor ->
            while (cursor.moveToNext()) result += cursorToRecord(cursor)
        }
        return result
    }

    fun getCapture(id: Long): CaptureRecord? {
        readableDatabase.query(
            "captures",
            arrayOf("id", "sequence_no", "side", "image_path", "created_at"),
            "id=?", arrayOf(id.toString()), null, null, null
        ).use { cursor ->
            return if (cursor.moveToFirst()) cursorToRecord(cursor) else null
        }
    }

    fun deleteCapture(id: Long): String? {
        val db = writableDatabase
        var imagePath: String? = null
        db.beginTransaction()
        try {
            db.query("captures", arrayOf("image_path"), "id=?", arrayOf(id.toString()), null, null, null)
                .use { c -> if (c.moveToFirst()) imagePath = c.getString(0) }
            db.delete("captures", "id=?", arrayOf(id.toString()))
            compactSequenceNumbers(db)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return imagePath
    }

    fun moveCapture(id: Long, direction: Int): Boolean {
        if (direction != -1 && direction != 1) return false
        val db = writableDatabase
        var moved = false
        db.beginTransaction()
        try {
            val ids = mutableListOf<Long>()
            db.rawQuery("SELECT id FROM captures ORDER BY sequence_no ASC, id ASC", null).use { c ->
                while (c.moveToNext()) ids += c.getLong(0)
            }
            val from = ids.indexOf(id)
            val to = from + direction
            if (from >= 0 && to in ids.indices) {
                val temp = ids[from]
                ids[from] = ids[to]
                ids[to] = temp
                ids.forEachIndexed { index, captureId ->
                    db.update(
                        "captures",
                        ContentValues().apply { put("sequence_no", -(index + 1)) },
                        "id=?", arrayOf(captureId.toString())
                    )
                }
                ids.forEachIndexed { index, captureId ->
                    db.update(
                        "captures",
                        ContentValues().apply { put("sequence_no", index + 1) },
                        "id=?", arrayOf(captureId.toString())
                    )
                }
                moved = true
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return moved
    }

    fun updateImagePath(id: Long, imagePath: String): Boolean {
        return writableDatabase.update(
            "captures",
            ContentValues().apply { put("image_path", imagePath) },
            "id=?", arrayOf(id.toString())
        ) > 0
    }

    private fun compactSequenceNumbers(db: SQLiteDatabase) {
        val ids = mutableListOf<Long>()
        db.rawQuery("SELECT id FROM captures ORDER BY sequence_no ASC, id ASC", null).use { c ->
            while (c.moveToNext()) ids += c.getLong(0)
        }
        ids.forEachIndexed { index, captureId ->
            db.update(
                "captures",
                ContentValues().apply { put("sequence_no", index + 1) },
                "id=?", arrayOf(captureId.toString())
            )
        }
    }

    private fun cursorToRecord(cursor: android.database.Cursor) = CaptureRecord(
        id = cursor.getLong(0),
        sequenceNumber = cursor.getInt(1),
        side = cursor.getString(2),
        imagePath = cursor.getString(3),
        createdAt = cursor.getLong(4)
    )

    companion object {
        private const val DATABASE_NAME = "mj_capture_history.db"
        private const val DATABASE_VERSION = 1
    }
}
