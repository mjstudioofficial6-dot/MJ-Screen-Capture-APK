package com.mjthakur.screencapture

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var projectionManager: MediaProjectionManager
    private var areaSetupOpening = false

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                CaptureService.ACTION_STATUS -> {
                    statusText.text = intent.getStringExtra(CaptureService.EXTRA_STATUS) ?: return
                }
                CaptureService.ACTION_SAMPLE_SAVED -> {
                    statusText.text = "Area sample captured. Returning to select the areas."
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        InsetsHelper.applySystemBarPadding(findViewById(R.id.mainRoot))
        statusText = findViewById(R.id.statusText)
        projectionManager = getSystemService(MediaProjectionManager::class.java)
        statusText.text = "Screen capture stopped. Start capture, then set areas and calibrate them empty."

        findViewById<Button>(R.id.startCaptureButton).setOnClickListener { requestScreenCapturePermission() }
        findViewById<Button>(R.id.stopCaptureButton).setOnClickListener { stopCapture() }
        findViewById<Button>(R.id.captureAreaButton).setOnClickListener {
            openPendingAreaSampleIfAny()
            if (areaSetupOpening) return@setOnClickListener
            if (!isCaptureRunning()) {
                Toast.makeText(this, "Start Capture first.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(
                    this,
                    "Open the target video, then tap Capture Area Sample in the MJ Screen Capture notification.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        findViewById<Button>(R.id.historyButton).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<Button>(R.id.referenceButton).setOnClickListener {
            startActivity(Intent(this, ReferenceActivity::class.java))
        }
        registerStatusReceiver()
    }

    override fun onResume() {
        super.onResume()
        areaSetupOpening = false
        if (::statusText.isInitialized && isCaptureRunning()) {
            val prefs = getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE)
            val frames = prefs.getLong(CaptureService.KEY_FRAME_COUNT, 0L)
            statusText.text = "Screen capture running. Frames received: $frames"
        }
        openPendingAreaSampleIfAny()
    }

    private fun requestScreenCapturePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_POST_NOTIFICATIONS)
            return
        }
        launchScreenCaptureConsent()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_POST_NOTIFICATIONS) {
            if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(
                    this,
                    "Enable notifications to use Capture Area Sample from another app.",
                    Toast.LENGTH_LONG
                ).show()
            }
            launchScreenCaptureConsent()
        }
    }

    private fun launchScreenCaptureConsent() {
        try {
            startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_MEDIA_PROJECTION)
        } catch (e: Exception) {
            statusText.text = "Unable to start screen capture: ${e.message ?: "unknown error"}"
            Toast.makeText(this, "Screen capture permission could not be opened.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("MediaProjection consent returns through this compatibility callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_MEDIA_PROJECTION) return
        if (resultCode != RESULT_OK || data == null) {
            statusText.text = "Screen capture permission was cancelled."
            return
        }
        val serviceIntent = Intent(this, CaptureService::class.java).apply {
            action = CaptureService.ACTION_START
            putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(CaptureService.EXTRA_RESULT_DATA, data)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
        statusText.text = "Starting screen capture..."
    }

    private fun stopCapture() {
        val intent = Intent(this, CaptureService::class.java).apply { action = CaptureService.ACTION_STOP }
        try {
            startService(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not stop capture: ${e.message}", Toast.LENGTH_LONG).show()
        }
        statusText.text = "Stopping screen capture..."
    }

    private fun isCaptureRunning(): Boolean = getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE)
        .getBoolean(CaptureService.KEY_CAPTURE_RUNNING, false)

    private fun openPendingAreaSampleIfAny() {
        if (areaSetupOpening) return
        val state = getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE)
        val path = state.getString(CaptureService.KEY_PENDING_SAMPLE_PATH, null)
        if (!path.isNullOrBlank() && File(path).isFile) {
            state.edit().remove(CaptureService.KEY_PENDING_SAMPLE_PATH).apply()
            areaSetupOpening = true
            startActivity(Intent(this, AreaSetupActivity::class.java).putExtra(AreaSetupActivity.EXTRA_SAMPLE_PATH, path))
        } else if (!path.isNullOrBlank()) {
            state.edit().remove(CaptureService.KEY_PENDING_SAMPLE_PATH).apply()
        }
    }

    private fun registerStatusReceiver() {
        val filter = IntentFilter().apply {
            addAction(CaptureService.ACTION_STATUS)
            addAction(CaptureService.ACTION_SAMPLE_SAVED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) registerReceiver(statusReceiver, filter, RECEIVER_NOT_EXPORTED)
        else {
            @Suppress("DEPRECATION")
            registerReceiver(statusReceiver, filter)
        }
    }

    override fun onDestroy() {
        unregisterReceiver(statusReceiver)
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_MEDIA_PROJECTION = 4101
        private const val REQUEST_POST_NOTIFICATIONS = 4102
    }
}
