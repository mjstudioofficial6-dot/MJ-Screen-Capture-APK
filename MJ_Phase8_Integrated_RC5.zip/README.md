# MJ Screen Capture — Integrated Phase 8 RC5

RC5 is an integrated offline Android test candidate. Phase 1 and Phase 2 remain locked successful baselines. This source ZIP has passed archive, XML, workflow and static source checks only; GitHub Actions must compile the APK and the installed app must pass phone tests before RC5 can be called successful.

## RC5 changes for the reported problems

1. **Two-screenshot workflow from the notification.** Tap **Capture Area Sample** for the screenshot used to draw the two rectangles. The notification then switches to **Capture Empty Sample**. Wait until no card is visible in either target region before taking that second screenshot. Return to the app and tap **CAPTURE AREA**; select both areas once on the first screenshot. RC5 applies those same normalized rectangles to the second screenshot, shows the two empty-crop previews, and saves both areas plus the separate empty baseline together.
2. **Area screenshot and empty baseline are no longer confused.** The first screenshot is for drawing regions only and is never accepted as the empty baseline through the area editor. The second screenshot is the only one used for the empty baseline. The editor previews the crops from that second screenshot; if either preview contains a card, cancel and capture the second screenshot again when both regions are blank.
3. **Brightness/contrast compensation.** The presence detector estimates a restrained per-channel exposure adjustment before comparing live pixels with the empty crop. Uniform screen brightness flashes should therefore create much less residual difference.
4. **Stronger debounce and a three-state detector.** A card must remain changed for 6 analyzed samples to trigger. After a save, the region must match the empty baseline confidently for 12 analyzed samples before it can trigger again. Frames between the strict empty and changed thresholds are classified as **uncertain**, not empty, so a brightness blink cannot re-arm a region just because it briefly looks different. This reduces duplicates; it cannot guarantee every animated graphic is rejected, so rectangles must tightly cover the card itself rather than score labels, betting indicators or decorations.
5. **Old baseline safety gate.** RC5 requires empty-calibration version 2. An empty reference saved by RC4 is treated as unverified, so automatic capture stays disabled until a new baseline is saved. This prevents the card-filled baseline shown in the user's sample preview from being silently reused.
6. **Physical side labels in the setup screen.** **RIGHT** means the physical screen-right card area (Tiger); **LEFT** means the physical screen-left card area (Dragon). The Right/Left test previews should confirm this before saving. If the preview labels are reversed, redraw the rectangles.

## Notification workflow

- Start Screen Capture and grant the OS screen-sharing permission.
- Expand the ongoing MJ notification.
- Tap **Capture Area Sample** while the game is visible; after it saves, the notification action changes to **Capture Empty Sample**.
- Wait for both card positions to have no card visible, then tap **Capture Empty Sample**. Frame counting can continue; detection remains paused.
- Return to MJ Screen Capture and tap **CAPTURE AREA**. Draw the physical screen-right area under **Set Right Area** and screen-left area under **Set Left Area**. Tap the save button and inspect both crops from the second screenshot. Confirm only if neither crop contains a card.
- The app saves the two selected rectangles and the baseline crops from the separate empty screenshot. Then tap **Start Auto Capture** in the notification.

If only one screenshot is waiting, the app can still save the rectangles only. The user must then use Settings to capture a no-card sample before Auto Capture can start. Area and empty samples never appear in History.

## Detection design

- Native Android, Kotlin + XML Views, MediaProjection + VirtualDisplay + ImageReader, SQLite history.
- No OCR, YOLO, card rank/suit recognition or denomination recognition.
- Only pixels inside the two normalized rectangles are compared. Detection applies exposure compensation, a minimum changed-pixel ratio and mean residual threshold, then a per-side presence state machine.
- An accepted appearance saves one ROI crop to app-private storage. It remains locked while that area stays present. It re-arms only after sustained empty results. Right is processed before Left if both trigger on the same analyzed sample.
- Screen frame count and image-save count are different: the frame counter increments for each received screen frame whether or not an image is saved.

## Android/build baseline

- Package: `com.mjthakur.screencapture`
- `compileSdk = 36`, `targetSdk = 36`, `minSdk = 26`, JDK 17, AGP 9.4.0, Gradle 9.6.0.
- AGP 9 built-in Kotlin support; do not add `org.jetbrains.kotlin.android`.
- No `INTERNET` permission, Firebase, login, server, cloud AI, OCR or YOLO. Runtime is offline.
- Samples, empty references, history database and saved crops stay in app-private storage.

## RC5 acceptance checks

1. GitHub Actions passes `:app:assembleDebug` and uploads the RC5 APK artifact.
2. Install over RC4 (do not uninstall, so History stays); the old empty baseline is marked not ready until recalibrated.
3. Capture the two screenshots through the same notification in the order Area then Empty. Confirm the notification action advances after the first screenshot.
4. In Area Setup, verify the physical Right preview is the game screen's right/Tiger position and the physical Left preview is the left/Dragon position.
5. Confirm the two crops shown from the second screenshot contain no card. After saving, Auto Capture must become ready.
6. Leave a card visible for several seconds: only one crop should be saved for that appearance. A brightness blink with no card movement must not create a new History item. When the card disappears for long enough and a new card appears, one new crop should be saved.
7. Run 10 rounds first. Compare expected vs actual saves and check for duplicate, blank-background, missed or reversed-side crops before attempting 50 or 100 rounds.
8. Verify Pause Auto Capture stops new saves while frame counting continues; Stop Capture ends the session and removes the notification.

## Acceptance rule

Static checks are not proof of a successful APK. RC5 is successful only after GitHub Actions builds it and the user confirms behavior on the target phone. If Kotlin compilation fails, use the first `e:` compiler line rather than guessing. If runtime behavior fails, diagnose the actual crop preview and detection status; do not silently rewrite unrelated phases.
