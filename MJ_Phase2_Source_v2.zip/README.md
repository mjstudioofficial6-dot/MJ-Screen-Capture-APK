# MJ Screen Capture APK — Phase 2

## Baseline
Phase 1 was completed and tested: the APK built, installed and launched on the target Android phone. Phase 2 keeps that baseline and adds only the actual screen-capture pipeline.

## Phase 2 Goal
Verify a real MediaProjection session from the phone screen:

START CAPTURE → Android consent → foreground service → MediaProjection → VirtualDisplay → ImageReader → receive frames → STOP CAPTURE → clean shutdown.

## Included
- MediaProjection permission flow
- Foreground service with `mediaProjection` type
- VirtualDisplay
- ImageReader frame reception
- Frame counter/status
- MediaProjection stop callback
- Proper VirtualDisplay/ImageReader/thread/service cleanup
- Fresh consent for each capture session

## Not included yet
- Automatic card detection
- Right/Left area detection
- Automatic screenshot/crop saving
- Duplicate suppression
- Calibration
- SQLite/history
- OCR
- YOLO
- Card-name/suit recognition
- Cloud AI/API

## Final Product Requirement Preserved
The final APK will automatically capture one crop when a card appears in a monitored fixed Right/Left area, avoid duplicates while it remains visible, re-arm after the area becomes empty, and save in actual appearance order. Card identity will not be recognized.

## Phase 2 Success Test
1. Install APK.
2. Tap START CAPTURE.
3. Grant Android screen-capture permission.
4. Confirm status changes to capture running and frame count increases.
5. Tap STOP CAPTURE.
6. Confirm capture stops without a crash.
7. Start a second capture session and confirm Android asks for consent again and frames are received.

Do not start Phase 3 until all Phase 2 tests pass on the target phone.
