package com.mjthakur.screencapture

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var projectionManager: MediaProjectionManager

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != CaptureService.ACTION_STATUS) return
            val message = intent.getStringExtra(CaptureService.EXTRA_STATUS) ?: return
            statusText.text = message
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        projectionManager = getSystemService(MediaProjectionManager::class.java)
        statusText.text = "Phase 2 ready: screen capture is not running."

        findViewById<Button>(R.id.startCaptureButton).setOnClickListener {
            requestScreenCapturePermission()
        }

        findViewById<Button>(R.id.stopCaptureButton).setOnClickListener {
            stopCapture()
        }

        findViewById<Button>(R.id.captureAreaButton).setOnClickListener {
            Toast.makeText(this, "Capture Area comes in Phase 3.", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.historyButton).setOnClickListener {
            Toast.makeText(this, "History comes in Phase 6.", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.referenceButton).setOnClickListener {
            Toast.makeText(this, "Reference is optional and is not part of Phase 2.", Toast.LENGTH_SHORT).show()
        }

        registerStatusReceiver()
    }

    private fun requestScreenCapturePermission() {
        try {
            val intent = projectionManager.createScreenCaptureIntent()
            startActivityForResult(intent, REQUEST_MEDIA_PROJECTION)
        } catch (e: Exception) {
            statusText.text = "Unable to start screen-capture permission: ${e.message}"
            Toast.makeText(this, "Screen capture permission could not be opened.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Activity Result API is not required for this phase")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_MEDIA_PROJECTION) return

        if (resultCode != RESULT_OK || data == null) {
            statusText.text = "Screen capture permission was cancelled."
            return
        }

        val serviceIntent = Intent(this, CaptureService::class.java).apply {
            action = CaptureService.ACTION_START
            putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(CaptureService.EXTRA_RESULT_DATA, data)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        statusText.text = "Starting screen capture..."
    }

    private fun stopCapture() {
        val intent = Intent(this, CaptureService::class.java).apply {
            action = CaptureService.ACTION_STOP
        }
        startService(intent)
        statusText.text = "Stopping screen capture..."
    }

    private fun registerStatusReceiver() {
        val filter = IntentFilter(CaptureService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(statusReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(statusReceiver, filter)
        }
    }

    override fun onDestroy() {
        unregisterReceiver(statusReceiver)
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_MEDIA_PROJECTION = 4101
    }
}
