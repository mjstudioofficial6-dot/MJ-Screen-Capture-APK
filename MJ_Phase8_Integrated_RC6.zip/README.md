# MJ Screen Capture APK — Phase 8 RC6

## Project status

RC6 adds session folders (Decks), folder management, a per-Deck 400-image cap, and a compact 10-column thumbnail grid. RC6 is a **candidate build**, not a confirmed release. Its static checks must pass, GitHub Actions must build the APK, and the user must install and exercise the new folder controls on the phone before the new functionality is considered verified.

The previously user-tested RC5 detection behavior is the known-good baseline: the user confirmed that card changes save card crops and brightness blinking / unrelated visual changes do not produce duplicate saves. RC6 intentionally does not change `DetectionEngine.kt` or its detection thresholds/state machine. Preserve that behavior and do not change the detector without a reproduced bug.

## Required behavior — Deck folders

- Every new **Screen Capture** session creates a new Deck by default: `Deck 1`, `Deck 2`, `Deck 3`, etc. This is a logical folder shown in the app and a matching private storage directory.
- All accepted image crops from that screen-capture session are saved inside that Deck's private folder. Samples and empty-baseline screenshots are never inserted into a Deck's image History.
- **Pause Auto Capture** pauses detection/saving but keeps the current Deck session. **Resume Auto Capture** continues saving into the same Deck.
- **Stop Capture** closes the current session. A future Screen Capture start creates a new Deck by default.
- The user may choose **Use Next** for an existing Deck. The next Screen Capture start will append saved crops to that Deck instead of creating a new one. The chosen Deck must have fewer than 400 images.
- Each Deck may contain at most **400 images**. When it reaches 400/400, Auto Capture automatically pauses and reports why. It must not save image 401 into that Deck.
- Every Deck has its own database sequence, starting at `001`. Deleting, moving, or reordering an image only affects sequence numbers inside its own Deck.
- The Deck list must allow Open, Rename, Delete, and Use Next. Renaming is a display/folder label operation; names must be unique. If Deck 1 was deleted, the user can rename Deck 2 to Deck 1. Do not silently rename other Decks.
- Deleting a Deck requires confirmation and permanently deletes that Deck's database records and image files. Do not allow deleting the currently active Deck. If it was selected as the next Deck, clear that selection.
- There must be a control to choose a fresh Deck for the next session rather than reusing a selected one.
- Export All creates a ZIP arranged in per-Deck directories and includes a CSV index. Export This Deck exports only the open Deck.
- Existing RC5 captures must remain available after the database migration and appear under `Previous captures`.

## Compact History grid

- Opening History shows Deck folders. Opening a Deck shows that Deck's thumbnails.
- Use **10 small thumbnails per horizontal row** on the phone, labelled with sequence and side (`001 L` / `001 R`). This is intentionally a compact preview; tapping any thumbnail opens the full image/detail view.
- Search by sequence or side within the selected Deck.
- Preserve existing image detail, crop, rotate, delete, move, replace, and export behavior unless a specific regression is reproduced.

## Screen positions and capture logic

- `LEFT` is the physical left side of the screen / Dragon region.
- `RIGHT` is the physical right side of the screen / Tiger region.
- Detect presence/absence only. Do not identify rank, suit, card name, or denomination.
- Preserve the known-good detection state machine, stability checks, brightness compensation, empty-frame re-arming, Right priority when both qualify simultaneously, and actual accepted-capture order.
- One appearance must save one crop. Brightness blinking or unrelated visual changes must not create additional captures. Change detection logic only after observing a reproducible failure on the phone.

## Calibration samples

Two different private samples are used:

1. **Area Selection Sample** — full-screen frozen frame used to draw the two rectangles only. It is not an empty baseline and never appears in History.
2. **Empty Background Sample** — a separate full-screen frame captured when both monitored regions visibly contain no card. Apply the same selected rectangles to this frame and show both crop previews. The user must confirm that both crops are empty before saving them as baselines.

The app does not recognize card rank/suit, so it cannot claim to automatically prove a sample contains no card. A user-confirmed empty baseline is required. Coordinate transforms, crop edges, and physical LEFT/RIGHT mapping must be verified.

## Runtime and technical constraints

- Native Android, Kotlin, XML Views, MediaProjection, VirtualDisplay, ImageReader, Bitmap/crop processing, a foreground screen-capture service, background image processing, SQLiteOpenHelper, app-private storage.
- Runtime is 100% offline. No `INTERNET` permission, Firebase, account/login, external server, cloud AI/API, OCR, YOLO, or automatic card-name/suit recognition.
- Do not bypass Android protected-content/security restrictions.
- `compileSdk = 36`, `targetSdk = 36`, `minSdk = 26`, JDK 17, AGP 9.4.0, Gradle 9.6.0.
- AGP 9 built-in Kotlin support: do not add `org.jetbrains.kotlin.android`.
- The database upgrade from schema v1 to v2 must be additive and preserve existing capture records.

## Build rules

When GitHub Actions fails:

1. Locate the exact failed step.
2. Read the first actual compiler/tool error (`e:`, `error:`), not only the final stack trace.
3. Identify the root cause and exact file/path.
4. Change only the required files; do not randomly rewrite unrelated source or the working detection engine.
5. Run static checks and the build again. Do not claim success until GitHub Actions finishes green.
6. Install the APK on the target phone and verify runtime behavior. A green build is not proof of correct app behavior.
7. Ensure the active workflow references the exact RC6 source ZIP, and keep old conflicting workflows from accidentally building stale source.
8. Before a risky change, preserve the last known-good source ZIP and workflow.

## RC6 test checklist

1. GitHub Actions static checks pass, `:app:assembleDebug` succeeds, APK artifact downloads, and app updates/installs without a crash.
2. Existing RC5 history remains after install; it is visible as `Previous captures`.
3. Start Screen Capture: a new Deck is created by default and shown under History.
4. Start Auto Capture and save sample cards; crops are saved within the active Deck with sequence `001`, `002`, etc.
5. Pause Auto Capture; no new images are saved, and resumed saving remains in the same Deck.
6. Stop Capture, then start Screen Capture again; a new Deck is created by default.
7. Choose Use Next on a non-full existing Deck, stop, then start again; new crops append to that selected Deck.
8. Rename a Deck; the list updates and duplicate names are rejected. Delete a non-active Deck and confirm all its images disappear. An active Deck cannot be deleted.
9. At 400 saved images in one Deck, Auto Capture pauses and a 401st image is not inserted.
10. In a Deck's History, 10 compact thumbnails appear per row; tapping one opens its full detail. Search works for sequence and side.
11. Export This Deck produces only that Deck; Export All preserves per-Deck directory grouping in the ZIP.
12. Re-run a small card-change/brightness-blink test to confirm the known-good RC5 detection behavior remains unchanged.
13. Keep testing in 10, then 50 and 100 rounds as practical. Record actual results; do not label untested items complete.

## Requirement protection

This README is the implementation baseline. Do not silently add unrelated features, unnecessary permissions/services, networking, analytics, or recognition capabilities. Any material requirement change must be discussed explicitly before implementation.
