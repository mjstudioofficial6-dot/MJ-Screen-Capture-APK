plugins {
    id("com.android.application")
}

android {
    namespace = "com.mjthakur.screencapture"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.mjthakur.screencapture"
        minSdk = 26
        targetSdk = 36
        versionCode = 13
        versionName = "1.9-phase8-rc6"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
