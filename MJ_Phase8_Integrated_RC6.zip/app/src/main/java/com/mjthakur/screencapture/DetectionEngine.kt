package com.mjthakur.screencapture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.RectF
import android.media.Image
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.abs

/** Presence/absence only. No card rank, suit, or denomination recognition is performed. */
class DetectionEngine(
    private val context: Context,
    private val onStableAppearance: (String, Bitmap) -> Unit,
    private val onMessage: (String) -> Unit
) {
    private data class AreaConfig(val normalizedRect: RectF, val emptyReference: Bitmap)
    private var rightConfig: AreaConfig? = null
    private var leftConfig: AreaConfig? = null
    private var lastConfigurationSignature: String? = null
    private var lastNotReadyMessageAt = 0L
    private var lastDiagnosticMessageAt = 0L
    private val rightState = PresenceState()
    private val leftState = PresenceState()

    fun isConfiguredNow(): Boolean = CaptureConfig.isDetectionConfigured(context)

    /** Called while the ImageReader image is open; only selected area pixels are sampled. */
    fun processImage(image: Image) {
        if (CaptureConfig.shouldPauseDetection(context)) return
        ensureConfiguration()
        val right = rightConfig
        val left = leftConfig
        if (right == null || left == null) {
            val now = System.currentTimeMillis()
            if (now - lastNotReadyMessageAt > 10_000L) {
                lastNotReadyMessageAt = now
                onMessage("Auto-save is waiting: set both areas and save a separate, verified no-card empty sample.")
            }
            return
        }
        val plane = image.planes.firstOrNull() ?: return
        val buffer = plane.buffer.duplicate().apply { rewind() }
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        if (pixelStride < 3 || rowStride <= 0) return

        val rightPixels = toPixelRect(right.normalizedRect, image.width, image.height)
        val leftPixels = toPixelRect(left.normalizedRect, image.width, image.height)
        val rightResult = compareWithEmpty(buffer, pixelStride, rowStride, rightPixels, right.emptyReference)
        val leftResult = compareWithEmpty(buffer, pixelStride, rowStride, leftPixels, left.emptyReference)

        val now = System.currentTimeMillis()
        if (now - lastDiagnosticMessageAt >= DIAGNOSTIC_INTERVAL_MS) {
            lastDiagnosticMessageAt = now
            onMessage(
                "Brightness-compensated monitoring (change ≥22%, residual mean ≥20) • RIGHT ${formatResult(rightResult)} • LEFT ${formatResult(leftResult)}"
            )
        }

        // Right is evaluated first; simultaneous stable appearances are queued Right then Left.
        if (rightState.observe(rightResult.isPresent, rightResult.isClearlyEmpty)) {
            createCrop(buffer, pixelStride, rowStride, rightPixels)?.let { onStableAppearance("RIGHT", it) }
        }
        if (leftState.observe(leftResult.isPresent, leftResult.isClearlyEmpty)) {
            createCrop(buffer, pixelStride, rowStride, leftPixels)?.let { onStableAppearance("LEFT", it) }
        }
    }

    private fun ensureConfiguration() {
        val prefs = CaptureConfig.prefs(context)
        val rightPath = prefs.getString(CaptureConfig.KEY_RIGHT_EMPTY_PATH, null)
        val leftPath = prefs.getString(CaptureConfig.KEY_LEFT_EMPTY_PATH, null)
        val signature = listOf(
            prefs.getBoolean(CaptureConfig.KEY_AREAS_SAVED, false),
            prefs.getBoolean(CaptureConfig.KEY_EMPTY_CALIBRATION_SAVED, false),
            prefs.getInt(CaptureConfig.KEY_EMPTY_CALIBRATION_VERSION, 0),
            prefs.getFloat("right_left", -1f), prefs.getFloat("right_top", -1f),
            prefs.getFloat("right_right", -1f), prefs.getFloat("right_bottom", -1f),
            prefs.getFloat("left_left", -1f), prefs.getFloat("left_top", -1f),
            prefs.getFloat("left_right", -1f), prefs.getFloat("left_bottom", -1f),
            rightPath ?: "", leftPath ?: "",
            rightPath?.let { File(it).lastModified() } ?: -1L,
            rightPath?.let { File(it).length() } ?: -1L,
            leftPath?.let { File(it).lastModified() } ?: -1L,
            leftPath?.let { File(it).length() } ?: -1L
        ).joinToString("|")
        if (signature == lastConfigurationSignature) return

        rightConfig?.emptyReference?.recycle()
        leftConfig?.emptyReference?.recycle()
        rightConfig = null
        leftConfig = null
        rightState.reset()
        leftState.reset()
        lastConfigurationSignature = signature

        if (!CaptureConfig.isDetectionConfigured(context)) return
        val rightRect = CaptureConfig.readNormalizedRect(prefs, "right") ?: return
        val leftRect = CaptureConfig.readNormalizedRect(prefs, "left") ?: return
        val rightReference = rightPath?.let { BitmapFactory.decodeFile(it) } ?: return
        val leftReference = leftPath?.let { BitmapFactory.decodeFile(it) }
        if (leftReference == null) {
            rightReference.recycle()
            return
        }
        rightConfig = AreaConfig(rightRect, rightReference)
        leftConfig = AreaConfig(leftRect, leftReference)
        onMessage("Presence detection ready. Empty baseline version ${CaptureConfig.CURRENT_EMPTY_CALIBRATION_VERSION}; brightness shifts are normalized.")
    }

    private fun toPixelRect(rect: RectF, width: Int, height: Int): PixelRect {
        val left = (rect.left * width).toInt().coerceIn(0, width - 1)
        val top = (rect.top * height).toInt().coerceIn(0, height - 1)
        val right = (rect.right * width).toInt().coerceIn(left + 1, width)
        val bottom = (rect.bottom * height).toInt().coerceIn(top + 1, height)
        return PixelRect(left, top, right, bottom)
    }

    private data class DifferenceResult(
        val isPresent: Boolean,
        val isClearlyEmpty: Boolean,
        val changedRatio: Float,
        val residualMean: Float
    )

    /**
     * Fits a small per-channel brightness/contrast adjustment between the live ROI and
     * the saved empty ROI. A whole-area brightness pulse therefore largely cancels out,
     * while local shapes/edges introduced by a new object remain different.
     */
    private fun compareWithEmpty(
        buffer: ByteBuffer,
        pixelStride: Int,
        rowStride: Int,
        rect: PixelRect,
        reference: Bitmap
    ): DifferenceResult {
        val gridWidth = GRID_SIZE
        val gridHeight = GRID_SIZE
        val count = gridWidth * gridHeight
        val currentR = IntArray(count)
        val currentG = IntArray(count)
        val currentB = IntArray(count)
        val referenceR = IntArray(count)
        val referenceG = IntArray(count)
        val referenceB = IntArray(count)
        var index = 0

        for (gy in 0 until gridHeight) {
            val y = (rect.top + ((gy + 0.5f) * rect.height / gridHeight).toInt())
                .coerceIn(rect.top, rect.bottom - 1)
            val refY = (((gy + 0.5f) * reference.height / gridHeight).toInt())
                .coerceIn(0, reference.height - 1)
            for (gx in 0 until gridWidth) {
                val x = (rect.left + ((gx + 0.5f) * rect.width / gridWidth).toInt())
                    .coerceIn(rect.left, rect.right - 1)
                val refX = (((gx + 0.5f) * reference.width / gridWidth).toInt())
                    .coerceIn(0, reference.width - 1)
                val current = readRgba(buffer, x, y, pixelStride, rowStride)
                val base = reference.getPixel(refX, refY)
                currentR[index] = Color.red(current)
                currentG[index] = Color.green(current)
                currentB[index] = Color.blue(current)
                referenceR[index] = Color.red(base)
                referenceG[index] = Color.green(base)
                referenceB[index] = Color.blue(base)
                index++
            }
        }

        val redFit = fitExposure(referenceR, currentR)
        val greenFit = fitExposure(referenceG, currentG)
        val blueFit = fitExposure(referenceB, currentB)
        var changed = 0
        var residualSum = 0L
        for (i in 0 until count) {
            val normalizedR = ((currentR[i] - redFit.offset) / redFit.gain).toInt().coerceIn(0, 255)
            val normalizedG = ((currentG[i] - greenFit.offset) / greenFit.gain).toInt().coerceIn(0, 255)
            val normalizedB = ((currentB[i] - blueFit.offset) / blueFit.gain).toInt().coerceIn(0, 255)
            val residual = (abs(normalizedR - referenceR[i]) +
                abs(normalizedG - referenceG[i]) +
                abs(normalizedB - referenceB[i])) / 3
            residualSum += residual
            if (residual >= NORMALIZED_PIXEL_DIFFERENCE_THRESHOLD) changed++
        }
        val ratio = changed.toFloat() / count
        val mean = residualSum.toFloat() / count
        return DifferenceResult(
            isPresent = ratio >= CHANGED_PIXEL_RATIO_THRESHOLD && mean >= MEAN_DIFFERENCE_THRESHOLD,
            // Only a confident match to the empty baseline may re-arm a saved ROI.
            // Ambiguous/animated frames stay LOCKED and cannot generate duplicates.
            isClearlyEmpty = ratio <= EMPTY_CHANGED_PIXEL_RATIO_THRESHOLD &&
                mean <= EMPTY_MEAN_DIFFERENCE_THRESHOLD,
            changedRatio = ratio,
            residualMean = mean
        )
    }

    private data class ExposureFit(val gain: Float, val offset: Float)

    /** current ≈ gain * reference + offset; reject extreme fits caused by genuine content changes. */
    private fun fitExposure(reference: IntArray, current: IntArray): ExposureFit {
        var meanReference = 0.0
        var meanCurrent = 0.0
        for (i in reference.indices) {
            meanReference += reference[i]
            meanCurrent += current[i]
        }
        meanReference /= reference.size
        meanCurrent /= current.size
        var covariance = 0.0
        var variance = 0.0
        for (i in reference.indices) {
            val dr = reference[i] - meanReference
            covariance += dr * (current[i] - meanCurrent)
            variance += dr * dr
        }
        val rawGain = if (variance > 100.0) (covariance / variance).toFloat() else 1f
        val gain = if (rawGain in MIN_EXPOSURE_GAIN..MAX_EXPOSURE_GAIN) rawGain else 1f
        val offset = if (gain == 1f && rawGain !in MIN_EXPOSURE_GAIN..MAX_EXPOSURE_GAIN) {
            // Pure additive fallback for scenes whose content changed too much for a safe fit.
            (meanCurrent - meanReference).toFloat()
        } else {
            (meanCurrent - gain * meanReference).toFloat()
        }
        return ExposureFit(gain.coerceAtLeast(MIN_SAFE_GAIN), offset)
    }

    private fun formatResult(result: DifferenceResult): String {
        val state = when {
            result.isPresent -> "CARD"
            result.isClearlyEmpty -> "empty"
            else -> "uncertain"
        }
        return "$state ${((result.changedRatio * 100f).toInt())}%/${result.residualMean.toInt()}"
    }

    private fun createCrop(buffer: ByteBuffer, pixelStride: Int, rowStride: Int, rect: PixelRect): Bitmap? {
        val width = rect.width
        val height = rect.height
        if (width <= 1 || height <= 1 || width.toLong() * height.toLong() > MAX_CROP_PIXELS) return null
        val pixels = IntArray(width * height)
        for (y in 0 until height) {
            var sourceIndex = (rect.top + y) * rowStride + rect.left * pixelStride
            val destinationRow = y * width
            for (x in 0 until width) {
                val r = buffer.get(sourceIndex).toInt() and 0xFF
                val g = buffer.get(sourceIndex + 1).toInt() and 0xFF
                val b = buffer.get(sourceIndex + 2).toInt() and 0xFF
                val a = if (pixelStride >= 4) buffer.get(sourceIndex + 3).toInt() and 0xFF else 255
                pixels[destinationRow + x] = Color.argb(a, r, g, b)
                sourceIndex += pixelStride
            }
        }
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also {
            it.setPixels(pixels, 0, width, 0, 0, width, height)
        }
    }

    private fun readRgba(buffer: ByteBuffer, x: Int, y: Int, pixelStride: Int, rowStride: Int): Int {
        val index = y * rowStride + x * pixelStride
        val r = buffer.get(index).toInt() and 0xFF
        val g = buffer.get(index + 1).toInt() and 0xFF
        val b = buffer.get(index + 2).toInt() and 0xFF
        val a = if (pixelStride >= 4) buffer.get(index + 3).toInt() and 0xFF else 255
        return Color.argb(a, r, g, b)
    }

    private data class PixelRect(val left: Int, val top: Int, val right: Int, val bottom: Int) {
        val width get() = right - left
        val height get() = bottom - top
    }

    private class PresenceState {
        private var armed = true
        private var presentSamples = 0
        private var emptySamples = 0

        /**
         * A single event per appearance. After saving, only confidently empty frames
         * may re-arm the ROI; brightness flashes and ambiguous frames keep it locked.
         */
        fun observe(present: Boolean, clearlyEmpty: Boolean): Boolean {
            if (armed) {
                emptySamples = 0
                if (present) {
                    presentSamples++
                    if (presentSamples >= REQUIRED_STABLE_PRESENT_SAMPLES) {
                        armed = false
                        presentSamples = 0
                        emptySamples = 0
                        return true
                    }
                } else {
                    // Empty or ambiguous frames break the appearance candidate streak.
                    presentSamples = 0
                }
            } else {
                presentSamples = 0
                if (clearlyEmpty) {
                    emptySamples++
                    if (emptySamples >= REQUIRED_STABLE_EMPTY_SAMPLES) {
                        armed = true
                        emptySamples = 0
                    }
                } else {
                    // CARD and UNCERTAIN both stay locked; never re-arm on a blink.
                    emptySamples = 0
                }
            }
            return false
        }

        fun reset() {
            armed = true
            presentSamples = 0
            emptySamples = 0
        }
    }

    fun release() {
        rightConfig?.emptyReference?.recycle()
        leftConfig?.emptyReference?.recycle()
        rightConfig = null
        leftConfig = null
    }

    companion object {
        private const val GRID_SIZE = 48
        private const val NORMALIZED_PIXEL_DIFFERENCE_THRESHOLD = 28
        private const val CHANGED_PIXEL_RATIO_THRESHOLD = 0.22f
        private const val MEAN_DIFFERENCE_THRESHOLD = 20f
        // A second, stricter region defines confidently empty. The gap is UNCERTAIN, not empty.
        private const val EMPTY_CHANGED_PIXEL_RATIO_THRESHOLD = 0.12f
        private const val EMPTY_MEAN_DIFFERENCE_THRESHOLD = 12f
        // Analysed every 3rd captured frame: appearance takes ~0.6s; re-arm needs ~1.2s empty.
        private const val REQUIRED_STABLE_PRESENT_SAMPLES = 6
        private const val REQUIRED_STABLE_EMPTY_SAMPLES = 12
        private const val MIN_EXPOSURE_GAIN = 0.65f
        private const val MAX_EXPOSURE_GAIN = 1.55f
        private const val MIN_SAFE_GAIN = 0.65f
        private const val MAX_CROP_PIXELS = 12_000_000L
        private const val DIAGNOSTIC_INTERVAL_MS = 2_000L
    }
}
