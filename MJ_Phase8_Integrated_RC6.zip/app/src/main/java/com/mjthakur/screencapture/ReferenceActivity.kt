package com.mjthakur.screencapture

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

/** Optional 52-slot manual image library. The detector never reads card rank/suit from these images. */
class ReferenceActivity : Activity() {
    private lateinit var grid: GridLayout
    private var selectedSlot: CardSlot? = null
    private val slots by lazy { buildSlots() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        root.addView(TextView(this).apply {
            text = "Reference Images (Optional)"
            textSize = 22f
            setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "Tap a slot to add or replace an image. These 52 slots are manual storage only; automatic capture does not recognize card names or suits."
            textSize = 13f
            setPadding(0, dp(4), 0, dp(8))
        })
        val scroll = ScrollView(this)
        grid = GridLayout(this).apply { columnCount = 4 }
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "Back"; setOnClickListener { finish() } })
        setContentView(root)
        InsetsHelper.applySystemBarPadding(root)
        renderSlots()
    }

    override fun onResume() {
        super.onResume()
        if (::grid.isInitialized) renderSlots()
    }

    private fun buildSlots(): List<CardSlot> {
        val ranks = listOf("A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K")
        val suits = listOf("S" to "♠", "H" to "♥", "D" to "♦", "C" to "♣")
        return suits.flatMap { (key, symbol) -> ranks.map { rank -> CardSlot("${rank}_$key", "$rank$symbol") } }
    }

    private fun renderSlots() {
        grid.removeAllViews()
        slots.forEach { slot ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(5), dp(4), dp(5))
                setBackgroundColor(0xFFF1F1F1.toInt())
                isClickable = true
                isFocusable = true
                setOnClickListener { chooseImage(slot) }
            }
            val file = slotFile(slot)
            val image = ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                if (file.isFile) {
                    ImageUtils.decodeSampledFile(file.absolutePath, dp(70), dp(90))?.let { setImageBitmap(it) }
                } else {
                    setBackgroundColor(0xFFDDDDDD.toInt())
                }
                contentDescription = slot.label
            }
            tile.addView(image, LinearLayout.LayoutParams(-1, dp(88)))
            tile.addView(TextView(this).apply {
                text = if (file.isFile) "${slot.label} · Replace" else "${slot.label} · Add"
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(Color.BLACK)
            })
            grid.addView(tile, GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            })
        }
    }

    private fun chooseImage(slot: CardSlot) {
        selectedSlot = slot
        getSharedPreferences(CaptureConfig.APP_STATE_PREFS, MODE_PRIVATE).edit()
            .putBoolean(CaptureConfig.KEY_DETECTION_PAUSED, true).apply()
        val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(picker, REQUEST_PICK_IMAGE)
    }

    @Deprecated("Reference images use the platform document picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PICK_IMAGE || resultCode != RESULT_OK || data?.data == null) return
        val slot = selectedSlot ?: return
        val bitmap = ImageUtils.decodeUri(this, data.data!!)
        if (bitmap == null) {
            Toast.makeText(this, "Could not read selected image.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val target = slotFile(slot)
            ImageUtils.saveJpegAtomic(bitmap, target)
            Toast.makeText(this, "Reference image saved for ${slot.label}.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not save reference image: ${e.message}", Toast.LENGTH_LONG).show()
        } finally {
            bitmap.recycle()
            selectedSlot = null
            renderSlots()
        }
    }

    private fun slotFile(slot: CardSlot): File = File(File(filesDir, "reference_images"), "${slot.key}.jpg").apply {
        parentFile?.mkdirs()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private data class CardSlot(val key: String, val label: String)

    companion object { private const val REQUEST_PICK_IMAGE = 6101 }
}
