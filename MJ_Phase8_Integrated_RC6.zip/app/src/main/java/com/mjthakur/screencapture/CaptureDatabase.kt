package com.mjthakur.screencapture

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

 data class CaptureRecord(
    val id: Long,
    val sequenceNumber: Int,
    val side: String,
    val imagePath: String,
    val createdAt: Long,
    val sessionId: Long
)

data class DeckSession(
    val id: Long,
    val deckNumber: Int,
    val displayName: String,
    val createdAt: Long,
    val imageCount: Int
)

class CaptureDatabase(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        createSessionsTable(db)
        db.execSQL(
            "CREATE TABLE captures (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "sequence_no INTEGER NOT NULL," +
                "side TEXT NOT NULL," +
                "image_path TEXT NOT NULL," +
                "created_at INTEGER NOT NULL," +
                "session_id INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL("CREATE INDEX idx_captures_sequence ON captures(session_id, sequence_no, id)")
        db.execSQL("INSERT INTO sessions(id, deck_no, display_name, created_at) VALUES(0, 0, 'Previous captures', ${System.currentTimeMillis()})")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            createSessionsTable(db)
            db.execSQL("INSERT OR IGNORE INTO sessions(id, deck_no, display_name, created_at) VALUES(0, 0, 'Previous captures', ${System.currentTimeMillis()})")
            db.execSQL("ALTER TABLE captures ADD COLUMN session_id INTEGER NOT NULL DEFAULT 0")
            db.execSQL("DROP INDEX IF EXISTS idx_captures_sequence")
            db.execSQL("CREATE INDEX idx_captures_sequence ON captures(session_id, sequence_no, id)")
        }
    }

    private fun createSessionsTable(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS sessions (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "deck_no INTEGER NOT NULL," +
                "display_name TEXT NOT NULL COLLATE NOCASE," +
                "created_at INTEGER NOT NULL)"
        )
    }

    fun createDeckSession(): DeckSession {
        val db = writableDatabase
        var created: DeckSession? = null
        db.beginTransaction()
        try {
            var number = db.rawQuery("SELECT COALESCE(MAX(deck_no), 0) + 1 FROM sessions WHERE deck_no > 0", null).use { c ->
                if (c.moveToFirst()) c.getInt(0).coerceAtLeast(1) else 1
            }
            var displayName = "Deck $number"
            while (sessionNameExists(db, displayName, exceptId = null)) {
                number++
                displayName = "Deck $number"
            }
            val now = System.currentTimeMillis()
            val id = db.insertOrThrow(
                "sessions", null,
                ContentValues().apply {
                    put("deck_no", number)
                    put("display_name", displayName)
                    put("created_at", now)
                }
            )
            created = DeckSession(id, number, displayName, now, 0)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return created ?: throw IllegalStateException("Could not create a Deck folder")
    }

    fun getSessions(): List<DeckSession> {
        val result = mutableListOf<DeckSession>()
        readableDatabase.rawQuery(
            "SELECT s.id, s.deck_no, s.display_name, s.created_at, COUNT(c.id) " +
                "FROM sessions s LEFT JOIN captures c ON c.session_id=s.id " +
                "WHERE s.id != 0 OR EXISTS(SELECT 1 FROM captures oldc WHERE oldc.session_id=0) " +
                "GROUP BY s.id, s.deck_no, s.display_name, s.created_at " +
                "ORDER BY CASE WHEN s.id=0 THEN 1 ELSE 0 END, s.deck_no ASC, s.id ASC",
            null
        ).use { cursor ->
            while (cursor.moveToNext()) result += DeckSession(
                id = cursor.getLong(0),
                deckNumber = cursor.getInt(1),
                displayName = cursor.getString(2),
                createdAt = cursor.getLong(3),
                imageCount = cursor.getInt(4)
            )
        }
        return result
    }

    fun getSession(sessionId: Long): DeckSession? {
        readableDatabase.rawQuery(
            "SELECT s.id, s.deck_no, s.display_name, s.created_at, COUNT(c.id) " +
                "FROM sessions s LEFT JOIN captures c ON c.session_id=s.id WHERE s.id=? " +
                "GROUP BY s.id, s.deck_no, s.display_name, s.created_at",
            arrayOf(sessionId.toString())
        ).use { cursor ->
            return if (cursor.moveToFirst()) DeckSession(
                id = cursor.getLong(0),
                deckNumber = cursor.getInt(1),
                displayName = cursor.getString(2),
                createdAt = cursor.getLong(3),
                imageCount = cursor.getInt(4)
            ) else null
        }
    }

    fun renameSession(sessionId: Long, requestedName: String): Boolean {
        val name = requestedName.trim().take(50)
        if (name.isBlank()) return false
        val db = writableDatabase
        if (sessionNameExists(db, name, sessionId)) return false
        return db.update(
            "sessions",
            ContentValues().apply { put("display_name", name) },
            "id=?", arrayOf(sessionId.toString())
        ) > 0
    }

    private fun sessionNameExists(db: SQLiteDatabase, name: String, exceptId: Long?): Boolean {
        val sql = if (exceptId == null) {
            "SELECT COUNT(*) FROM sessions WHERE display_name=? COLLATE NOCASE"
        } else {
            "SELECT COUNT(*) FROM sessions WHERE display_name=? COLLATE NOCASE AND id<>?"
        }
        val args = if (exceptId == null) arrayOf(name) else arrayOf(name, exceptId.toString())
        return db.rawQuery(sql, args).use { c -> c.moveToFirst() && c.getInt(0) > 0 }
    }

    /** Deletes the database folder and returns every saved image path for physical cleanup. */
    fun deleteSession(sessionId: Long): List<String> {
        val db = writableDatabase
        val paths = mutableListOf<String>()
        db.beginTransaction()
        try {
            db.query("captures", arrayOf("image_path"), "session_id=?", arrayOf(sessionId.toString()), null, null, null)
                .use { c -> while (c.moveToNext()) paths += c.getString(0) }
            db.delete("captures", "session_id=?", arrayOf(sessionId.toString()))
            db.delete("sessions", "id=?", arrayOf(sessionId.toString()))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return paths
    }

    fun insertCapture(side: String, imagePath: String, sessionId: Long): CaptureRecord {
        val db = writableDatabase
        var created: CaptureRecord? = null
        db.beginTransaction()
        try {
            val deckExists = db.rawQuery("SELECT COUNT(*) FROM sessions WHERE id=?", arrayOf(sessionId.toString())).use { c ->
                c.moveToFirst() && c.getInt(0) > 0
            }
            if (!deckExists) throw IllegalStateException("The active Deck folder no longer exists")
            val count = db.rawQuery("SELECT COUNT(*) FROM captures WHERE session_id=?", arrayOf(sessionId.toString())).use { c ->
                if (c.moveToFirst()) c.getInt(0) else 0
            }
            if (count >= CaptureConfig.MAX_IMAGES_PER_DECK) throw DeckLimitReachedException()
            val sequence = db.rawQuery(
                "SELECT COALESCE(MAX(sequence_no), 0) + 1 FROM captures WHERE session_id=?",
                arrayOf(sessionId.toString())
            ).use { c -> if (c.moveToFirst()) c.getInt(0) else 1 }.coerceAtLeast(1)
            val now = System.currentTimeMillis()
            val id = db.insertOrThrow(
                "captures", null,
                ContentValues().apply {
                    put("sequence_no", sequence)
                    put("side", side)
                    put("image_path", imagePath)
                    put("created_at", now)
                    put("session_id", sessionId)
                }
            )
            created = CaptureRecord(id, sequence, side, imagePath, now, sessionId)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return created ?: throw IllegalStateException("Capture database insert failed")
    }

    fun getCaptureCountForSession(sessionId: Long): Int = readableDatabase.rawQuery(
        "SELECT COUNT(*) FROM captures WHERE session_id=?", arrayOf(sessionId.toString())
    ).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }

    fun getAllCaptures(): List<CaptureRecord> = queryCaptures(null, null, "created_at ASC, id ASC")

    fun getCapturesForSession(sessionId: Long): List<CaptureRecord> =
        queryCaptures("session_id=?", arrayOf(sessionId.toString()), "sequence_no ASC, id ASC")

    private fun queryCaptures(selection: String?, selectionArgs: Array<String>?, orderBy: String): List<CaptureRecord> {
        val result = mutableListOf<CaptureRecord>()
        readableDatabase.query(
            "captures",
            arrayOf("id", "sequence_no", "side", "image_path", "created_at", "session_id"),
            selection, selectionArgs, null, null, orderBy
        ).use { cursor -> while (cursor.moveToNext()) result += cursorToRecord(cursor) }
        return result
    }

    fun getCapture(id: Long): CaptureRecord? {
        readableDatabase.query(
            "captures",
            arrayOf("id", "sequence_no", "side", "image_path", "created_at", "session_id"),
            "id=?", arrayOf(id.toString()), null, null, null
        ).use { cursor -> return if (cursor.moveToFirst()) cursorToRecord(cursor) else null }
    }

    fun deleteCapture(id: Long): String? {
        val db = writableDatabase
        var imagePath: String? = null
        var sessionId: Long? = null
        db.beginTransaction()
        try {
            db.query("captures", arrayOf("image_path", "session_id"), "id=?", arrayOf(id.toString()), null, null, null)
                .use { c -> if (c.moveToFirst()) { imagePath = c.getString(0); sessionId = c.getLong(1) } }
            db.delete("captures", "id=?", arrayOf(id.toString()))
            sessionId?.let { compactSequenceNumbers(db, it) }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return imagePath
    }

    fun moveCapture(id: Long, direction: Int): Boolean {
        if (direction != -1 && direction != 1) return false
        val db = writableDatabase
        var moved = false
        db.beginTransaction()
        try {
            var sessionId: Long? = null
            db.query("captures", arrayOf("session_id"), "id=?", arrayOf(id.toString()), null, null, null)
                .use { c -> if (c.moveToFirst()) sessionId = c.getLong(0) }
            val actualSession = sessionId ?: return false
            val ids = mutableListOf<Long>()
            db.rawQuery(
                "SELECT id FROM captures WHERE session_id=? ORDER BY sequence_no ASC, id ASC",
                arrayOf(actualSession.toString())
            ).use { c -> while (c.moveToNext()) ids += c.getLong(0) }
            val from = ids.indexOf(id)
            val to = from + direction
            if (from >= 0 && to in ids.indices) {
                val temp = ids[from]
                ids[from] = ids[to]
                ids[to] = temp
                ids.forEachIndexed { index, captureId ->
                    db.update("captures", ContentValues().apply { put("sequence_no", -(index + 1)) }, "id=?", arrayOf(captureId.toString()))
                }
                ids.forEachIndexed { index, captureId ->
                    db.update("captures", ContentValues().apply { put("sequence_no", index + 1) }, "id=?", arrayOf(captureId.toString()))
                }
                moved = true
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return moved
    }

    fun updateImagePath(id: Long, imagePath: String): Boolean = writableDatabase.update(
        "captures", ContentValues().apply { put("image_path", imagePath) }, "id=?", arrayOf(id.toString())
    ) > 0

    private fun compactSequenceNumbers(db: SQLiteDatabase, sessionId: Long) {
        val ids = mutableListOf<Long>()
        db.rawQuery(
            "SELECT id FROM captures WHERE session_id=? ORDER BY sequence_no ASC, id ASC",
            arrayOf(sessionId.toString())
        ).use { c -> while (c.moveToNext()) ids += c.getLong(0) }
        ids.forEachIndexed { index, captureId ->
            db.update(
                "captures",
                ContentValues().apply { put("sequence_no", index + 1) },
                "id=?", arrayOf(captureId.toString())
            )
        }
    }

    private fun cursorToRecord(cursor: android.database.Cursor) = CaptureRecord(
        id = cursor.getLong(0),
        sequenceNumber = cursor.getInt(1),
        side = cursor.getString(2),
        imagePath = cursor.getString(3),
        createdAt = cursor.getLong(4),
        sessionId = cursor.getLong(5)
    )

    companion object {
        private const val DATABASE_NAME = "mj_capture_history.db"
        private const val DATABASE_VERSION = 2
    }
}

class DeckLimitReachedException : IllegalStateException("This Deck has reached its 400-image limit")
