package com.mjthakur.screencapture

import android.app.Activity
import android.content.Intent
import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.math.max
import kotlin.math.min

class AreaSetupActivity : Activity() {
    private lateinit var areaView: AreaSelectionView
    private lateinit var instructionText: TextView
    private lateinit var prefs: android.content.SharedPreferences
    private var sampleBitmap: Bitmap? = null
    private var emptySampleBitmap: Bitmap? = null
    private var samplePath: String? = null
    private var emptySamplePath: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_area_setup)
        InsetsHelper.applySystemBarPadding(findViewById(R.id.areaSetupRoot))

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        areaView = findViewById(R.id.areaSelectionView)
        instructionText = findViewById(R.id.areaInstructionText)

        val path = intent.getStringExtra(EXTRA_SAMPLE_PATH)
        samplePath = path
        val statePrefs = getSharedPreferences(CaptureConfig.APP_STATE_PREFS, MODE_PRIVATE)
        emptySamplePath = intent.getStringExtra(EXTRA_EMPTY_SAMPLE_PATH)
            ?: statePrefs.getString(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH, null)
        if (emptySamplePath != null && !File(emptySamplePath!!).isFile) emptySamplePath = null
        if (emptySamplePath != null) emptySampleBitmap = ImageUtils.decodeFullFile(emptySamplePath!!)
        if (path.isNullOrBlank()) {
            Toast.makeText(this, "Capture sample is missing.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        sampleBitmap = BitmapFactory.decodeFile(path)
        val bitmap = sampleBitmap
        if (bitmap == null) {
            Toast.makeText(this, "Could not open capture sample.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        areaView.setBitmap(bitmap)
        areaView.setSavedRectangles(
            loadRect("right", bitmap.width, bitmap.height),
            loadRect("left", bitmap.width, bitmap.height)
        )
        areaView.setActiveSide(AreaSelectionView.Side.RIGHT)
        instructionText.text = "Select the physical screen RIGHT card area first (Tiger). Draw tightly around the card, not labels/scores. The separate empty sample must show no card in either area."

        findViewById<Button>(R.id.setRightButton).setOnClickListener {
            areaView.setActiveSide(AreaSelectionView.Side.RIGHT)
            instructionText.text = "Select the physical screen RIGHT card area first (Tiger). Draw tightly around the card, not labels/scores. The separate empty sample must show no card in either area."
        }
        findViewById<Button>(R.id.setLeftButton).setOnClickListener {
            areaView.setActiveSide(AreaSelectionView.Side.LEFT)
            instructionText.text = "LEFT = physical screen-left card area (Dragon). Draw tightly around the card, not labels/scores."
        }
        findViewById<Button>(R.id.testRightButton).setOnClickListener {
            previewArea("right", areaView.getRightRect())
        }
        findViewById<Button>(R.id.testLeftButton).setOnClickListener {
            previewArea("left", areaView.getLeftRect())
        }
        findViewById<Button>(R.id.saveAreasButton).setOnClickListener {
            showSaveOptions()
        }
        findViewById<Button>(R.id.resetAreasButton).setOnClickListener {
            resetAreas()
        }
    }

    private fun validRectangles(): Pair<RectF, RectF>? {
        val right = areaView.getRightRect()
        val left = areaView.getLeftRect()
        if (right == null || left == null || right.width() < 20f || right.height() < 20f ||
            left.width() < 20f || left.height() < 20f
        ) {
            Toast.makeText(this, "Set both Right and Left areas first.", Toast.LENGTH_LONG).show()
            return null
        }
        if (right.centerX() <= left.centerX()) {
            Toast.makeText(
                this,
                "The RIGHT rectangle is on the screen-left of the LEFT rectangle. Requirements: RIGHT = physical screen-right/Tiger; LEFT = physical screen-left/Dragon. Redraw the rectangles before saving.",
                Toast.LENGTH_LONG
            ).show()
            return null
        }
        return right to left
    }

    private fun previewArea(label: String, rect: RectF?) {
        val source = sampleBitmap ?: return
        if (rect == null || rect.width() < 20f || rect.height() < 20f) {
            Toast.makeText(this, "Set the ${label.replaceFirstChar { it.uppercase() }} Area first.", Toast.LENGTH_LONG).show()
            return
        }
        val crop = cropBitmap(source, rect)
        if (crop == null) {
            Toast.makeText(this, "Could not preview this area.", Toast.LENGTH_LONG).show()
            return
        }
        val imageView = ImageView(this).apply {
            setImageBitmap(crop)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(260)
            )
        }
        AlertDialog.Builder(this)
            .setTitle("${label.replaceFirstChar { it.uppercase() }} Area Preview")
            .setMessage("Preview only; this does not add an item to History.")
            .setView(imageView)
            .setPositiveButton("Close", null)
            .setOnDismissListener { if (!crop.isRecycled) crop.recycle() }
            .show()
    }

    private fun showSaveOptions() {
        val rectangles = validRectangles() ?: return
        val areaSource = sampleBitmap ?: return
        val emptySource = emptySampleBitmap
        if (emptySource == null || emptySamplePath.isNullOrBlank() || !File(emptySamplePath!!).isFile) {
            AlertDialog.Builder(this)
                .setTitle("Save selected areas")
                .setMessage(
                    "This screenshot is ONLY for drawing the two rectangles. It may contain cards, so it will NOT be used as the empty baseline.\n\n" +
                        "The separate no-card sample has not been captured/loaded yet. Save the areas now, then use Settings to capture an empty sample, or capture both samples from the notification before saving."
                )
                .setPositiveButton("Save Areas Only") { _, _ ->
                    saveAreasOnly(rectangles.first, rectangles.second, areaSource.width, areaSource.height)
                }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }
        showSeparateEmptySampleReview(rectangles.first, rectangles.second, areaSource, emptySource)
    }

    /** Show the selected crops from the SECOND screenshot before it can become the empty baseline. */
    private fun showSeparateEmptySampleReview(
        right: RectF,
        left: RectF,
        areaSource: Bitmap,
        emptySource: Bitmap
    ) {
        val rightEmptyRect = mapRectToTarget(right, areaSource, emptySource)
        val leftEmptyRect = mapRectToTarget(left, areaSource, emptySource)
        val rightCrop = cropBitmap(emptySource, rightEmptyRect)
        val leftCrop = cropBitmap(emptySource, leftEmptyRect)
        if (rightCrop == null || leftCrop == null) {
            rightCrop?.recycle()
            leftCrop?.recycle()
            Toast.makeText(this, "Could not preview the selected areas in the empty sample. Capture both samples at the same screen orientation/size.", Toast.LENGTH_LONG).show()
            return
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        content.addView(TextView(this).apply {
            text = "These crops come from the SEPARATE empty screenshot. Neither crop may contain a card. If you can see any card, cancel and recapture the empty sample when both card positions are blank."
            textSize = 14f
            setPadding(0, 0, 0, dp(8))
        })
        val previews = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        previews.addView(emptyPreviewColumn("RIGHT empty crop", rightCrop), LinearLayout.LayoutParams(0, dp(150), 1f))
        previews.addView(emptyPreviewColumn("LEFT empty crop", leftCrop), LinearLayout.LayoutParams(0, dp(150), 1f))
        content.addView(previews)
        val dialog = AlertDialog.Builder(this)
            .setTitle("Verify the no-card sample")
            .setView(content)
            .setPositiveButton("No cards — Save Both") { _, _ ->
                saveAreasAndCalibrateFromSeparateSample(right, left, areaSource, emptySource)
            }
            .setNegativeButton("Cancel / Retake", null)
            .create()
        dialog.setOnDismissListener {
            if (!rightCrop.isRecycled) rightCrop.recycle()
            if (!leftCrop.isRecycled) leftCrop.recycle()
        }
        dialog.show()
    }

    private fun emptyPreviewColumn(label: String, bitmap: Bitmap): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        addView(TextView(this@AreaSetupActivity).apply {
            text = label
            textSize = 12f
            gravity = Gravity.CENTER
        })
        addView(ImageView(this@AreaSetupActivity).apply {
            setImageBitmap(bitmap)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = label
        }, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun mapRectToTarget(rect: RectF, source: Bitmap, target: Bitmap): RectF = RectF(
        rect.left / source.width * target.width,
        rect.top / source.height * target.height,
        rect.right / source.width * target.width,
        rect.bottom / source.height * target.height
    )

    private fun saveAreasOnly(right: RectF, left: RectF, width: Int, height: Int) {
        val changed = areasDifferFromSaved(right, left, width, height)
        if (changed) clearEmptyReferences()
        persistAreas(right, left, width, height)
        prefs.edit().putBoolean(CaptureConfig.KEY_AREAS_SAVED, true).apply()
        clearPendingSamples(deleteFiles = true)
        refreshCaptureNotification()
        val message = if (changed) {
            "Areas saved only. The previous empty baseline was cleared because the rectangles changed. Capture a separate no-card sample before Auto Capture."
        } else if (CaptureConfig.isDetectionConfigured(this)) {
            "Right and Left areas saved. Existing verified empty baseline kept."
        } else {
            "Areas saved only. Capture a separate no-card empty sample before Auto Capture."
        }
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        finish()
    }

    private fun saveAreasAndCalibrateFromSeparateSample(
        right: RectF,
        left: RectF,
        areaSource: Bitmap,
        emptySource: Bitmap
    ) {
        var rightCrop: Bitmap? = null
        var leftCrop: Bitmap? = null
        val folder = File(filesDir, "capture_calibration").apply { mkdirs() }
        val stamp = System.currentTimeMillis()
        val rightFile = File(folder, "right_empty_$stamp.jpg")
        val leftFile = File(folder, "left_empty_$stamp.jpg")
        val oldPaths = listOf(
            prefs.getString(CaptureConfig.KEY_RIGHT_EMPTY_PATH, null),
            prefs.getString(CaptureConfig.KEY_LEFT_EMPTY_PATH, null)
        ).filterNotNull().distinct()
        try {
            rightCrop = cropBitmap(emptySource, mapRectToTarget(right, areaSource, emptySource))
                ?: throw IllegalStateException("Could not crop Right empty area from the second sample")
            leftCrop = cropBitmap(emptySource, mapRectToTarget(left, areaSource, emptySource))
                ?: throw IllegalStateException("Could not crop Left empty area from the second sample")
            ImageUtils.saveJpegAtomic(rightCrop, rightFile, 95)
            ImageUtils.saveJpegAtomic(leftCrop, leftFile, 95)

            val editor = prefs.edit()
            putRect(editor, "right", right, areaSource.width, areaSource.height)
            putRect(editor, "left", left, areaSource.width, areaSource.height)
            val saved = editor
                .putInt(CaptureConfig.KEY_SAMPLE_WIDTH, areaSource.width)
                .putInt(CaptureConfig.KEY_SAMPLE_HEIGHT, areaSource.height)
                .putString(CaptureConfig.KEY_RIGHT_EMPTY_PATH, rightFile.absolutePath)
                .putString(CaptureConfig.KEY_LEFT_EMPTY_PATH, leftFile.absolutePath)
                .putBoolean(CaptureConfig.KEY_AREAS_SAVED, true)
                .putBoolean(CaptureConfig.KEY_EMPTY_CALIBRATION_SAVED, true)
                .putInt(CaptureConfig.KEY_EMPTY_CALIBRATION_VERSION, CaptureConfig.CURRENT_EMPTY_CALIBRATION_VERSION)
                .commit()
            if (!saved) throw IllegalStateException("Could not save areas and the separate empty baseline")

            oldPaths.forEach { old ->
                if (old != rightFile.absolutePath && old != leftFile.absolutePath) File(old).delete()
            }
            clearPendingSamples(deleteFiles = true)
            refreshCaptureNotification()
            Toast.makeText(
                this,
                "Both areas and the separate empty baseline are saved. Auto Capture is ready; start it from the notification.",
                Toast.LENGTH_LONG
            ).show()
            finish()
        } catch (e: Exception) {
            rightFile.delete()
            leftFile.delete()
            Toast.makeText(this, "Could not save the two samples: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        } finally {
            rightCrop?.recycle()
            leftCrop?.recycle()
        }
    }

    private fun clearPendingSamples(deleteFiles: Boolean) {
        val state = getSharedPreferences(CaptureConfig.APP_STATE_PREFS, MODE_PRIVATE)
        val pendingArea = state.getString(CaptureService.KEY_PENDING_SAMPLE_PATH, null)
        val pendingEmpty = state.getString(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH, null)
        if (deleteFiles) {
            pendingArea?.let { File(it).delete() }
            pendingEmpty?.let { File(it).delete() }
            samplePath?.let { File(it).delete() }
            emptySamplePath?.let { File(it).delete() }
        }
        state.edit()
            .remove(CaptureService.KEY_PENDING_SAMPLE_PATH)
            .remove(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH)
            .apply()
    }

    private fun refreshCaptureNotification() {
        val running = getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE)
            .getBoolean(CaptureService.KEY_CAPTURE_RUNNING, false)
        if (!running) return
        try {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_REFRESH_NOTIFICATION))
        } catch (_: Exception) {
            // The saved preferences remain valid; notification refresh can be retried next time.
        }
    }

    private fun cropBitmap(source: Bitmap, rect: RectF): Bitmap? {
        val left = rect.left.toInt().coerceIn(0, source.width - 1)
        val top = rect.top.toInt().coerceIn(0, source.height - 1)
        val right = rect.right.toInt().coerceIn(left + 1, source.width)
        val bottom = rect.bottom.toInt().coerceIn(top + 1, source.height)
        if (right - left < 1 || bottom - top < 1) return null
        return Bitmap.createBitmap(source, left, top, right - left, bottom - top)
    }

    private fun persistAreas(right: RectF, left: RectF, width: Int, height: Int) {
        val editor = prefs.edit()
        putRect(editor, "right", right, width, height)
        putRect(editor, "left", left, width, height)
        editor.putInt(CaptureConfig.KEY_SAMPLE_WIDTH, width)
            .putInt(CaptureConfig.KEY_SAMPLE_HEIGHT, height)
            .putBoolean(CaptureConfig.KEY_AREAS_SAVED, true)
            .apply()
    }

    private fun putRect(
        editor: android.content.SharedPreferences.Editor,
        prefix: String,
        rect: RectF,
        width: Int,
        height: Int
    ) {
        editor.putFloat("${prefix}_left", rect.left / width)
            .putFloat("${prefix}_top", rect.top / height)
            .putFloat("${prefix}_right", rect.right / width)
            .putFloat("${prefix}_bottom", rect.bottom / height)
    }

    private fun loadRect(prefix: String, width: Int, height: Int): RectF? {
        if (!prefs.contains("${prefix}_left")) return null
        return RectF(
            prefs.getFloat("${prefix}_left", 0f) * width,
            prefs.getFloat("${prefix}_top", 0f) * height,
            prefs.getFloat("${prefix}_right", 0f) * width,
            prefs.getFloat("${prefix}_bottom", 0f) * height
        )
    }

    private fun areasDifferFromSaved(right: RectF, left: RectF, width: Int, height: Int): Boolean {
        fun differs(prefix: String, rect: RectF): Boolean {
            val saved = CaptureConfig.readNormalizedRect(prefs, prefix) ?: return true
            val newRect = RectF(rect.left / width, rect.top / height, rect.right / width, rect.bottom / height)
            return kotlin.math.abs(saved.left - newRect.left) > 0.0005f ||
                kotlin.math.abs(saved.top - newRect.top) > 0.0005f ||
                kotlin.math.abs(saved.right - newRect.right) > 0.0005f ||
                kotlin.math.abs(saved.bottom - newRect.bottom) > 0.0005f
        }
        return differs("right", right) || differs("left", left)
    }

    private fun clearEmptyReferences() {
        listOf(CaptureConfig.KEY_RIGHT_EMPTY_PATH, CaptureConfig.KEY_LEFT_EMPTY_PATH).forEach { key ->
            prefs.getString(key, null)?.let { File(it).delete() }
        }
        prefs.edit()
            .remove(CaptureConfig.KEY_RIGHT_EMPTY_PATH)
            .remove(CaptureConfig.KEY_LEFT_EMPTY_PATH)
            .putBoolean(CaptureConfig.KEY_EMPTY_CALIBRATION_SAVED, false)
            .remove(CaptureConfig.KEY_EMPTY_CALIBRATION_VERSION)
            .apply()
    }

    private fun resetAreas() {
        clearEmptyReferences()
        listOf(
            "right_left", "right_top", "right_right", "right_bottom",
            "left_left", "left_top", "left_right", "left_bottom",
            CaptureConfig.KEY_SAMPLE_WIDTH, CaptureConfig.KEY_SAMPLE_HEIGHT, CaptureConfig.KEY_AREAS_SAVED
        ).forEach { key -> prefs.edit().remove(key).apply() }
        File(filesDir, "capture_calibration").listFiles()?.forEach { it.delete() }
        areaView.setSavedRectangles(null, null)
        Toast.makeText(this, "Saved areas and empty references reset.", Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        // The view is going away; release the large decoded sample bitmap.
        sampleBitmap?.let { if (!it.isRecycled) it.recycle() }
        sampleBitmap = null
        emptySampleBitmap?.let { if (!it.isRecycled) it.recycle() }
        emptySampleBitmap = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_SAMPLE_PATH = "extra_sample_path"
        const val EXTRA_EMPTY_SAMPLE_PATH = "extra_empty_sample_path_for_pair"
        const val PREFS_NAME = CaptureConfig.PREFS_NAME
    }
}
