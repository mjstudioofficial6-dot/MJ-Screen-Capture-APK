package com.mjthakur.screencapture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.Display
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class CaptureService : Service() {
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    private var frameCount = 0L
    private var captureDisplayWidth = 0
    private var captureDisplayHeight = 0
    private var captureDensityDpi = 0
    private var displayListenerRegistered = false
    @Volatile private var stopped = false
    @Volatile private var sampleRequestPending = false
    private var detectionExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var detectionEngine: DetectionEngine? = null
    private var captureDatabase: CaptureDatabase? = null
    @Volatile private var activeSessionId: Long = -1L
    private val detectionLock = Any()

    private val mediaProjectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stopCapture()
        }
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = Unit
        override fun onDisplayRemoved(displayId: Int) = Unit
        override fun onDisplayChanged(displayId: Int) {
            if (displayId != Display.DEFAULT_DISPLAY || mediaProjection == null || stopped) return
            val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)
            if (metrics.widthPixels != captureDisplayWidth ||
                metrics.heightPixels != captureDisplayHeight ||
                metrics.densityDpi != captureDensityDpi
            ) {
                stopCapture()
                sendStatus("Capture stopped because screen size/orientation changed. Restart and recalibrate if needed.")
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startCapture(intent)
            ACTION_STOP -> stopCapture()
            ACTION_CAPTURE_SAMPLE -> requestCaptureSample()
            ACTION_PREPARE_EMPTY_SAMPLE -> prepareEmptyBackgroundSample()
            ACTION_REFRESH_NOTIFICATION -> refreshNotificationFromState()
            ACTION_RESUME_AUTO_CAPTURE -> setAutoCaptureEnabled(true)
            ACTION_PAUSE_AUTO_CAPTURE -> setAutoCaptureEnabled(false)
        }
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent) {
        if (mediaProjection != null) {
            sendStatus("Screen capture is already running. Frames received: $frameCount")
            return
        }
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
        val resultData = getParcelableIntentExtra(intent, EXTRA_RESULT_DATA)
        if (resultCode != Activity.RESULT_OK || resultData == null) {
            sendStatus("Screen capture could not start: missing permission data.")
            stopSelf()
            return
        }

        stopped = false
        activeSessionId = -1L
        if (detectionExecutor.isShutdown) detectionExecutor = Executors.newSingleThreadExecutor()
        frameCount = 0L
        getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_CAPTURE_RUNNING, true)
            .putBoolean(CaptureConfig.KEY_AUTO_CAPTURE_ENABLED, false)
            .putBoolean(CaptureConfig.KEY_NEXT_SAMPLE_IS_EMPTY, false)
            .putLong(KEY_FRAME_COUNT, 0L)
            .apply()
        sendDetectionStatus("Auto Capture is paused. Save both areas and a verified no-card empty background sample, then tap Start Auto Capture.")
        startForegroundNotification("Screen capture is running • Auto Capture paused")

        try {
            val projectionManager = getSystemService(MediaProjectionManager::class.java)
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
            val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val densityDpi = metrics.densityDpi
            captureDisplayWidth = width
            captureDisplayHeight = height
            captureDensityDpi = densityDpi
            val activeDeck = openCaptureDeck()

            captureThread = HandlerThread("MJ-CaptureThread").also { it.start() }
            captureHandler = Handler(captureThread!!.looper)
            // Required by Android 14+: register the callback before createVirtualDisplay().
            mediaProjection!!.registerCallback(mediaProjectionCallback, captureHandler)
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
            synchronized(detectionLock) {
                detectionEngine?.release()
                detectionEngine = null
            }
            detectionEngine = DetectionEngine(
                applicationContext,
                onStableAppearance = { side, crop -> queueDetectedCrop(side, crop) },
                onMessage = { message -> sendDetectionStatus(message) }
            )

            imageReader!!.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    frameCount++
                    if (frameCount == 1L || frameCount % 30L == 0L) {
                        getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE).edit()
                            .putLong(KEY_FRAME_COUNT, frameCount).apply()
                        sendStatus("Screen capture running. Frames received: $frameCount")
                    }

                    if (stopped) return@setOnImageAvailableListener
                    val requestedSample = sampleRequestPending
                    if (requestedSample) sampleRequestPending = false
                    if (requestedSample) {
                        val bitmap = imageToBitmap(image)
                        if (bitmap == null) {
                            sendStatus("Area sample failed: could not convert the captured frame.")
                        } else {
                            try { saveRequestedAreaSample(bitmap) }
                            finally { if (!bitmap.isRecycled) bitmap.recycle() }
                        }
                    } else if (frameCount % ANALYZE_EVERY_N_FRAMES == 0L &&
                        CaptureConfig.isAutoCaptureEnabled(this) &&
                        detectionEngine?.isConfiguredNow() == true && !CaptureConfig.shouldPauseDetection(this)
                    ) {
                        try {
                            synchronized(detectionLock) { detectionEngine?.processImage(image) }
                        } catch (e: Exception) {
                            sendDetectionStatus("Detection processing error: ${e.message ?: "unknown error"}")
                        }
                    }
                } finally {
                    image.close()
                }
            }, captureHandler)

            virtualDisplay = mediaProjection!!.createVirtualDisplay(
                "MJ Screen Capture", width, height, densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader!!.surface, null, captureHandler
            )
            val displayManager = getSystemService(DisplayManager::class.java)
            displayManager.registerDisplayListener(displayListener, captureHandler)
            displayListenerRegistered = true
            updateForegroundNotification("Screen capture running • ${activeDeck.displayName} • Auto Capture paused")
            sendStatus("Screen capture running in ${activeDeck.displayName}. Waiting for frames...")
            if (!CaptureConfig.isDetectionConfigured(this)) {
                sendDetectionStatus("Auto Capture NOT READY: save both areas and a verified no-card empty background sample.")
            } else {
                sendDetectionStatus("Areas and empty references are configured. Tap Start Auto Capture to begin.")
            }
        } catch (e: Exception) {
            sendStatus("Screen capture failed: ${e.message ?: "unknown error"}")
            stopCapture()
        }
    }

    private fun setAutoCaptureEnabled(enabled: Boolean) {
        val state = getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE)
        if (enabled) {
            if (mediaProjection == null || stopped || !state.getBoolean(KEY_CAPTURE_RUNNING, false)) {
                sendDetectionStatus("Cannot start Auto Capture: start Screen Capture first.")
                return
            }
            if (!CaptureConfig.isDetectionConfigured(this)) {
                sendDetectionStatus("Auto Capture NOT READY: save both areas and a verified no-card empty background sample.")
                return
            }
            val sessionId = activeSessionId
            if (sessionId > 0L) {
                val database = captureDatabase ?: CaptureDatabase(applicationContext).also { captureDatabase = it }
                if (database.getCaptureCountForSession(sessionId) >= CaptureConfig.MAX_IMAGES_PER_DECK) {
                    pauseAtDeckLimit(sessionId, database)
                    return
                }
            }
        }
        state.edit().putBoolean(CaptureConfig.KEY_AUTO_CAPTURE_ENABLED, enabled).apply()
        if (enabled) {
            sendDetectionStatus("Auto Capture ON. Switch to the target video; monitoring pauses while MJ Screen Capture is open.")
            updateForegroundNotification("Auto Capture ON • Monitoring target video")
        } else {
            sendDetectionStatus("Auto Capture PAUSED by user. Screen capture and frame counter remain active.")
            updateForegroundNotification("Screen capture running • Auto Capture paused")
        }
    }

    private fun prepareEmptyBackgroundSample() {
        if (mediaProjection == null || stopped) {
            sendDetectionStatus("Start Screen Capture first, then prepare an empty background sample.")
            return
        }
        if (!CaptureConfig.areAreasSaved(this)) {
            sendDetectionStatus("Save both Right and Left areas before capturing an empty sample.")
            return
        }
        getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(CaptureConfig.KEY_AUTO_CAPTURE_ENABLED, false)
            .putBoolean(CaptureConfig.KEY_NEXT_SAMPLE_IS_EMPTY, true)
            .putBoolean(CaptureConfig.KEY_DETECTION_PAUSED, true)
            .apply()
        sendDetectionStatus("Ready for empty sample: show the target video with NO card in either selected area, then tap Capture Empty Sample in this notification.")
        updateForegroundNotification("Ready for empty background sample • no cards in either area")
    }

    private fun refreshNotificationFromState() {
        if (mediaProjection == null || stopped) return
        val state = getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE)
        val enabled = CaptureConfig.isAutoCaptureEnabled(this)
        val pairedArea = state.getString(KEY_PENDING_SAMPLE_PATH, null)?.let { File(it).isFile } == true
        val pairedEmpty = state.getString(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH, null)?.let { File(it).isFile } == true
        val content = when {
            state.getBoolean(CaptureConfig.KEY_NEXT_SAMPLE_IS_EMPTY, false) -> "Ready to capture a separate empty/no-card screenshot"
            pairedArea && pairedEmpty -> "Both samples captured • return to set areas and verify no-card crops"
            pairedArea -> "Area sample captured • next capture the empty/no-card sample"
            enabled -> "Screen capture running • Auto Capture ON"
            else -> "Screen capture running • Auto Capture paused"
        }
        updateForegroundNotification(content)
    }

    private fun requestCaptureSample() {
        if (mediaProjection == null || captureHandler == null) {
            sendStatus("Sample capture needs an active screen-capture session.")
            return
        }
        val state = getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE)
        var areaPath = state.getString(KEY_PENDING_SAMPLE_PATH, null)
        var emptyPath = state.getString(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH, null)
        val areaExists = !areaPath.isNullOrBlank() && File(areaPath).isFile
        val emptyExists = !emptyPath.isNullOrBlank() && File(emptyPath).isFile
        var emptyMode = state.getBoolean(CaptureConfig.KEY_NEXT_SAMPLE_IS_EMPTY, false) || areaExists

        // If both samples are already waiting, another sample-button tap starts a fresh pair.
        if (areaExists && emptyExists && !state.getBoolean(CaptureConfig.KEY_NEXT_SAMPLE_IS_EMPTY, false)) {
            File(areaPath!!).delete()
            File(emptyPath!!).delete()
            state.edit()
                .remove(KEY_PENDING_SAMPLE_PATH)
                .remove(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH)
                .putBoolean(CaptureConfig.KEY_NEXT_SAMPLE_IS_EMPTY, false)
                .apply()
            areaPath = null
            emptyPath = null
            emptyMode = false
        }

        // Empty sample collection is intentionally allowed before the rectangles are saved:
        // the two screenshots are paired later in AreaSetupActivity using the same coordinates.
        state.edit()
            .putBoolean(CaptureConfig.KEY_AUTO_CAPTURE_ENABLED, false)
            .putBoolean(CaptureConfig.KEY_DETECTION_PAUSED, true)
            .putBoolean(CaptureConfig.KEY_NEXT_SAMPLE_IS_EMPTY, emptyMode)
            .apply()
        updateForegroundNotification(if (emptyMode) "Capturing separate empty/no-card sample..." else "Capturing area-selection sample...")
        captureHandler?.postDelayed({
            // Let Android close the notification shade before the actual frame is acquired.
            sampleRequestPending = true
            sendStatus(if (emptyMode) "Capturing the separate empty/no-card frame now..." else "Capturing the area-selection frame now...")
        }, SAMPLE_CAPTURE_DELAY_MS)
    }

    private fun saveRequestedAreaSample(bitmap: Bitmap) {
        val state = getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE)
        val areaPathBeforeCapture = state.getString(KEY_PENDING_SAMPLE_PATH, null)
        val emptyMode = state.getBoolean(CaptureConfig.KEY_NEXT_SAMPLE_IS_EMPTY, false)
        try {
            val folder = File(filesDir, "capture_area").apply { mkdirs() }
            val unique = System.currentTimeMillis()
            val file = File(folder, if (emptyMode) "empty_background_sample_$unique.jpg" else "area_sample_$unique.jpg")
            FileOutputStream(file).use { output ->
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 95, output)) throw IllegalStateException("JPEG compression failed")
                output.fd.sync()
            }
            val editor = state.edit()
            if (emptyMode) {
                editor.putString(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH, file.absolutePath)
                editor.putBoolean(CaptureConfig.KEY_NEXT_SAMPLE_IS_EMPTY, false)
            } else {
                // A new area sample invalidates any stale pending empty sample.
                state.getString(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH, null)?.let { File(it).delete() }
                editor.remove(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH)
                    .putString(KEY_PENDING_SAMPLE_PATH, file.absolutePath)
                    .putBoolean(CaptureConfig.KEY_NEXT_SAMPLE_IS_EMPTY, true)
            }
            editor.apply()

            val pairedAreaExists = !areaPathBeforeCapture.isNullOrBlank() && File(areaPathBeforeCapture).isFile
            val action = if (emptyMode) ACTION_EMPTY_SAMPLE_SAVED else ACTION_SAMPLE_SAVED
            sendBroadcast(Intent(action).setPackage(packageName).putExtra(EXTRA_SAMPLE_PATH, file.absolutePath))
            val message = when {
                emptyMode && pairedAreaExists -> "Both samples captured. Return to MJ Screen Capture, tap CAPTURE AREA, and verify both empty crops before saving."
                emptyMode -> "Empty background sample captured. Return to MJ Screen Capture to review and save it."
                else -> "Area sample captured. The notification now offers Capture Empty Sample. Take the second screenshot only when NO card is visible in either selected area."
            }
            sendStatus(message)
            val notificationText = when {
                emptyMode && pairedAreaExists -> "Both samples captured • return to set areas and verify no-card crops"
                emptyMode -> "Empty sample captured • return to save baseline"
                else -> "Area sample captured • next capture an empty/no-card sample"
            }
            updateForegroundNotification(notificationText)
        } catch (e: Exception) {
            sendStatus("Sample capture failed: ${e.message ?: "unknown error"}")
            updateForegroundNotification("Sample capture failed • retry from this notification")
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        if (pixelStride <= 0 || rowStride <= 0) return null
        val rowPadding = rowStride - pixelStride * image.width
        val bitmapWidth = image.width + (rowPadding / pixelStride)
        val fullBitmap = Bitmap.createBitmap(bitmapWidth, image.height, Bitmap.Config.ARGB_8888)
        buffer.rewind()
        fullBitmap.copyPixelsFromBuffer(buffer)
        return if (bitmapWidth == image.width) fullBitmap else Bitmap.createBitmap(fullBitmap, 0, 0, image.width, image.height).also {
            fullBitmap.recycle()
        }
    }

    private fun queueDetectedCrop(side: String, crop: Bitmap) {
        try {
            detectionExecutor.execute { saveDetectedCrop(side, crop) }
        } catch (e: Exception) {
            if (!crop.isRecycled) crop.recycle()
            sendDetectionStatus("Automatic image save could not be queued: ${e.message ?: "unknown error"}")
        }
    }

    private fun openCaptureDeck(): DeckSession {
        val database = captureDatabase ?: CaptureDatabase(applicationContext).also { captureDatabase = it }
        val appState = getSharedPreferences(CaptureConfig.APP_STATE_PREFS, Context.MODE_PRIVATE)
        val requestedSessionId = appState.getLong(CaptureConfig.KEY_NEXT_SESSION_ID, -1L)
        val requestedSession = if (requestedSessionId > 0L) database.getSession(requestedSessionId) else null
        val reusableSession = requestedSession?.takeIf { it.imageCount < CaptureConfig.MAX_IMAGES_PER_DECK }
        val deck = reusableSession ?: database.createDeckSession()
        val imageFolder = File(File(filesDir, "decks/deck_${deck.id}"), "images")
        if (!imageFolder.exists() && !imageFolder.mkdirs()) {
            throw IllegalStateException("Could not create private folder for ${deck.displayName}")
        }
        activeSessionId = deck.id
        val editor = appState.edit().putLong(KEY_ACTIVE_SESSION_ID, deck.id)
        if (requestedSessionId > 0L) editor.remove(CaptureConfig.KEY_NEXT_SESSION_ID)
        editor.apply()
        return deck
    }

    private fun pauseAtDeckLimit(sessionId: Long, database: CaptureDatabase) {
        val deckName = database.getSession(sessionId)?.displayName ?: "This Deck"
        getSharedPreferences(CaptureConfig.APP_STATE_PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(CaptureConfig.KEY_AUTO_CAPTURE_ENABLED, false).apply()
        val message = "$deckName reached ${CaptureConfig.MAX_IMAGES_PER_DECK}/${CaptureConfig.MAX_IMAGES_PER_DECK} images. Auto Capture paused; stop or select another Deck for the next session."
        sendDetectionStatus(message)
        updateForegroundNotification(message)
    }

    private fun saveDetectedCrop(side: String, crop: Bitmap) {
        var outputFile: File? = null
        var databaseInsertCompleted = false
        try {
            // A crop already accepted by the detector is completed even if Pause is tapped while it waits in the save queue.
            val database = captureDatabase ?: CaptureDatabase(applicationContext).also { captureDatabase = it }
            val sessionId = activeSessionId
            if (sessionId <= 0L) throw IllegalStateException("No active Deck folder is assigned")
            if (database.getCaptureCountForSession(sessionId) >= CaptureConfig.MAX_IMAGES_PER_DECK) {
                pauseAtDeckLimit(sessionId, database)
                return
            }
            val folder = File(File(filesDir, "decks/deck_$sessionId"), "images").apply {
                if (!exists() && !mkdirs()) throw IllegalStateException("Could not create image folder")
            }
            val file = File(folder, "capture_${System.currentTimeMillis()}_${UUID.randomUUID()}.jpg")
            outputFile = file
            ImageUtils.saveJpegAtomic(crop, file, 94)
            val record = database.insertCapture(side, file.absolutePath, sessionId)
            databaseInsertCompleted = true
            val session = database.getSession(sessionId)
            val message = "${session?.displayName ?: "Deck"}: Saved ${record.sequenceNumber.toString().padStart(3, '0')} • $side (${session?.imageCount ?: record.sequenceNumber}/${CaptureConfig.MAX_IMAGES_PER_DECK})"
            sendDetectionStatus(message)
            updateForegroundNotification(message)
            if ((session?.imageCount ?: 0) >= CaptureConfig.MAX_IMAGES_PER_DECK) pauseAtDeckLimit(sessionId, database)
        } catch (e: Exception) {
            // Do not delete an image after its SQLite row was committed; that would
            // leave a history row pointing to a missing file.
            if (!databaseInsertCompleted) outputFile?.delete()
            if (e is DeckLimitReachedException && activeSessionId > 0L) {
                val db = captureDatabase ?: CaptureDatabase(applicationContext).also { captureDatabase = it }
                pauseAtDeckLimit(activeSessionId, db)
            } else {
                sendDetectionStatus("Automatic image save failed: ${e.message ?: "unknown error"}")
            }
        } finally {
            if (!crop.isRecycled) crop.recycle()
        }
    }

    private fun buildNotification(content: String): Notification {
        val state = getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE)
        val nextSampleIsEmpty = state.getBoolean(CaptureConfig.KEY_NEXT_SAMPLE_IS_EMPTY, false)
        val pendingAreaPath = state.getString(KEY_PENDING_SAMPLE_PATH, null)
        val pendingEmptyPath = state.getString(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH, null)
        val pendingAreaExists = !pendingAreaPath.isNullOrBlank() && File(pendingAreaPath).isFile
        val pendingEmptyExists = !pendingEmptyPath.isNullOrBlank() && File(pendingEmptyPath).isFile
        val sampleIntent = Intent(this, CaptureService::class.java).apply { action = ACTION_CAPTURE_SAMPLE }
        val samplePendingIntent = PendingIntent.getService(
            this, REQUEST_CAPTURE_SAMPLE, sampleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val autoEnabled = CaptureConfig.isAutoCaptureEnabled(this)
        val autoIntent = Intent(this, CaptureService::class.java).apply {
            action = if (autoEnabled) ACTION_PAUSE_AUTO_CAPTURE else ACTION_RESUME_AUTO_CAPTURE
        }
        val autoPendingIntent = PendingIntent.getService(
            this, REQUEST_TOGGLE_AUTO_CAPTURE, autoIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, CaptureService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, REQUEST_STOP_CAPTURE, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val autoActionTitle = if (autoEnabled) "Pause Auto Capture" else "Start Auto Capture"
        val sampleActionTitle = when {
            nextSampleIsEmpty || (pendingAreaExists && !pendingEmptyExists) -> "Capture Empty Sample"
            pendingAreaExists && pendingEmptyExists -> "Retake Area Sample"
            else -> "Capture Area Sample"
        }
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("MJ Screen Capture")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            // The notification keeps all three controls together: Auto toggle, Stop, and Sample.
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_camera),
                autoActionTitle, autoPendingIntent
            ).build())
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                "Stop Capture", stopPendingIntent
            ).build())
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_media_play),
                sampleActionTitle, samplePendingIntent
            ).build())
            .build()
    }

    private fun startForegroundNotification(content: String) {
        val notification = buildNotification(content)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private fun updateForegroundNotification(content: String) {
        // Notification UI is secondary to the durable image+database save.
        // A notification update failure must never turn a successful save into a
        // false failure or cause the saved crop to be deleted.
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(content))
        } catch (e: Exception) {
            android.util.Log.w("MJScreenCapture", "Could not update foreground notification", e)
        }
    }

    private fun stopCapture() {
        if (stopped) return
        stopped = true
        sampleRequestPending = false
        virtualDisplay?.release()
        virtualDisplay = null
        synchronized(detectionLock) {
            imageReader?.setOnImageAvailableListener(null, null)
            imageReader?.close()
            imageReader = null
            detectionEngine?.release()
            detectionEngine = null
        }
        if (displayListenerRegistered) {
            try { getSystemService(DisplayManager::class.java).unregisterDisplayListener(displayListener) } catch (_: Exception) {}
            displayListenerRegistered = false
        }
        mediaProjection?.let { projection ->
            try { projection.unregisterCallback(mediaProjectionCallback) } catch (_: Exception) {}
            try { projection.stop() } catch (_: Exception) {}
        }
        mediaProjection = null
        captureThread?.quitSafely()
        captureThread = null
        captureHandler = null
        detectionExecutor.shutdown()
        try {
            if (!detectionExecutor.awaitTermination(SAVE_QUEUE_DRAIN_TIMEOUT_SECONDS, TimeUnit.SECONDS)) {
                detectionExecutor.shutdownNow()
            }
        } catch (_: InterruptedException) {
            detectionExecutor.shutdownNow()
            Thread.currentThread().interrupt()
        }
        getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_CAPTURE_RUNNING, false)
            .putBoolean(CaptureConfig.KEY_AUTO_CAPTURE_ENABLED, false)
            .putBoolean(CaptureConfig.KEY_NEXT_SAMPLE_IS_EMPTY, false)
            .putLong(KEY_FRAME_COUNT, frameCount)
            .remove(KEY_ACTIVE_SESSION_ID)
            .apply()
        activeSessionId = -1L
        sendDetectionStatus("Auto Capture paused because Screen Capture stopped.")
        sendStatus("Screen capture stopped.")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun sendStatus(message: String) {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra(EXTRA_STATUS, message))
    }

    private fun sendDetectionStatus(message: String) {
        getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE).edit()
            .putString(CaptureConfig.KEY_LAST_DETECTION_STATUS, message)
            .apply()
        sendBroadcast(Intent(ACTION_DETECTION_STATUS).setPackage(packageName).putExtra(EXTRA_STATUS, message))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Screen Capture", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Screen capture and area-sample controls"
        })
    }

    @Suppress("DEPRECATION")
    private fun getParcelableIntentExtra(intent: Intent, key: String): Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        intent.getParcelableExtra(key, Intent::class.java)
    } else intent.getParcelableExtra(key)

    override fun onDestroy() {
        if (!stopped) stopCapture()
        if (!detectionExecutor.isShutdown) detectionExecutor.shutdownNow()
        captureDatabase?.close()
        captureDatabase = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.mjthakur.screencapture.action.START"
        const val ACTION_STOP = "com.mjthakur.screencapture.action.STOP"
        const val ACTION_CAPTURE_SAMPLE = "com.mjthakur.screencapture.action.CAPTURE_SAMPLE"
        const val ACTION_PREPARE_EMPTY_SAMPLE = "com.mjthakur.screencapture.action.PREPARE_EMPTY_SAMPLE"
        const val ACTION_REFRESH_NOTIFICATION = "com.mjthakur.screencapture.action.REFRESH_NOTIFICATION"
        const val ACTION_RESUME_AUTO_CAPTURE = "com.mjthakur.screencapture.action.RESUME_AUTO_CAPTURE"
        const val ACTION_PAUSE_AUTO_CAPTURE = "com.mjthakur.screencapture.action.PAUSE_AUTO_CAPTURE"
        const val ACTION_STATUS = "com.mjthakur.screencapture.action.STATUS"
        const val ACTION_DETECTION_STATUS = "com.mjthakur.screencapture.action.DETECTION_STATUS"
        const val ACTION_SAMPLE_SAVED = "com.mjthakur.screencapture.action.SAMPLE_SAVED"
        const val ACTION_EMPTY_SAMPLE_SAVED = "com.mjthakur.screencapture.action.EMPTY_SAMPLE_SAVED"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_STATUS = "extra_status"
        const val EXTRA_SAMPLE_PATH = "extra_sample_path"
        const val STATE_PREFS = "capture_app_state"
        const val KEY_CAPTURE_RUNNING = "capture_running"
        const val KEY_FRAME_COUNT = "capture_frame_count"
        const val KEY_ACTIVE_SESSION_ID = "active_capture_session_id"
        const val KEY_PENDING_SAMPLE_PATH = "pending_area_sample_path"
        private const val CHANNEL_ID = "mj_screen_capture"
        private const val NOTIFICATION_ID = 1001
        private const val REQUEST_CAPTURE_SAMPLE = 1002
        private const val REQUEST_TOGGLE_AUTO_CAPTURE = 1003
        private const val REQUEST_STOP_CAPTURE = 1004
        private const val SAMPLE_CAPTURE_DELAY_MS = 900L
        private const val ANALYZE_EVERY_N_FRAMES = 3L
        private const val SAVE_QUEUE_DRAIN_TIMEOUT_SECONDS = 4L
    }
}
