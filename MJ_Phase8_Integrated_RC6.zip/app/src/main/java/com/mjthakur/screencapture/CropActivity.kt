package com.mjthakur.screencapture

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Bitmap
import android.graphics.RectF
import java.io.File

class CropActivity : Activity() {
    private var captureId: Long = -1L
    private var sourceBitmap: Bitmap? = null
    private lateinit var selectionView: AreaSelectionView
    private val database by lazy { CaptureDatabase(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        captureId = intent.getLongExtra(ImageDetailActivity.EXTRA_CAPTURE_ID, -1L)
        val record = database.getCapture(captureId)
        if (record == null) { finish(); return }
        sourceBitmap = ImageUtils.decodeFullFile(record.imagePath)
        val bitmap = sourceBitmap
        if (bitmap == null) {
            Toast.makeText(this, "Could not open image for cropping.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        root.addView(TextView(this).apply { text = "Drag a rectangle around the crop to keep." })
        selectionView = AreaSelectionView(this)
        selectionView.setBitmap(bitmap)
        selectionView.setActiveSide(AreaSelectionView.Side.RIGHT)
        selectionView.setSavedRectangles(null, null)
        root.addView(selectionView, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(Button(this@CropActivity).apply { text = "Apply Crop"; setOnClickListener { applyCrop() } }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(Button(this@CropActivity).apply { text = "Cancel"; setOnClickListener { finish() } }, LinearLayout.LayoutParams(0, -2, 1f))
        })
        setContentView(root)
        InsetsHelper.applySystemBarPadding(root)
    }

    private fun applyCrop() {
        val rect: RectF = selectionView.getRightRect() ?: run {
            Toast.makeText(this, "Draw a crop rectangle first.", Toast.LENGTH_LONG).show()
            return
        }
        val source = sourceBitmap ?: return
        val crop = ImageUtils.crop(source, rect) ?: run {
            Toast.makeText(this, "Invalid crop rectangle.", Toast.LENGTH_LONG).show()
            return
        }
        val record = database.getCapture(captureId) ?: return
        try {
            ImageUtils.saveJpegAtomic(crop, File(record.imagePath))
            setResult(RESULT_OK)
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "Crop failed: ${e.message}", Toast.LENGTH_LONG).show()
        } finally {
            crop.recycle()
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        sourceBitmap?.let { if (!it.isRecycled) it.recycle() }
        sourceBitmap = null
        database.close()
        super.onDestroy()
    }
}
