package com.mjthakur.screencapture

import android.os.Build
import android.view.View
import android.view.WindowInsets

/** Adds system-bar padding while retaining each screen's original padding. */
object InsetsHelper {
    fun applySystemBarPadding(root: View) {
        val initialLeft = root.paddingLeft
        val initialTop = root.paddingTop
        val initialRight = root.paddingRight
        val initialBottom = root.paddingBottom
        root.setOnApplyWindowInsetsListener { view, insets ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(
                    initialLeft + bars.left,
                    initialTop + bars.top,
                    initialRight + bars.right,
                    initialBottom + bars.bottom
                )
            } else {
                @Suppress("DEPRECATION")
                val left = insets.systemWindowInsetLeft
                @Suppress("DEPRECATION")
                val top = insets.systemWindowInsetTop
                @Suppress("DEPRECATION")
                val right = insets.systemWindowInsetRight
                @Suppress("DEPRECATION")
                val bottom = insets.systemWindowInsetBottom
                view.setPadding(
                    initialLeft + left,
                    initialTop + top,
                    initialRight + right,
                    initialBottom + bottom
                )
            }
            insets
        }
        root.requestApplyInsets()
    }
}
