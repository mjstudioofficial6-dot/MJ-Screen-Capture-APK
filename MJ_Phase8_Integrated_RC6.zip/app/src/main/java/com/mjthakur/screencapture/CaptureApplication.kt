package com.mjthakur.screencapture

import android.app.Activity
import android.app.Application
import android.os.Bundle

class CaptureApplication : Application(), Application.ActivityLifecycleCallbacks {
    private var resumedCount = 0

    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(this)
        getSharedPreferences(CaptureConfig.APP_STATE_PREFS, MODE_PRIVATE).edit()
            .putBoolean(CaptureConfig.KEY_APP_FOREGROUND, false)
            .putBoolean(CaptureConfig.KEY_DETECTION_PAUSED, false)
            .apply()
    }

    override fun onActivityResumed(activity: Activity) {
        resumedCount++
        getSharedPreferences(CaptureConfig.APP_STATE_PREFS, MODE_PRIVATE).edit()
            .putBoolean(CaptureConfig.KEY_APP_FOREGROUND, true)
            .putBoolean(CaptureConfig.KEY_DETECTION_PAUSED, false)
            .apply()
    }

    override fun onActivityPaused(activity: Activity) {
        resumedCount = (resumedCount - 1).coerceAtLeast(0)
        getSharedPreferences(CaptureConfig.APP_STATE_PREFS, MODE_PRIVATE).edit()
            .putBoolean(CaptureConfig.KEY_APP_FOREGROUND, resumedCount > 0)
            .apply()
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
    override fun onActivityStarted(activity: Activity) = Unit
    override fun onActivityStopped(activity: Activity) = Unit
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
    override fun onActivityDestroyed(activity: Activity) = Unit
}
