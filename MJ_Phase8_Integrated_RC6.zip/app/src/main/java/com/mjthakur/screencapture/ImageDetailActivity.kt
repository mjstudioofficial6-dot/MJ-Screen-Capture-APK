package com.mjthakur.screencapture

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class ImageDetailActivity : Activity() {
    private var captureId: Long = -1L
    private lateinit var imageView: ImageView
    private lateinit var titleText: TextView
    private val database by lazy { CaptureDatabase(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        captureId = intent.getLongExtra(EXTRA_CAPTURE_ID, -1L)
        if (captureId <= 0L) { finish(); return }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        titleText = TextView(this).apply { textSize = 20f; setTextColor(Color.BLACK) }
        root.addView(titleText)
        imageView = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        root.addView(imageView, LinearLayout.LayoutParams(-1, 0, 1f))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        actions.addView(rowButtons(
            makeButton("Rotate 90°") { rotateImage() },
            makeButton("Crop") { startActivityForResult(Intent(this@ImageDetailActivity, CropActivity::class.java)
                .putExtra(EXTRA_CAPTURE_ID, captureId), REQUEST_CROP) }
        ))
        actions.addView(rowButtons(
            makeButton("Move Earlier") { move(-1) },
            makeButton("Move Later") { move(1) }
        ))
        actions.addView(rowButtons(
            makeButton("Change / Replace") { chooseReplacement() },
            makeButton("Delete") { confirmDelete() }
        ))
        actions.addView(makeButton("Back to History") { finish() })
        root.addView(actions)
        setContentView(root)
        InsetsHelper.applySystemBarPadding(root)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (::imageView.isInitialized) refresh()
    }

    private fun refresh() {
        val record = database.getCapture(captureId)
        if (record == null || !File(record.imagePath).isFile) {
            Toast.makeText(this, "This saved image is no longer available.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        titleText.text = "${record.sequenceNumber.toString().padStart(3, '0')} · ${record.side}"
        val bitmap = ImageUtils.decodeSampledFile(record.imagePath, dp(900), dp(1100))
        if (bitmap != null) imageView.setImageBitmap(bitmap)
    }

    private fun rotateImage() {
        val record = database.getCapture(captureId) ?: return
        try {
            val original = ImageUtils.decodeFullFile(record.imagePath) ?: throw IllegalStateException("Cannot open image")
            val rotated = ImageUtils.rotate(original, 90f)
            if (rotated !== original && !original.isRecycled) original.recycle()
            ImageUtils.saveJpegAtomic(rotated, File(record.imagePath))
            rotated.recycle()
            refresh()
            Toast.makeText(this, "Image rotated.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Rotate failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun move(direction: Int) {
        if (database.moveCapture(captureId, direction)) {
            refresh()
            Toast.makeText(this, "History order updated.", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, if (direction < 0) "Already first." else "Already last.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun chooseReplacement() {
        getSharedPreferences(CaptureConfig.APP_STATE_PREFS, MODE_PRIVATE).edit()
            .putBoolean(CaptureConfig.KEY_DETECTION_PAUSED, true).apply()
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, REQUEST_REPLACE)
    }

    @Deprecated("Image replacement uses the platform document picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQUEST_CROP -> refresh()
            REQUEST_REPLACE -> {
                val uri = data?.data ?: return
                val record = database.getCapture(captureId) ?: return
                val bitmap = ImageUtils.decodeUri(this, uri)
                if (bitmap == null) {
                    Toast.makeText(this, "Could not read selected image.", Toast.LENGTH_LONG).show()
                    return
                }
                try {
                    ImageUtils.saveJpegAtomic(bitmap, File(record.imagePath))
                    refresh()
                    Toast.makeText(this, "Image replaced.", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Replace failed: ${e.message}", Toast.LENGTH_LONG).show()
                } finally {
                    bitmap.recycle()
                }
            }
        }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle("Delete saved image?")
            .setMessage("This permanently deletes the saved crop from this app.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                val path = database.deleteCapture(captureId)
                path?.let { File(it).delete() }
                finish()
            }.show()
    }

    private fun rowButtons(left: Button, right: Button): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        addView(right, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }

    override fun onDestroy() {
        database.close()
        super.onDestroy()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_CAPTURE_ID = "extra_capture_id"
        private const val REQUEST_CROP = 5101
        private const val REQUEST_REPLACE = 5102
    }
}
