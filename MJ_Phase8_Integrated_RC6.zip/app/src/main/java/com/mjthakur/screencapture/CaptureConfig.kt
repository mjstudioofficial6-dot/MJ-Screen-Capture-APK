package com.mjthakur.screencapture

import android.content.Context
import android.content.SharedPreferences
import android.graphics.RectF
import java.io.File

/** Shared, offline-only area/calibration preferences. Coordinates are normalized to 0..1. */
object CaptureConfig {
    const val PREFS_NAME = "capture_areas"
    const val KEY_AREAS_SAVED = "areas_saved"
    const val KEY_EMPTY_CALIBRATION_SAVED = "empty_calibration_saved"
    const val KEY_EMPTY_CALIBRATION_VERSION = "empty_calibration_version"
    const val CURRENT_EMPTY_CALIBRATION_VERSION = 2
    const val KEY_RIGHT_EMPTY_PATH = "right_empty_path"
    const val KEY_LEFT_EMPTY_PATH = "left_empty_path"
    const val KEY_SAMPLE_WIDTH = "sample_width"
    const val KEY_SAMPLE_HEIGHT = "sample_height"
    const val APP_STATE_PREFS = "capture_app_state"
    const val KEY_APP_FOREGROUND = "app_foreground"
    const val KEY_DETECTION_PAUSED = "detection_paused"
    const val KEY_AUTO_CAPTURE_ENABLED = "auto_capture_enabled"
    const val KEY_LAST_DETECTION_STATUS = "last_detection_status"
    const val KEY_NEXT_SAMPLE_IS_EMPTY = "next_sample_is_empty"
    const val KEY_PENDING_EMPTY_SAMPLE_PATH = "pending_empty_sample_path"
    const val KEY_NEXT_SESSION_ID = "next_capture_session_id"
    const val MAX_IMAGES_PER_DECK = 400

    fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun readNormalizedRect(prefs: SharedPreferences, prefix: String): RectF? {
        val leftKey = "${prefix}_left"
        val topKey = "${prefix}_top"
        val rightKey = "${prefix}_right"
        val bottomKey = "${prefix}_bottom"
        if (!prefs.contains(leftKey) || !prefs.contains(topKey) ||
            !prefs.contains(rightKey) || !prefs.contains(bottomKey)) return null
        val rect = RectF(
            prefs.getFloat(leftKey, 0f),
            prefs.getFloat(topKey, 0f),
            prefs.getFloat(rightKey, 0f),
            prefs.getFloat(bottomKey, 0f)
        )
        return rect.takeIf { it.width() > 0.001f && it.height() > 0.001f }
    }

    fun toPixelRect(normalized: RectF, width: Int, height: Int): RectF = RectF(
        normalized.left * width,
        normalized.top * height,
        normalized.right * width,
        normalized.bottom * height
    )

    fun shouldPauseDetection(context: Context): Boolean {
        val state = context.getSharedPreferences(APP_STATE_PREFS, Context.MODE_PRIVATE)
        return state.getBoolean(KEY_APP_FOREGROUND, false) ||
            state.getBoolean(KEY_DETECTION_PAUSED, false) ||
            !state.getBoolean(KEY_AUTO_CAPTURE_ENABLED, false)
    }

    fun isAutoCaptureEnabled(context: Context): Boolean =
        context.getSharedPreferences(APP_STATE_PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_AUTO_CAPTURE_ENABLED, false)

    fun areAreasSaved(context: Context): Boolean {
        val p = prefs(context)
        return p.getBoolean(KEY_AREAS_SAVED, false) &&
            readNormalizedRect(p, "right") != null &&
            readNormalizedRect(p, "left") != null
    }

    fun isDetectionConfigured(context: Context): Boolean {
        val p = prefs(context)
        if (!p.getBoolean(KEY_AREAS_SAVED, false) ||
            !p.getBoolean(KEY_EMPTY_CALIBRATION_SAVED, false) ||
            p.getInt(KEY_EMPTY_CALIBRATION_VERSION, 0) != CURRENT_EMPTY_CALIBRATION_VERSION) return false
        if (readNormalizedRect(p, "right") == null || readNormalizedRect(p, "left") == null) return false
        val rightPath = p.getString(KEY_RIGHT_EMPTY_PATH, null) ?: return false
        val leftPath = p.getString(KEY_LEFT_EMPTY_PATH, null) ?: return false
        return File(rightPath).isFile && File(leftPath).isFile
    }
}
