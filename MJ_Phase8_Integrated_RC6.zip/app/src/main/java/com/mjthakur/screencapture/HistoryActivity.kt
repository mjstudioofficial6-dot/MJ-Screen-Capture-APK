package com.mjthakur.screencapture

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class HistoryActivity : Activity() {
    private lateinit var titleText: TextView
    private lateinit var subtitleText: TextView
    private lateinit var content: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var exportButton: Button
    private lateinit var exportStatus: TextView
    private lateinit var backButton: Button
    private val database by lazy { CaptureDatabase(this) }
    private var selectedDeck: DeckSession? = null
    private var pendingExportRecords: List<CaptureRecord> = emptyList()
    private var pendingExportDeckNames: Map<Long, String> = emptyMap()
    private var pendingExportTitle = "MJ_Screen_Capture_All_Decks.zip"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        titleText = TextView(this).apply {
            text = "Saved Decks"
            textSize = 23f
            setTextColor(Color.BLACK)
        }
        root.addView(titleText)
        subtitleText = TextView(this).apply {
            textSize = 12f
            setPadding(0, dp(3), 0, dp(5))
        }
        root.addView(subtitleText)
        searchInput = EditText(this).apply {
            hint = "Search sequence or side (001, RIGHT, LEFT)"
            setSingleLine(true)
            visibility = View.GONE
        }
        root.addView(searchInput)
        exportButton = Button(this).apply {
            text = "Export All Decks (ZIP)"
            setOnClickListener { requestExportDestination() }
        }
        root.addView(exportButton)
        exportStatus = TextView(this).apply {
            textSize = 11f
            setTextColor(Color.DKGRAY)
        }
        root.addView(exportStatus)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply {
            text = "Refresh"
            setOnClickListener { renderHistory() }
        })
        backButton = Button(this).apply {
            text = "Back"
            setOnClickListener { navigateBack() }
        }
        root.addView(backButton)
        setContentView(root)
        InsetsHelper.applySystemBarPadding(root)
        searchInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = renderHistory()
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })
        renderHistory()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) renderHistory()
    }

    @Deprecated("Use the onBackPressed dispatcher on newer Android versions")
    override fun onBackPressed() {
        if (selectedDeck != null) navigateBack() else super.onBackPressed()
    }

    private fun navigateBack() {
        if (selectedDeck != null) {
            selectedDeck = null
            searchInput.setText("")
            exportStatus.text = ""
            renderHistory()
        } else {
            finish()
        }
    }

    private fun renderHistory() {
        if (!::content.isInitialized) return
        val selection = selectedDeck
        if (selection == null) {
            titleText.text = "Saved Decks"
            subtitleText.text = "Each new Screen Capture start creates a Deck. Pause keeps the same Deck; Stop then Start creates a new one. Maximum ${CaptureConfig.MAX_IMAGES_PER_DECK} images per Deck."
            searchInput.visibility = View.GONE
            exportButton.text = "Export All Decks (ZIP)"
            backButton.text = "Back"
            renderDeckList()
        } else {
            val refreshed = database.getSession(selection.id)
            if (refreshed == null) {
                selectedDeck = null
                renderHistory()
                return
            }
            selectedDeck = refreshed
            titleText.text = refreshed.displayName
            subtitleText.text = "${refreshed.imageCount}/${CaptureConfig.MAX_IMAGES_PER_DECK} images • Small thumbnails; tap any image to open it larger."
            searchInput.visibility = View.VISIBLE
            exportButton.text = "Export This Deck (ZIP)"
            backButton.text = "Back to Decks"
            renderDeckImages(refreshed)
        }
    }

    private fun renderDeckList() {
        content.removeAllViews()
        val sessions = database.getSessions()
        if (sessions.isEmpty()) {
            content.addView(TextView(this).apply {
                text = "No Deck folders yet. Start Screen Capture to create Deck 1. Images will be saved inside that Deck automatically."
                textSize = 15f
                setPadding(dp(5), dp(18), dp(5), dp(18))
            })
            return
        }
        val state = getSharedPreferences(CaptureConfig.APP_STATE_PREFS, MODE_PRIVATE)
        val activeId = if (state.getBoolean(CaptureService.KEY_CAPTURE_RUNNING, false)) state.getLong(CaptureService.KEY_ACTIVE_SESSION_ID, -1L) else -1L
        val nextId = state.getLong(CaptureConfig.KEY_NEXT_SESSION_ID, -1L)
        content.addView(makeButton("Use a New Deck on the Next Start", false) {
            state.edit().remove(CaptureConfig.KEY_NEXT_SESSION_ID).apply()
            Toast.makeText(this, "Next Screen Capture start will create a new Deck.", Toast.LENGTH_SHORT).show()
            renderHistory()
        })
        if (nextId > 0L) {
            val nextDeck = database.getSession(nextId)
            content.addView(TextView(this).apply {
                text = "Next start selected: ${nextDeck?.displayName ?: "new Deck"}"
                textSize = 12f
                setTextColor(Color.rgb(20, 100, 40))
                setPadding(dp(4), dp(3), dp(4), dp(7))
            })
        }
        sessions.forEach { deck ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(6), dp(5), dp(6), dp(5))
                setBackgroundColor(0xFFF1F1F1.toInt())
            }
            card.addView(TextView(this).apply {
                text = deck.displayName
                textSize = 18f
                setTextColor(Color.BLACK)
            })
            card.addView(TextView(this).apply {
                text = "${deck.imageCount}/${CaptureConfig.MAX_IMAGES_PER_DECK} images" +
                    (if (deck.id == activeId) " • ACTIVE SESSION" else "")
                textSize = 12f
                setTextColor(if (deck.id == activeId) Color.rgb(20, 100, 40) else Color.DKGRAY)
            })
            val firstActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            firstActions.addView(makeButton("Open", true) {
                selectedDeck = deck
                searchInput.setText("")
                renderHistory()
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            firstActions.addView(makeButton("Rename", true) { renameDeck(deck) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            card.addView(firstActions)
            val secondActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val isActive = deck.id == activeId
            secondActions.addView(makeButton("Delete", true) {
                if (isActive) {
                    Toast.makeText(this@HistoryActivity, "Stop Capture before deleting the active Deck.", Toast.LENGTH_LONG).show()
                } else confirmDeleteDeck(deck)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            secondActions.addView(makeButton("Use Next", true) {
                if (deck.id <= 0L) {
                    Toast.makeText(this@HistoryActivity, "Previous captures are read-only; choose a Deck folder.", Toast.LENGTH_LONG).show()
                } else if (deck.imageCount >= CaptureConfig.MAX_IMAGES_PER_DECK) {
                    Toast.makeText(this@HistoryActivity, "This Deck is full. Choose a different Deck or a new Deck.", Toast.LENGTH_LONG).show()
                } else {
                    state.edit().putLong(CaptureConfig.KEY_NEXT_SESSION_ID, deck.id).apply()
                    Toast.makeText(this@HistoryActivity, "${deck.displayName} selected for the next Screen Capture start.", Toast.LENGTH_LONG).show()
                    renderHistory()
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            card.addView(secondActions)
            content.addView(card, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            })
        }
    }

    private fun renderDeckImages(deck: DeckSession) {
        content.removeAllViews()
        val allRecords = database.getCapturesForSession(deck.id)
        val query = searchInput.text.toString().trim().uppercase()
        val records = if (query.isEmpty()) allRecords else allRecords.filter { record ->
            record.sequenceNumber.toString().padStart(3, '0').contains(query) ||
                record.sequenceNumber.toString().contains(query) || record.side.uppercase().contains(query)
        }
        if (records.isEmpty()) {
            content.addView(TextView(this).apply {
                text = if (allRecords.isEmpty()) {
                    "This Deck has no saved images yet. Start Auto Capture and let the cards change. Pause keeps this Deck; Stop Capture and start again to make a new Deck."
                } else "No saved images match this search."
                textSize = 14f
                setPadding(dp(4), dp(16), dp(4), dp(16))
            })
            return
        }
        records.chunked(10).forEach { items -> content.addView(rowForRecords(items)) }
    }

    private fun rowForRecords(records: List<CaptureRecord>): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        records.forEach { record ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(1), dp(2), dp(1), dp(2))
                setBackgroundColor(0xFFF1F1F1.toInt())
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    startActivity(Intent(this@HistoryActivity, ImageDetailActivity::class.java)
                        .putExtra(ImageDetailActivity.EXTRA_CAPTURE_ID, record.id))
                }
            }
            val image = ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                val bitmap = ImageUtils.decodeSampledFile(record.imagePath, dp(36), dp(46))
                if (bitmap != null) setImageBitmap(bitmap) else setBackgroundColor(0xFFCCCCCC.toInt())
                contentDescription = "Saved image ${record.sequenceNumber} ${record.side}"
            }
            tile.addView(image, LinearLayout.LayoutParams(-1, dp(46)))
            tile.addView(TextView(this).apply {
                text = "${record.sequenceNumber.toString().padStart(3, '0')} ${if (record.side.equals("LEFT", true)) "L" else "R"}"
                textSize = 7f
                setTextColor(Color.BLACK)
                gravity = Gravity.CENTER
                setSingleLine(true)
                setPadding(0, dp(1), 0, 0)
            })
            row.addView(tile, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(1), dp(1), dp(1), dp(1))
            })
        }
        repeat((10 - records.size).coerceAtLeast(0)) {
            row.addView(LinearLayout(this), LinearLayout.LayoutParams(0, 1, 1f))
        }
        return row
    }

    private fun makeButton(label: String, compact: Boolean = false, action: () -> Unit): Button = Button(this).apply {
        text = label
        if (compact) {
            textSize = 10f
            minimumHeight = dp(34)
            setPadding(dp(2), 0, dp(2), 0)
        }
        setOnClickListener { action() }
    }

    private fun renameDeck(deck: DeckSession) {
        val input = EditText(this).apply {
            setSingleLine(true)
            setText(deck.displayName)
            setSelection(text.length)
            hint = "Deck name"
        }
        AlertDialog.Builder(this)
            .setTitle("Rename Deck")
            .setMessage("You can rename it to Deck 1, Deck 2, or another name. Names must be unique.")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                if (database.renameSession(deck.id, input.text.toString())) {
                    Toast.makeText(this, "Deck renamed.", Toast.LENGTH_SHORT).show()
                    renderHistory()
                } else {
                    Toast.makeText(this, "Name is empty or already used by another Deck.", Toast.LENGTH_LONG).show()
                }
            }
            .show()
    }

    private fun confirmDeleteDeck(deck: DeckSession) {
        AlertDialog.Builder(this)
            .setTitle("Delete ${deck.displayName}?")
            .setMessage("This permanently deletes the entire Deck folder and its ${deck.imageCount} saved image(s). This cannot be undone.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete Deck") { _, _ ->
                val state = getSharedPreferences(CaptureConfig.APP_STATE_PREFS, MODE_PRIVATE)
                if (state.getBoolean(CaptureService.KEY_CAPTURE_RUNNING, false) &&
                    state.getLong(CaptureService.KEY_ACTIVE_SESSION_ID, -1L) == deck.id
                ) {
                    Toast.makeText(this, "Stop Capture before deleting the active Deck.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                database.deleteSession(deck.id).forEach { path -> File(path).delete() }
                File(filesDir, "decks/deck_${deck.id}").deleteRecursively()
                if (state.getLong(CaptureConfig.KEY_NEXT_SESSION_ID, -1L) == deck.id) {
                    state.edit().remove(CaptureConfig.KEY_NEXT_SESSION_ID).apply()
                }
                if (selectedDeck?.id == deck.id) selectedDeck = null
                Toast.makeText(this, "${deck.displayName} deleted.", Toast.LENGTH_SHORT).show()
                renderHistory()
            }
            .show()
    }

    private fun requestExportDestination() {
        pendingExportRecords = selectedDeck?.let { database.getCapturesForSession(it.id) } ?: database.getAllCaptures()
        if (pendingExportRecords.isEmpty()) {
            exportStatus.text = "There are no images to export."
            return
        }
        pendingExportDeckNames = database.getSessions().associate { it.id to it.displayName }
        pendingExportTitle = selectedDeck?.let { "${safeName(it.displayName)}.zip" } ?: "MJ_Screen_Capture_All_Decks.zip"
        getSharedPreferences(CaptureConfig.APP_STATE_PREFS, MODE_PRIVATE).edit()
            .putBoolean(CaptureConfig.KEY_DETECTION_PAUSED, true).apply()
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_TITLE, pendingExportTitle)
        }
        startActivityForResult(intent, REQUEST_EXPORT)
    }

    @Deprecated("Export destination is selected through Android's document picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_EXPORT || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val records = pendingExportRecords
        exportButton.isEnabled = false
        exportStatus.text = "Exporting ${records.size} image(s)..."
        Thread({
            var exported = 0
            var failure: String? = null
            try {
                val output = applicationContext.contentResolver.openOutputStream(uri)
                    ?: throw IllegalStateException("Could not open the chosen export location")
                ZipOutputStream(output.buffered()).use { zip ->
                    val csv = buildString {
                        append("deck,sequence,side,image_file\n")
                        records.forEach { record ->
                            val deckName = pendingExportDeckNames[record.sessionId] ?: "Previous captures"
                            val filename = "${record.sequenceNumber.toString().padStart(3, '0')}_${record.side}.jpg"
                            append(csvEscape(deckName)).append(',')
                                .append(record.sequenceNumber).append(',')
                                .append(record.side).append(',')
                                .append(filename).append('\n')
                        }
                    }
                    zip.putNextEntry(ZipEntry("history.csv"))
                    zip.write(csv.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                    records.forEach { record ->
                        val file = File(record.imagePath)
                        if (file.isFile) {
                            val deckName = pendingExportDeckNames[record.sessionId] ?: "Previous captures"
                            val name = "${safeName(deckName)}/${record.sequenceNumber.toString().padStart(3, '0')}_${record.side}.jpg"
                            zip.putNextEntry(ZipEntry(name))
                            file.inputStream().buffered().use { it.copyTo(zip) }
                            zip.closeEntry()
                            exported++
                        }
                    }
                }
            } catch (e: Exception) {
                failure = e.message ?: "Unknown export error"
            }
            runOnUiThread {
                exportButton.isEnabled = true
                exportStatus.text = if (failure == null) {
                    "Export complete: $exported image(s), grouped by Deck, plus history.csv."
                } else "Export failed: $failure"
            }
        }, "MJ-HistoryExport").start()
    }

    private fun safeName(name: String): String = name.trim()
        .replace(Regex("[^A-Za-z0-9 _-]"), "_")
        .replace(Regex("\\s+"), "_")
        .take(50)
        .ifBlank { "Deck" }

    private fun csvEscape(value: String): String = "\"" + value.replace("\"", "\"\"") + "\""

    override fun onDestroy() {
        database.close()
        super.onDestroy()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object { private const val REQUEST_EXPORT = 5201 }
}
