package com.mjthakur.screencapture

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Offline settings for adding/replacing the no-card empty background reference. */
class SettingsActivity : Activity() {
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "Capture Settings"
            textSize = 24f
            setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "Empty background samples are negative references only. They are never saved to History. Auto Capture saves only crops inside the saved Right and Left rectangles when their appearance differs from the empty baseline."
            textSize = 14f
            setPadding(0, dp(8), 0, dp(12))
        })
        statusText = TextView(this).apply { textSize = 14f }
        root.addView(statusText)

        root.addView(Button(this).apply {
            text = "Capture / Replace Empty Background Sample"
            setOnClickListener { prepareEmptySample() }
        }, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(14)
        })
        root.addView(Button(this).apply {
            text = "Clear Empty Baseline"
            setOnClickListener { clearEmptyBaseline() }
        })
        root.addView(Button(this).apply {
            text = "Back"
            setOnClickListener { finish() }
        })
        setContentView(root)
        InsetsHelper.applySystemBarPadding(root)
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::statusText.isInitialized) refreshStatus()
        openPendingEmptySampleIfAny()
    }

    private fun openPendingEmptySampleIfAny() {
        val state = getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE)
        val path = state.getString(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH, null)
        if (!path.isNullOrBlank() && File(path).isFile) {
            state.edit().remove(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH).apply()
            startActivity(
                Intent(this, EmptySampleActivity::class.java)
                    .putExtra(EmptySampleActivity.EXTRA_SAMPLE_PATH, path)
            )
        } else if (!path.isNullOrBlank()) {
            state.edit().remove(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH).apply()
            Toast.makeText(this, "Empty sample file was not found. Capture it again.", Toast.LENGTH_LONG).show()
        }
    }

    private fun prepareEmptySample() {
        val running = getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE)
            .getBoolean(CaptureService.KEY_CAPTURE_RUNNING, false)
        if (!running) {
            Toast.makeText(this, "Start Screen Capture first.", Toast.LENGTH_LONG).show()
            return
        }
        if (!CaptureConfig.areAreasSaved(this)) {
            Toast.makeText(this, "Save both Right and Left areas first.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_PREPARE_EMPTY_SAMPLE))
            Toast.makeText(
                this,
                "Now show the target video with NO card in either selected area, expand the MJ notification and tap Capture Empty Sample. Then return to MJ Screen Capture to preview and save it.",
                Toast.LENGTH_LONG
            ).show()
            statusText.text = "Waiting for an empty sample: show the target video with no card in either selected area, then use Capture Empty Sample in the notification."
        } catch (e: Exception) {
            Toast.makeText(this, "Could not prepare empty sample: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun clearEmptyBaseline() {
        val prefs = CaptureConfig.prefs(this)
        val oldPaths = listOf(
            prefs.getString(CaptureConfig.KEY_RIGHT_EMPTY_PATH, null),
            prefs.getString(CaptureConfig.KEY_LEFT_EMPTY_PATH, null)
        ).filterNotNull().distinct()
        val saved = prefs.edit()
            .remove(CaptureConfig.KEY_RIGHT_EMPTY_PATH)
            .remove(CaptureConfig.KEY_LEFT_EMPTY_PATH)
            .putBoolean(CaptureConfig.KEY_EMPTY_CALIBRATION_SAVED, false)
            .remove(CaptureConfig.KEY_EMPTY_CALIBRATION_VERSION)
            .commit()
        if (!saved) {
            Toast.makeText(this, "Could not clear empty baseline settings.", Toast.LENGTH_LONG).show()
            return
        }
        oldPaths.forEach { File(it).delete() }
        getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE).edit()
            .putBoolean(CaptureConfig.KEY_AUTO_CAPTURE_ENABLED, false)
            .putBoolean(CaptureConfig.KEY_NEXT_SAMPLE_IS_EMPTY, false)
            .apply()
        refreshNotificationIfCaptureRunning()
        refreshStatus()
        Toast.makeText(this, "Empty baseline cleared. Capture a new no-card sample before starting Auto Capture.", Toast.LENGTH_LONG).show()
    }

    private fun refreshStatus() {
        val areaSaved = CaptureConfig.areAreasSaved(this)
        val calibrated = CaptureConfig.isDetectionConfigured(this)
        statusText.text = when {
            !areaSaved -> "Status: Right/Left areas are not saved. Use Capture Area first."
            calibrated -> "Status: Empty baseline is saved for BOTH selected areas. It is excluded from History. You can capture a replacement whenever the background changes."
            else -> "Status: Areas are saved, but the empty background baseline is missing. Capture a no-card sample to enable Auto Capture."
        }
    }

    private fun refreshNotificationIfCaptureRunning() {
        val running = getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE)
            .getBoolean(CaptureService.KEY_CAPTURE_RUNNING, false)
        if (running) {
            try { startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_REFRESH_NOTIFICATION)) }
            catch (_: Exception) { }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
