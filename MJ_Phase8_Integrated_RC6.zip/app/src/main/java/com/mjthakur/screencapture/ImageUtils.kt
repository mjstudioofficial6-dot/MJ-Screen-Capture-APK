package com.mjthakur.screencapture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.RectF
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import kotlin.math.max

object ImageUtils {
    fun crop(source: Bitmap, rect: RectF): Bitmap? {
        if (source.width <= 0 || source.height <= 0) return null
        val left = rect.left.toInt().coerceIn(0, source.width - 1)
        val top = rect.top.toInt().coerceIn(0, source.height - 1)
        val right = rect.right.toInt().coerceIn(left + 1, source.width)
        val bottom = rect.bottom.toInt().coerceIn(top + 1, source.height)
        if (right - left < 1 || bottom - top < 1) return null
        return Bitmap.createBitmap(source, left, top, right - left, bottom - top)
    }

    fun saveJpegAtomic(bitmap: Bitmap, target: File, quality: Int = 94) {
        target.parentFile?.mkdirs()
        val temp = File(target.parentFile, target.name + ".tmp")
        FileOutputStream(temp).use { out ->
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)) {
                throw IllegalStateException("JPEG encoding failed")
            }
            out.fd.sync()
        }
        try {
            Files.move(
                temp.toPath(), target.toPath(),
                StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING
            )
        } catch (_: Exception) {
            // Some document/filesystem implementations do not support ATOMIC_MOVE.
            // Keep a recoverable backup when replacing an existing image.
            val backup = File(target.parentFile, target.name + ".bak")
            if (backup.exists() && !backup.delete()) {
                temp.delete()
                throw IllegalStateException("Could not clear the old-image backup")
            }
            val hadOriginal = target.exists()
            if (hadOriginal && !target.renameTo(backup)) {
                temp.delete()
                throw IllegalStateException("Could not protect the original image before replacement")
            }
            try {
                if (!temp.renameTo(target)) temp.copyTo(target, overwrite = true)
                backup.delete()
            } catch (e: Exception) {
                if (target.exists()) target.delete()
                if (hadOriginal) backup.renameTo(target)
                temp.delete()
                throw e
            }
        }
        if (temp.exists()) temp.delete()
    }

    fun decodeSampledFile(path: String, reqWidth: Int, reqHeight: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val options = BitmapFactory.Options().apply {
            inSampleSize = calculateInSampleSize(bounds.outWidth, bounds.outHeight, reqWidth, reqHeight)
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        return BitmapFactory.decodeFile(path, options)
    }

    fun decodeFullFile(path: String): Bitmap? = BitmapFactory.decodeFile(path)

    fun decodeUri(context: Context, uri: Uri, maxDimension: Int = 1800): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val options = BitmapFactory.Options().apply {
            inSampleSize = calculateInSampleSize(bounds.outWidth, bounds.outHeight, maxDimension, maxDimension)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }

    fun rotate(bitmap: Bitmap, degrees: Float): Bitmap {
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun calculateInSampleSize(width: Int, height: Int, reqWidth: Int, reqHeight: Int): Int {
        var sample = 1
        while (width / (sample * 2) >= max(1, reqWidth) || height / (sample * 2) >= max(1, reqHeight)) {
            sample *= 2
        }
        return sample
    }
}
