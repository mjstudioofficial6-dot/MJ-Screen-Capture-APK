# MJ Screen Capture — Integrated Phase 8 Release Candidate 4

RC4 is an integrated, offline Android test candidate. Phase 1 and Phase 2 remain locked successful baselines; RC4 extends the RC3 source with the explicit user workflow below. This archive has passed static validation only. GitHub Actions must build it and the phone must pass practical tests before it is considered successful.

## What was fixed for the reported problem

The user confirmed that screen capture and frame counting work, the area editor opens, and History/Reference screens open, but the screen remains empty in History because automatic detection/save is not activated or no appearance is detected. RC4 now distinguishes three separate things:

1. **Area selection sample** — a full-screen frozen sample used only to draw the Right and Left rectangles. It is private and never inserted into History.
2. **Empty background sample** — the selected Right and Left crops when there are no cards in either area. These are negative references used to decide that the areas are empty. They are private and never inserted into History.
3. **Live target frames** — while Auto Capture is explicitly ON and a different app is foreground, only the pixels inside the two selected rectangles are compared with their empty references. A stable significant appearance queues exactly one crop for that appearance; it stays locked until the area looks empty again.

This is visual presence/absence comparison, not card identification. It cannot mathematically guarantee that every changed graphic is a card. Rectangles must tightly cover where the card itself appears, not betting counters, text labels, changing scores, animated decorations, or unrelated UI.

## Notification controls

The persistent MJ Screen Capture foreground notification has three actions in the same notification:

- **Start Auto Capture / Pause Auto Capture** — toggles detection/saving but does not stop screen frame capture.
- **Stop Capture** — ends the MediaProjection session and removes the foreground notification.
- **Capture Area Sample** or **Capture Empty Sample** — action label changes according to the sample mode prepared in Settings.

Android/phone notification UI may show actions only after expanding the notification. After an area sample is captured, the notification remains active with Auto Capture and Stop controls. Auto Capture cannot start until the rectangles and both empty references are valid.

## Area setup and automatic empty calibration

1. Start Screen Capture and grant Entire Screen sharing permission.
2. Tap Capture Area Sample in the notification while the target video is visible; return to the app to open the frozen screenshot.
3. Draw a tight Right and Left rectangle around the exact card display positions. Use Test Right and Test Left; each preview must show the region where the card itself appears.
4. Tap **Save Areas / Auto-Calibrate Empty**. The dialog offers:
   - **Save + Calibrate Empty** — use only if both rectangles currently contain no card. The two selected crops are saved as empty references at the same time as the areas, so there is no separate calibration button.
   - **Save Areas Only** — use if a card is visible in the sample or if the sample is not suitable as an empty reference. The detector stays not-ready until a no-card sample is captured in Settings.
5. The app's own settings has **Capture / Replace Empty Background Sample**. It arms the next sample action in the notification. Go to the target video when both selected regions have no card and tap **Capture Empty Sample** in the same persistent notification. Return to MJ Screen Capture Settings; a preview shows the full sample and separate Right/Left crops. Only press **USE AS EMPTY BACKGROUND** when both crop previews are empty. The new pair replaces the previous empty references. Discard does not change the existing references.
6. Once areas and empty references are saved, the notification's Start Auto Capture action is ready.

## Runtime capture behavior

- Screen Capture starts using Android MediaProjection; fresh OS permission is requested per session.
- MediaProjection callback is registered before `createVirtualDisplay()` for Android 14+ compatibility.
- The ongoing foreground service contains start/pause auto, sample capture and Stop actions.
- Screen capture frame count increments independently from Auto Capture.
- Auto Capture is initially paused for every new screen-capture session.
- While Auto Capture is ON, each side is sampled every third received frame. A side requires 3 consecutive changed samples before one crop is saved; after a save it must be empty for 2 consecutive analyzed samples before re-arming.
- If both sides become stable on the same analyzed frame, RIGHT is queued first. Each side has an independent presence state.
- Images saved during detection contain only the crop inside their respective selected rectangles and are written to app-private storage. History numbering is sourced from SQLite order.
- The blank baseline and area-selection samples are never inserted in History.
- Stop Capture disables Auto Capture, stops MediaProjection, releases VirtualDisplay/ImageReader and worker resources, and removes the notification.
- If resolution/orientation changes during capture, the service stops capture instead of using stale coordinates. Restart capture and recheck the selected areas.

## Settings / History / Reference

- Settings can capture/replace or clear the no-card baseline. Clearing it disables Auto Capture until a new empty reference is saved.
- History is stored in SQLite with sequential IDs, side and private image path. It supports number/side search, viewing/editing, crop/rotate, move, replace, delete and ZIP+CSV export.
- The optional 52-slot A–K × four-suit Reference library is manual storage only. It does not affect the detector and never makes the APK recognize card ranks or suits.

## Offline and Android baseline

- Native Android, Kotlin + XML Views; package `com.mjthakur.screencapture`.
- `compileSdk = 36`, `targetSdk = 36`, `minSdk = 26`, JDK 17, AGP 9.4.0, Gradle 9.6.0.
- AGP 9 built-in Kotlin is used. Do not add `org.jetbrains.kotlin.android`.
- No INTERNET permission, Firebase, login, server, cloud AI, OCR or YOLO. The separate source-video application may require its own connection to play a stream; MJ Screen Capture itself makes no network requests.
- Images, area samples, empty references, and database remain inside app-private storage; there is no automatic gallery export.

## Phase 8 manual acceptance test

### Install and baseline
- [ ] GitHub Actions build is green and uploads `MJ-Screen-Capture-Phase8-RC4-debug-APK`.
- [ ] Install on target phone; Start Screen Capture consent prompt appears, frame count increases, and Stop Capture works.
- [ ] Expand notification. Verify Auto Capture, Stop Capture, and sample action are present in the same notification.

### Area and empty baseline
- [ ] Capture an area-selection sample while the target video is visible; editor opens the right frozen frame.
- [ ] Select exact Right/Left card areas. Test previews show the cards' expected appearance zones, not labels/counters.
- [ ] With no card in both areas, use Save + Calibrate Empty and verify Auto Capture becomes ready.
- [ ] Alternatively, Save Areas Only; use Settings to prepare/capture/preview a no-card sample; accept it and verify the baseline status changes to saved.
- [ ] Confirm area-selection and empty samples never appear in History.
- [ ] Replace the empty baseline from Settings and verify current baseline stays intact if the new sample is discarded.

### Auto capture
- [ ] Press Start Auto Capture in the notification; verify the notification changes to Pause Auto Capture.
- [ ] Switch to the target video while capture remains active.
- [ ] For a single appearance in the Right area, confirm exactly one crop containing only the Right selected region is added to History.
- [ ] Repeat Left. Confirm the left crop and side label.
- [ ] Leave a card visible for several seconds; confirm no duplicate saves while it remains visible.
- [ ] Remove the card; wait until the area returns to empty; show another card and confirm one new save.
- [ ] Move/change unrelated parts outside the two selected rectangles; confirm they do not get saved.
- [ ] Pause Auto Capture from notification and confirm frame count continues but History does not grow. Resume and verify saving works.
- [ ] Stop Capture from the notification; confirm screen sharing stops and capture notification disappears.

### 10 / 50 / 100 appearance test
- [ ] Run 10 rounds first and compare expected vs actual saves (if each round has one Right and one Left appearance, expected = 20).
- [ ] Only after 10 rounds pass, run 50 rounds; check duplicates/missed items/order and app stability.
- [ ] Only after 50 rounds pass, run 100 rounds; review all mismatches.

### History, Reference and offline
- [ ] Search by sequence/side; rotate/crop/move/replace/delete a test record.
- [ ] Export ZIP; confirm images and history CSV are present.
- [ ] Add/replace optional Reference images; confirm detection behavior does not depend on them.
- [ ] Verify the built APK does not request INTERNET permission.

## Acceptance rule

This RC is not considered successful merely because the archive or YAML validates. It passes only after GitHub Actions builds it and the user verifies the above tests on the target phone. If it fails, fix the exact reported log/behavior while preserving the locked Phase 1 and Phase 2 baseline.
