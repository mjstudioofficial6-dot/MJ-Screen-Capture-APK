package com.mjthakur.screencapture

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var autoCaptureStatusText: TextView
    private lateinit var detectionDiagnosticsText: TextView
    private lateinit var autoCaptureButton: Button
    private lateinit var projectionManager: MediaProjectionManager
    private var areaSetupOpening = false
    private var receiverRegistered = false

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                CaptureService.ACTION_STATUS -> {
                    statusText.text = intent.getStringExtra(CaptureService.EXTRA_STATUS) ?: return
                }
                CaptureService.ACTION_DETECTION_STATUS -> {
                    detectionDiagnosticsText.text = intent.getStringExtra(CaptureService.EXTRA_STATUS)
                        ?: getLastDetectionStatus()
                    renderAutoCaptureUi()
                }
                CaptureService.ACTION_SAMPLE_SAVED -> {
                    statusText.text = "Area sample captured. Returning to select the areas."
                }
                CaptureService.ACTION_EMPTY_SAMPLE_SAVED -> {
                    statusText.text = "Empty background sample captured. Return to MJ Screen Capture to review and save it."
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        InsetsHelper.applySystemBarPadding(findViewById(R.id.mainRoot))
        statusText = findViewById(R.id.statusText)
        autoCaptureStatusText = findViewById(R.id.autoCaptureStatusText)
        detectionDiagnosticsText = findViewById(R.id.detectionDiagnosticsText)
        autoCaptureButton = findViewById(R.id.autoCaptureButton)
        projectionManager = getSystemService(MediaProjectionManager::class.java)
        statusText.text = "Screen capture stopped. Start capture, select both areas, then save a no-card empty background sample."

        findViewById<Button>(R.id.startCaptureButton).setOnClickListener { requestScreenCapturePermission() }
        findViewById<Button>(R.id.stopCaptureButton).setOnClickListener { stopCapture() }
        autoCaptureButton.setOnClickListener { toggleAutoCapture() }
        findViewById<Button>(R.id.captureAreaButton).setOnClickListener {
            openPendingAreaSampleIfAny()
            if (areaSetupOpening) return@setOnClickListener
            if (!isCaptureRunning()) {
                Toast.makeText(this, "Start Capture first.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(
                    this,
                    "Open the target video, then tap Capture Area Sample in the MJ Screen Capture notification.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        findViewById<Button>(R.id.historyButton).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<Button>(R.id.referenceButton).setOnClickListener {
            startActivity(Intent(this, ReferenceActivity::class.java))
        }
        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        registerStatusReceiver()
        renderAutoCaptureUi()
    }

    override fun onResume() {
        super.onResume()
        areaSetupOpening = false
        if (::statusText.isInitialized && isCaptureRunning()) {
            val prefs = getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE)
            val frames = prefs.getLong(CaptureService.KEY_FRAME_COUNT, 0L)
            statusText.text = "Screen capture running. Frames received: $frames"
        } else if (::statusText.isInitialized) {
            statusText.text = "Screen capture stopped."
        }
        renderAutoCaptureUi()
        openPendingAreaSampleIfAny()
        openPendingEmptySampleIfAny()
    }

    private fun toggleAutoCapture() {
        if (!isCaptureRunning()) {
            Toast.makeText(this, "Start Screen Capture first.", Toast.LENGTH_LONG).show()
            renderAutoCaptureUi()
            return
        }
        val enabled = CaptureConfig.isAutoCaptureEnabled(this)
        if (!enabled && !CaptureConfig.isDetectionConfigured(this)) {
            val message = "Not ready: save both areas and use a verified empty background sample first."
            autoCaptureStatusText.text = message
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            return
        }
        val serviceIntent = Intent(this, CaptureService::class.java).apply {
            action = if (enabled) CaptureService.ACTION_PAUSE_AUTO_CAPTURE else CaptureService.ACTION_RESUME_AUTO_CAPTURE
        }
        try {
            startService(serviceIntent)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not change Auto Capture: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderAutoCaptureUi() {
        if (!::autoCaptureButton.isInitialized) return
        val state = getSharedPreferences(CaptureConfig.APP_STATE_PREFS, MODE_PRIVATE)
        val running = isCaptureRunning()
        val configured = CaptureConfig.isDetectionConfigured(this)
        val enabled = CaptureConfig.isAutoCaptureEnabled(this)
        autoCaptureButton.text = if (enabled) "Pause Auto Capture" else "Start Auto Capture"
        autoCaptureStatusText.text = when {
            !running -> "Auto Capture unavailable: start Screen Capture first."
            !configured -> "Auto Capture NOT READY: save both areas and a verified no-card empty background sample."
            enabled -> "Auto Capture ON. Detection pauses while MJ Screen Capture is open; switch to the target video."
            else -> "Auto Capture PAUSED. Tap Start Auto Capture, then switch to the target video."
        }
        val lastStatus = state.getString(CaptureConfig.KEY_LAST_DETECTION_STATUS, null)
        detectionDiagnosticsText.text = when {
            !running -> "Detection diagnostics: screen capture is stopped."
            !configured -> "Detection diagnostics: waiting for valid saved areas and empty references."
            !enabled -> "Detection diagnostics: paused; no new samples are being analyzed." +
                (if (!lastStatus.isNullOrBlank()) "\nLast result: $lastStatus" else "")
            !lastStatus.isNullOrBlank() -> lastStatus
            else -> "Detection diagnostics: waiting for the first analyzed target-video sample."
        }
        val savedCount = try {
            val db = CaptureDatabase(this)
            try { db.getAllCaptures().size } finally { db.close() }
        } catch (_: Exception) {
            -1
        }
        if (savedCount >= 0) {
            val countLine = "Saved images in History: $savedCount"
            val previous = detectionDiagnosticsText.text?.toString().orEmpty()
            val mainLine = previous.substringBefore("\nSaved images in History:")
            detectionDiagnosticsText.text = "$mainLine\n$countLine"
        }
    }

    private fun getLastDetectionStatus(): String = getSharedPreferences(
        CaptureConfig.APP_STATE_PREFS, MODE_PRIVATE
    ).getString(CaptureConfig.KEY_LAST_DETECTION_STATUS, "Detection diagnostics: waiting for a sample.")
        ?: "Detection diagnostics: waiting for a sample."

    private fun requestScreenCapturePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_POST_NOTIFICATIONS)
            return
        }
        launchScreenCaptureConsent()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_POST_NOTIFICATIONS) {
            if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(
                    this,
                    "Enable notifications to use Capture Area Sample and Auto Capture controls.",
                    Toast.LENGTH_LONG
                ).show()
            }
            launchScreenCaptureConsent()
        }
    }

    private fun launchScreenCaptureConsent() {
        try {
            startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_MEDIA_PROJECTION)
        } catch (e: Exception) {
            statusText.text = "Unable to start screen capture: ${e.message ?: "unknown error"}"
            Toast.makeText(this, "Screen capture permission could not be opened.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("MediaProjection consent returns through this compatibility callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_MEDIA_PROJECTION) return
        if (resultCode != RESULT_OK || data == null) {
            statusText.text = "Screen capture permission was cancelled."
            return
        }
        val serviceIntent = Intent(this, CaptureService::class.java).apply {
            action = CaptureService.ACTION_START
            putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(CaptureService.EXTRA_RESULT_DATA, data)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
        statusText.text = "Starting screen capture..."
    }

    private fun stopCapture() {
        val intent = Intent(this, CaptureService::class.java).apply { action = CaptureService.ACTION_STOP }
        try {
            startService(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not stop capture: ${e.message}", Toast.LENGTH_LONG).show()
        }
        statusText.text = "Stopping screen capture..."
    }

    private fun isCaptureRunning(): Boolean = getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE)
        .getBoolean(CaptureService.KEY_CAPTURE_RUNNING, false)

    private fun openPendingAreaSampleIfAny() {
        if (areaSetupOpening) return
        val state = getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE)
        val path = state.getString(CaptureService.KEY_PENDING_SAMPLE_PATH, null)
        if (!path.isNullOrBlank() && File(path).isFile) {
            state.edit().remove(CaptureService.KEY_PENDING_SAMPLE_PATH).apply()
            areaSetupOpening = true
            startActivity(Intent(this, AreaSetupActivity::class.java).putExtra(AreaSetupActivity.EXTRA_SAMPLE_PATH, path))
        } else if (!path.isNullOrBlank()) {
            state.edit().remove(CaptureService.KEY_PENDING_SAMPLE_PATH).apply()
        }
    }

    private fun openPendingEmptySampleIfAny() {
        if (areaSetupOpening) return
        val state = getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE)
        val path = state.getString(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH, null)
        if (!path.isNullOrBlank() && File(path).isFile) {
            state.edit().remove(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH).apply()
            startActivity(
                Intent(this, EmptySampleActivity::class.java)
                    .putExtra(EmptySampleActivity.EXTRA_SAMPLE_PATH, path)
            )
        } else if (!path.isNullOrBlank()) {
            state.edit().remove(CaptureConfig.KEY_PENDING_EMPTY_SAMPLE_PATH).apply()
            Toast.makeText(this, "The pending empty sample file was not found. Capture it again from Settings.", Toast.LENGTH_LONG).show()
        }
    }

    private fun registerStatusReceiver() {
        val filter = IntentFilter().apply {
            addAction(CaptureService.ACTION_STATUS)
            addAction(CaptureService.ACTION_DETECTION_STATUS)
            addAction(CaptureService.ACTION_SAMPLE_SAVED)
            addAction(CaptureService.ACTION_EMPTY_SAMPLE_SAVED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) registerReceiver(statusReceiver, filter, RECEIVER_NOT_EXPORTED)
        else {
            @Suppress("DEPRECATION")
            registerReceiver(statusReceiver, filter)
        }
        receiverRegistered = true
    }

    override fun onDestroy() {
        if (receiverRegistered) unregisterReceiver(statusReceiver)
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_MEDIA_PROJECTION = 4101
        private const val REQUEST_POST_NOTIFICATIONS = 4102
    }
}
