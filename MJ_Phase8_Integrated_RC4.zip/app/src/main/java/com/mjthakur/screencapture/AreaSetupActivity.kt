package com.mjthakur.screencapture

import android.app.Activity
import android.content.Intent
import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.math.max
import kotlin.math.min

class AreaSetupActivity : Activity() {
    private lateinit var areaView: AreaSelectionView
    private lateinit var instructionText: TextView
    private lateinit var prefs: android.content.SharedPreferences
    private var sampleBitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_area_setup)
        InsetsHelper.applySystemBarPadding(findViewById(R.id.areaSetupRoot))

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        areaView = findViewById(R.id.areaSelectionView)
        instructionText = findViewById(R.id.areaInstructionText)

        val path = intent.getStringExtra(EXTRA_SAMPLE_PATH)
        if (path.isNullOrBlank()) {
            Toast.makeText(this, "Capture sample is missing.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        sampleBitmap = BitmapFactory.decodeFile(path)
        val bitmap = sampleBitmap
        if (bitmap == null) {
            Toast.makeText(this, "Could not open capture sample.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        areaView.setBitmap(bitmap)
        areaView.setSavedRectangles(
            loadRect("right", bitmap.width, bitmap.height),
            loadRect("left", bitmap.width, bitmap.height)
        )
        areaView.setActiveSide(AreaSelectionView.Side.RIGHT)
        instructionText.text = "Right selected: draw tightly around where the RIGHT card appears, not labels/scores. Test Right must show the card area."

        findViewById<Button>(R.id.setRightButton).setOnClickListener {
            areaView.setActiveSide(AreaSelectionView.Side.RIGHT)
            instructionText.text = "Right selected: draw tightly around where the RIGHT card appears, not labels/scores. Test Right must show the card area."
        }
        findViewById<Button>(R.id.setLeftButton).setOnClickListener {
            areaView.setActiveSide(AreaSelectionView.Side.LEFT)
            instructionText.text = "Left selected: draw tightly around where the LEFT card appears, not labels/scores. Test Left must show the card area."
        }
        findViewById<Button>(R.id.testRightButton).setOnClickListener {
            previewArea("right", areaView.getRightRect())
        }
        findViewById<Button>(R.id.testLeftButton).setOnClickListener {
            previewArea("left", areaView.getLeftRect())
        }
        findViewById<Button>(R.id.saveAreasButton).setOnClickListener {
            showSaveOptions()
        }
        findViewById<Button>(R.id.resetAreasButton).setOnClickListener {
            resetAreas()
        }
    }

    private fun validRectangles(): Pair<RectF, RectF>? {
        val right = areaView.getRightRect()
        val left = areaView.getLeftRect()
        if (right == null || left == null || right.width() < 20f || right.height() < 20f ||
            left.width() < 20f || left.height() < 20f
        ) {
            Toast.makeText(this, "Set both Right and Left areas first.", Toast.LENGTH_LONG).show()
            return null
        }
        return right to left
    }

    private fun previewArea(label: String, rect: RectF?) {
        val source = sampleBitmap ?: return
        if (rect == null || rect.width() < 20f || rect.height() < 20f) {
            Toast.makeText(this, "Set the ${label.replaceFirstChar { it.uppercase() }} Area first.", Toast.LENGTH_LONG).show()
            return
        }
        val crop = cropBitmap(source, rect)
        if (crop == null) {
            Toast.makeText(this, "Could not preview this area.", Toast.LENGTH_LONG).show()
            return
        }
        val imageView = ImageView(this).apply {
            setImageBitmap(crop)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(260)
            )
        }
        AlertDialog.Builder(this)
            .setTitle("${label.replaceFirstChar { it.uppercase() }} Area Preview")
            .setMessage("Preview only; this does not add an item to History.")
            .setView(imageView)
            .setPositiveButton("Close", null)
            .setOnDismissListener { if (!crop.isRecycled) crop.recycle() }
            .show()
    }

    private fun showSaveOptions() {
        val rectangles = validRectangles() ?: return
        val source = sampleBitmap ?: return
        AlertDialog.Builder(this)
            .setTitle("Save selected areas")
            .setMessage(
                "Are BOTH selected areas completely empty (no card visible) in this frozen sample?\n\n" +
                    "YES: save both areas and automatically use these two crops as the empty/no-save baseline.\n\n" +
                    "NO: save only the area coordinates. Later open Settings and capture a separate empty background sample.\n\n" +
                    "The empty sample is never added to History. Only the selected Right/Left crops can be saved during Auto Capture."
            )
            .setPositiveButton("Save + Calibrate Empty") { _, _ ->
                saveAreasAndCalibrate(rectangles.first, rectangles.second, source)
            }
            .setNeutralButton("Save Areas Only") { _, _ ->
                saveAreasOnly(rectangles.first, rectangles.second, source.width, source.height)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun saveAreasOnly(right: RectF, left: RectF, width: Int, height: Int) {
        val changed = areasDifferFromSaved(right, left, width, height)
        if (changed) clearEmptyReferences()
        persistAreas(right, left, width, height)
        prefs.edit().putBoolean(CaptureConfig.KEY_AREAS_SAVED, true).apply()
        refreshCaptureNotification()
        val message = if (changed) {
            "Areas saved only. Use Settings to capture a no-card empty background sample before Auto Capture."
        } else if (CaptureConfig.isDetectionConfigured(this)) {
            "Right and Left areas saved; existing empty calibration kept."
        } else {
            "Areas saved only. Capture an empty background sample in Settings before Auto Capture."
        }
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        finish()
    }

    private fun saveAreasAndCalibrate(right: RectF, left: RectF, source: Bitmap) {
        var rightCrop: Bitmap? = null
        var leftCrop: Bitmap? = null
        val folder = File(filesDir, "capture_calibration").apply { mkdirs() }
        val stamp = System.currentTimeMillis()
        val rightFile = File(folder, "right_empty_$stamp.jpg")
        val leftFile = File(folder, "left_empty_$stamp.jpg")
        val oldRightPath = prefs.getString(CaptureConfig.KEY_RIGHT_EMPTY_PATH, null)
        val oldLeftPath = prefs.getString(CaptureConfig.KEY_LEFT_EMPTY_PATH, null)
        try {
            rightCrop = cropBitmap(source, right)
                ?: throw IllegalStateException("Could not crop Right Area")
            leftCrop = cropBitmap(source, left)
                ?: throw IllegalStateException("Could not crop Left Area")
            // Write both new references first; do not point preferences at a partial pair.
            ImageUtils.saveJpegAtomic(rightCrop, rightFile, 95)
            ImageUtils.saveJpegAtomic(leftCrop, leftFile, 95)
            val editor = prefs.edit()
            putRect(editor, "right", right, source.width, source.height)
            putRect(editor, "left", left, source.width, source.height)
            val saved = editor
                .putInt(CaptureConfig.KEY_SAMPLE_WIDTH, source.width)
                .putInt(CaptureConfig.KEY_SAMPLE_HEIGHT, source.height)
                .putString(CaptureConfig.KEY_RIGHT_EMPTY_PATH, rightFile.absolutePath)
                .putString(CaptureConfig.KEY_LEFT_EMPTY_PATH, leftFile.absolutePath)
                .putBoolean(CaptureConfig.KEY_AREAS_SAVED, true)
                .putBoolean(CaptureConfig.KEY_EMPTY_CALIBRATION_SAVED, true)
                .commit()
            if (!saved) throw IllegalStateException("Could not save empty-reference settings")
            listOf(oldRightPath, oldLeftPath).filterNotNull().distinct().forEach { oldPath ->
                if (oldPath != rightFile.absolutePath && oldPath != leftFile.absolutePath) File(oldPath).delete()
            }
            refreshCaptureNotification()
            Toast.makeText(
                this,
                "Areas saved and Empty Calibration completed automatically. Start Auto Capture from the notification.",
                Toast.LENGTH_LONG
            ).show()
            finish()
        } catch (e: Exception) {
            rightFile.delete()
            leftFile.delete()
            Toast.makeText(this, "Could not save areas/calibration: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        } finally {
            rightCrop?.recycle()
            leftCrop?.recycle()
        }
    }

    private fun refreshCaptureNotification() {
        val running = getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE)
            .getBoolean(CaptureService.KEY_CAPTURE_RUNNING, false)
        if (!running) return
        try {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_REFRESH_NOTIFICATION))
        } catch (_: Exception) {
            // The saved preferences remain valid; notification refresh can be retried next time.
        }
    }

    private fun cropBitmap(source: Bitmap, rect: RectF): Bitmap? {
        val left = rect.left.toInt().coerceIn(0, source.width - 1)
        val top = rect.top.toInt().coerceIn(0, source.height - 1)
        val right = rect.right.toInt().coerceIn(left + 1, source.width)
        val bottom = rect.bottom.toInt().coerceIn(top + 1, source.height)
        if (right - left < 1 || bottom - top < 1) return null
        return Bitmap.createBitmap(source, left, top, right - left, bottom - top)
    }

    private fun persistAreas(right: RectF, left: RectF, width: Int, height: Int) {
        val editor = prefs.edit()
        putRect(editor, "right", right, width, height)
        putRect(editor, "left", left, width, height)
        editor.putInt(CaptureConfig.KEY_SAMPLE_WIDTH, width)
            .putInt(CaptureConfig.KEY_SAMPLE_HEIGHT, height)
            .putBoolean(CaptureConfig.KEY_AREAS_SAVED, true)
            .apply()
    }

    private fun putRect(
        editor: android.content.SharedPreferences.Editor,
        prefix: String,
        rect: RectF,
        width: Int,
        height: Int
    ) {
        editor.putFloat("${prefix}_left", rect.left / width)
            .putFloat("${prefix}_top", rect.top / height)
            .putFloat("${prefix}_right", rect.right / width)
            .putFloat("${prefix}_bottom", rect.bottom / height)
    }

    private fun loadRect(prefix: String, width: Int, height: Int): RectF? {
        if (!prefs.contains("${prefix}_left")) return null
        return RectF(
            prefs.getFloat("${prefix}_left", 0f) * width,
            prefs.getFloat("${prefix}_top", 0f) * height,
            prefs.getFloat("${prefix}_right", 0f) * width,
            prefs.getFloat("${prefix}_bottom", 0f) * height
        )
    }

    private fun areasDifferFromSaved(right: RectF, left: RectF, width: Int, height: Int): Boolean {
        fun differs(prefix: String, rect: RectF): Boolean {
            val saved = CaptureConfig.readNormalizedRect(prefs, prefix) ?: return true
            val newRect = RectF(rect.left / width, rect.top / height, rect.right / width, rect.bottom / height)
            return kotlin.math.abs(saved.left - newRect.left) > 0.0005f ||
                kotlin.math.abs(saved.top - newRect.top) > 0.0005f ||
                kotlin.math.abs(saved.right - newRect.right) > 0.0005f ||
                kotlin.math.abs(saved.bottom - newRect.bottom) > 0.0005f
        }
        return differs("right", right) || differs("left", left)
    }

    private fun clearEmptyReferences() {
        listOf(CaptureConfig.KEY_RIGHT_EMPTY_PATH, CaptureConfig.KEY_LEFT_EMPTY_PATH).forEach { key ->
            prefs.getString(key, null)?.let { File(it).delete() }
        }
        prefs.edit()
            .remove(CaptureConfig.KEY_RIGHT_EMPTY_PATH)
            .remove(CaptureConfig.KEY_LEFT_EMPTY_PATH)
            .putBoolean(CaptureConfig.KEY_EMPTY_CALIBRATION_SAVED, false)
            .apply()
    }

    private fun resetAreas() {
        clearEmptyReferences()
        listOf(
            "right_left", "right_top", "right_right", "right_bottom",
            "left_left", "left_top", "left_right", "left_bottom",
            CaptureConfig.KEY_SAMPLE_WIDTH, CaptureConfig.KEY_SAMPLE_HEIGHT, CaptureConfig.KEY_AREAS_SAVED
        ).forEach { key -> prefs.edit().remove(key).apply() }
        File(filesDir, "capture_calibration").listFiles()?.forEach { it.delete() }
        areaView.setSavedRectangles(null, null)
        Toast.makeText(this, "Saved areas and empty references reset.", Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        // The view is going away; release the large decoded sample bitmap.
        sampleBitmap?.let { if (!it.isRecycled) it.recycle() }
        sampleBitmap = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_SAMPLE_PATH = "extra_sample_path"
        const val PREFS_NAME = CaptureConfig.PREFS_NAME
    }
}
