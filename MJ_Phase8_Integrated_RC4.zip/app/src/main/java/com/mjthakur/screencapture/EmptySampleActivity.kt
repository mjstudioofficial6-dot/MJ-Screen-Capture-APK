package com.mjthakur.screencapture

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Preview and accept a full-screen sample whose selected Right/Left regions contain no card. */
class EmptySampleActivity : Activity() {
    private var sourceBitmap: Bitmap? = null
    private var rightPreview: Bitmap? = null
    private var leftPreview: Bitmap? = null
    private lateinit var samplePath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        samplePath = intent.getStringExtra(EXTRA_SAMPLE_PATH).orEmpty()
        sourceBitmap = ImageUtils.decodeFullFile(samplePath)
        val source = sourceBitmap
        if (source == null) {
            Toast.makeText(this, "Empty sample is missing or could not be opened.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val prefs = CaptureConfig.prefs(this)
        val rightRect = CaptureConfig.readNormalizedRect(prefs, "right")
        val leftRect = CaptureConfig.readNormalizedRect(prefs, "left")
        if (rightRect == null || leftRect == null) {
            Toast.makeText(this, "Save both monitored areas before applying an empty sample.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        rightPreview = ImageUtils.crop(source, scaleRect(rightRect, source))
        leftPreview = ImageUtils.crop(source, scaleRect(leftRect, source))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        root.addView(TextView(this).apply {
            text = "Empty Background Sample"
            textSize = 22f
            setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "Check both crop previews below. There must be NO card in either selected area. This sample is used only as a no-save baseline; it will never appear in History."
            textSize = 13f
            setPadding(0, dp(4), 0, dp(8))
        })
        val previews = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        previews.addView(previewColumn("RIGHT empty area", rightPreview), LinearLayout.LayoutParams(0, dp(140), 1f))
        previews.addView(previewColumn("LEFT empty area", leftPreview), LinearLayout.LayoutParams(0, dp(140), 1f))
        root.addView(previews)
        root.addView(TextView(this).apply {
            text = "Full captured sample"
            textSize = 12f
            setPadding(0, dp(4), 0, dp(2))
        })
        root.addView(ImageView(this).apply {
            setImageBitmap(source)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply {
            text = "USE AS EMPTY BACKGROUND"
            setOnClickListener { saveEmptyBaseline() }
        })
        root.addView(Button(this).apply {
            text = "DISCARD SAMPLE"
            setOnClickListener {
                File(samplePath).delete()
                finish()
            }
        })
        setContentView(root)
        InsetsHelper.applySystemBarPadding(root)
    }

    private fun previewColumn(label: String, bitmap: Bitmap?): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        addView(TextView(this@EmptySampleActivity).apply {
            text = label
            textSize = 12f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        })
        addView(ImageView(this@EmptySampleActivity).apply {
            setImageBitmap(bitmap)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = label
        }, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun saveEmptyBaseline() {
        val source = sourceBitmap ?: return
        val prefs = CaptureConfig.prefs(this)
        val rightRect = CaptureConfig.readNormalizedRect(prefs, "right")
        val leftRect = CaptureConfig.readNormalizedRect(prefs, "left")
        if (rightRect == null || leftRect == null) {
            Toast.makeText(this, "Saved areas are missing. Configure both areas again.", Toast.LENGTH_LONG).show()
            return
        }
        var rightCrop: Bitmap? = null
        var leftCrop: Bitmap? = null
        val folder = File(filesDir, "capture_calibration").apply { mkdirs() }
        val stamp = System.currentTimeMillis()
        val rightFile = File(folder, "right_empty_$stamp.jpg")
        val leftFile = File(folder, "left_empty_$stamp.jpg")
        val oldPaths = listOf(
            prefs.getString(CaptureConfig.KEY_RIGHT_EMPTY_PATH, null),
            prefs.getString(CaptureConfig.KEY_LEFT_EMPTY_PATH, null)
        ).filterNotNull().distinct()
        try {
            rightCrop = ImageUtils.crop(source, scaleRect(rightRect, source))
                ?: throw IllegalStateException("Could not crop Right empty area")
            leftCrop = ImageUtils.crop(source, scaleRect(leftRect, source))
                ?: throw IllegalStateException("Could not crop Left empty area")
            ImageUtils.saveJpegAtomic(rightCrop, rightFile, 95)
            ImageUtils.saveJpegAtomic(leftCrop, leftFile, 95)
            val saved = prefs.edit()
                .putString(CaptureConfig.KEY_RIGHT_EMPTY_PATH, rightFile.absolutePath)
                .putString(CaptureConfig.KEY_LEFT_EMPTY_PATH, leftFile.absolutePath)
                .putBoolean(CaptureConfig.KEY_AREAS_SAVED, true)
                .putBoolean(CaptureConfig.KEY_EMPTY_CALIBRATION_SAVED, true)
                .putInt(CaptureConfig.KEY_SAMPLE_WIDTH, source.width)
                .putInt(CaptureConfig.KEY_SAMPLE_HEIGHT, source.height)
                .commit()
            if (!saved) throw IllegalStateException("Could not update empty baseline settings")
            oldPaths.forEach { old ->
                if (old != rightFile.absolutePath && old != leftFile.absolutePath) File(old).delete()
            }
            val running = getSharedPreferences(CaptureService.STATE_PREFS, MODE_PRIVATE)
                .getBoolean(CaptureService.KEY_CAPTURE_RUNNING, false)
            if (running) {
                startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_REFRESH_NOTIFICATION))
            }
            Toast.makeText(this, "Empty baseline saved for both areas. Start Auto Capture from the notification to begin saving card appearances.", Toast.LENGTH_LONG).show()
            File(samplePath).delete()
            finish()
        } catch (e: Exception) {
            rightFile.delete()
            leftFile.delete()
            Toast.makeText(this, "Empty baseline failed: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
        } finally {
            rightCrop?.recycle()
            leftCrop?.recycle()
        }
    }

    private fun scaleRect(rect: RectF, source: Bitmap) = RectF(
        rect.left * source.width,
        rect.top * source.height,
        rect.right * source.width,
        rect.bottom * source.height
    )

    override fun onDestroy() {
        rightPreview?.let { if (!it.isRecycled) it.recycle() }
        leftPreview?.let { if (!it.isRecycled) it.recycle() }
        sourceBitmap?.let { if (!it.isRecycled) it.recycle() }
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object { const val EXTRA_SAMPLE_PATH = "extra_empty_sample_path" }
}
