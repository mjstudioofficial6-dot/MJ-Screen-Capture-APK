# MJ Screen Capture APK — Phase 1 starter

This is a native Kotlin + XML Android starter for the screen-capture project. It is deliberately only the Phase 1 UI/build shell. **It does not yet capture the screen, detect cards, or save screenshots.** Those features are added in separate build-and-test phases.

## Baseline
- `compileSdk = 36`
- `targetSdk = 36`
- `minSdk = 26`
- JDK 17
- Android Gradle Plugin 9.4.0
- Kotlin Android plugin 2.4.10
- Gradle 9.6.0 (pinned by GitHub Actions)
- Native Android Views/XML; no Compose, OCR, YOLO, AI model, Firebase, or runtime server

## Phase 1 build
The GitHub Actions workflow builds a debug APK when `main` is updated or when manually run from the Actions tab. It bootstraps Gradle Wrapper files if the repository does not contain them, then builds `:app:assembleDebug`. The workflow uploads the APK as an Actions artifact.

## Phase 1 pass criteria
1. GitHub Actions finishes with a green check.
2. The `MJ-Screen-Capture-debug-APK` artifact contains `app-debug.apk`.
3. The APK installs on the target Android phone and opens to the main screen.
4. Placeholder buttons show messages and do not claim to start screen capture.

## Next phases
- Phase 2: MediaProjection + foreground service + lifecycle cleanup.
- Phase 3: calibrated Left/Right rectangles and empty baseline.
- Phase 4: independent state machines and stability checks.
- Phase 5: app-private cropped-image storage + SQLite.
- Phase 6: history and image actions.
- Phase 7: 52 manual reference slots.
- Phase 8: actual-video validation.
