plugins {
    id("com.android.application")
}

android {
    namespace = "com.mjthakur.screencapture"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.mjthakur.screencapture"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0-phase1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
