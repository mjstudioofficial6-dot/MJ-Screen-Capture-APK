package com.mjthakur.screencapture

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val status = findViewById<TextView>(R.id.statusText)
        status.text = "Phase 1 ready: app shell loaded. Screen capture is not active yet."

        findViewById<Button>(R.id.startCaptureButton).setOnClickListener {
            Toast.makeText(this, "Screen capture comes in Phase 2.", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.stopCaptureButton).setOnClickListener {
            Toast.makeText(this, "No capture session is active in Phase 1.", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.captureAreaButton).setOnClickListener {
            Toast.makeText(this, "Capture Area comes in Phase 3.", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.historyButton).setOnClickListener {
            Toast.makeText(this, "History comes in Phase 6.", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.referenceButton).setOnClickListener {
            Toast.makeText(this, "Reference comes in Phase 7.", Toast.LENGTH_SHORT).show()
        }
    }
}
