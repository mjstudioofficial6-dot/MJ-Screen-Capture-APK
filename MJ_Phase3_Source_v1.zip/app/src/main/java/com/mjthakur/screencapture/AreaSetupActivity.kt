package com.mjthakur.screencapture

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class AreaSetupActivity : Activity() {
    private lateinit var areaView: AreaSelectionView
    private lateinit var instructionText: TextView

    private val prefs by lazy { getSharedPreferences(PREFS_NAME, MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_area_setup)

        areaView = findViewById(R.id.areaSelectionView)
        instructionText = findViewById(R.id.areaInstructionText)

        val path = intent.getStringExtra(EXTRA_SAMPLE_PATH)
        if (path.isNullOrBlank()) {
            Toast.makeText(this, "Capture sample is missing.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        val bitmap = BitmapFactory.decodeFile(path)
        if (bitmap == null) {
            Toast.makeText(this, "Could not open capture sample.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        areaView.setBitmap(bitmap)
        areaView.setSavedRectangles(loadRect("right", bitmap.width, bitmap.height), loadRect("left", bitmap.width, bitmap.height))
        areaView.setActiveSide(AreaSelectionView.Side.RIGHT)
        instructionText.text = "Right Area selected. Drag a rectangle over the right-side monitored area."

        findViewById<Button>(R.id.setRightButton).setOnClickListener {
            areaView.setActiveSide(AreaSelectionView.Side.RIGHT)
            instructionText.text = "Right Area selected. Drag a rectangle over the right-side monitored area."
        }

        findViewById<Button>(R.id.setLeftButton).setOnClickListener {
            areaView.setActiveSide(AreaSelectionView.Side.LEFT)
            instructionText.text = "Left Area selected. Drag a rectangle over the left-side monitored area."
        }

        findViewById<Button>(R.id.saveAreasButton).setOnClickListener {
            val right = areaView.getRightRect()
            val left = areaView.getLeftRect()
            if (right == null || left == null || right.width() < 20f || right.height() < 20f || left.width() < 20f || left.height() < 20f) {
                Toast.makeText(this, "Set both Right and Left areas first.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            saveRect("right", right, bitmap.width, bitmap.height)
            saveRect("left", left, bitmap.width, bitmap.height)
            Toast.makeText(this, "Right and Left areas saved.", Toast.LENGTH_SHORT).show()
            finish()
        }

        findViewById<Button>(R.id.resetAreasButton).setOnClickListener {
            prefs.edit().clear().apply()
            areaView.setSavedRectangles(null, null)
            Toast.makeText(this, "Saved areas reset.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveRect(prefix: String, rect: RectF, width: Int, height: Int) {
        prefs.edit()
            .putFloat("${prefix}_left", rect.left / width)
            .putFloat("${prefix}_top", rect.top / height)
            .putFloat("${prefix}_right", rect.right / width)
            .putFloat("${prefix}_bottom", rect.bottom / height)
            .apply()
    }

    private fun loadRect(prefix: String, width: Int, height: Int): RectF? {
        if (!prefs.contains("${prefix}_left")) return null
        return RectF(
            prefs.getFloat("${prefix}_left", 0f) * width,
            prefs.getFloat("${prefix}_top", 0f) * height,
            prefs.getFloat("${prefix}_right", 0f) * width,
            prefs.getFloat("${prefix}_bottom", 0f) * height
        )
    }

    companion object {
        const val EXTRA_SAMPLE_PATH = "extra_sample_path"
        const val PREFS_NAME = "capture_areas"
    }
}
