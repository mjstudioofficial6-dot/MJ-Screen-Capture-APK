package com.mjthakur.screencapture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import java.io.File
import java.io.FileOutputStream
import android.util.DisplayMetrics
import android.view.WindowManager

class CaptureService : Service() {
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    private var frameCount = 0L
    private var stopped = false
    private var latestSampleFrame: Bitmap? = null
    private val sampleLock = Any()
    private var latestSampleCounter = 0L

    private val mediaProjectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stopCapture()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startCapture(intent)
            ACTION_STOP -> stopCapture()
            ACTION_CAPTURE_SAMPLE -> requestCaptureSample()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent) {
        if (mediaProjection != null) {
            sendStatus("Screen capture is already running. Frames received: $frameCount")
            return
        }

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
        val resultData = getParcelableIntentExtra(intent, EXTRA_RESULT_DATA)
        if (resultCode != Activity.RESULT_OK || resultData == null) {
            sendStatus("Screen capture could not start: missing permission data.")
            stopSelf()
            return
        }

        stopped = false
        frameCount = 0L
        startForegroundNotification()

        try {
            val projectionManager = getSystemService(MediaProjectionManager::class.java)
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)

            val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)

            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val densityDpi = metrics.densityDpi

            captureThread = HandlerThread("MJ-CaptureThread").also { it.start() }
            captureHandler = Handler(captureThread!!.looper)
            mediaProjection!!.registerCallback(mediaProjectionCallback, captureHandler)

            imageReader = ImageReader.newInstance(
                width,
                height,
                PixelFormat.RGBA_8888,
                2
            )

            imageReader!!.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    frameCount++
                    if (frameCount == 1L || frameCount % 30L == 0L) {
                        saveLatestCalibrationFrame(image)
                    }
                    if (frameCount == 1L || frameCount % 30L == 0L) {
                        sendStatus("Screen capture running. Frames received: $frameCount")
                    }
                } finally {
                    image.close()
                }
            }, captureHandler)

            virtualDisplay = mediaProjection!!.createVirtualDisplay(
                "MJ Screen Capture",
                width,
                height,
                densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader!!.surface,
                null,
                captureHandler
            )

            sendStatus("Screen capture running. Waiting for frames...")
        } catch (e: Exception) {
            sendStatus("Screen capture failed: ${e.message}")
            stopCapture()
        }
    }

    private fun requestCaptureSample() {
        if (mediaProjection == null) {
            sendStatus("Capture Area needs an active screen-capture session.")
            return
        }
        try {
            val file = File(cacheDir, "capture_area_sample.jpg")
            synchronized(sampleLock) {
                val source = latestSampleFrame
                if (source == null) {
                    sendStatus("Capture Area sample is not ready yet. Wait for a few frames.")
                    return
                }
                FileOutputStream(file).use { output ->
                    source.compress(Bitmap.CompressFormat.JPEG, 92, output)
                }
            }
            val intent = Intent(ACTION_SAMPLE_SAVED).apply {
                setPackage(packageName)
                putExtra(EXTRA_SAMPLE_PATH, file.absolutePath)
            }
            sendBroadcast(intent)
        } catch (e: Exception) {
            sendStatus("Capture Area sample failed: ${e.message}")
        }
    }

    private fun saveLatestCalibrationFrame(image: android.media.Image) {
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val bitmapWidth = image.width + rowPadding / pixelStride
            val fullBitmap = Bitmap.createBitmap(bitmapWidth, image.height, Bitmap.Config.ARGB_8888)
            buffer.rewind()
            fullBitmap.copyPixelsFromBuffer(buffer)
            val bitmap = if (bitmapWidth == image.width) {
                fullBitmap
            } else {
                Bitmap.createBitmap(fullBitmap, 0, 0, image.width, image.height)
                    .also { fullBitmap.recycle() }
            }
            synchronized(sampleLock) {
                latestSampleFrame?.recycle()
                latestSampleFrame = bitmap
            }
            latestSampleCounter = frameCount
        } catch (_: Exception) {
            // Keep the previous calibration frame if this frame cannot be converted.
        }
    }

    private fun startForegroundNotification() {
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("MJ Screen Capture")
            .setContentText("Screen capture is running")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun stopCapture() {
        if (stopped) return
        stopped = true

        virtualDisplay?.release()
        virtualDisplay = null

        imageReader?.setOnImageAvailableListener(null, null)
        imageReader?.close()
        imageReader = null

        mediaProjection?.let { projection ->
            try {
                projection.unregisterCallback(mediaProjectionCallback)
            } catch (_: Exception) {
                // Ignore cleanup errors.
            }
            projection.stop()
        }
        mediaProjection = null

        captureThread?.quitSafely()
        captureThread = null
        captureHandler = null
        frameCount = 0L
        synchronized(sampleLock) {
            latestSampleFrame?.recycle()
            latestSampleFrame = null
        }

        sendStatus("Screen capture stopped.")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun sendStatus(message: String) {
        val intent = Intent(ACTION_STATUS).apply {
            setPackage(packageName)
            putExtra(EXTRA_STATUS, message)
        }
        sendBroadcast(intent)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Screen Capture",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Screen capture service status"
        }
        manager.createNotificationChannel(channel)
    }

    @Suppress("DEPRECATION")
    private fun getParcelableIntentExtra(intent: Intent, key: String): Intent? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(key, Intent::class.java)
        } else {
            intent.getParcelableExtra(key)
        }
    }

    override fun onDestroy() {
        if (!stopped) stopCapture()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.mjthakur.screencapture.action.START"
        const val ACTION_STOP = "com.mjthakur.screencapture.action.STOP"
        const val ACTION_CAPTURE_SAMPLE = "com.mjthakur.screencapture.action.CAPTURE_SAMPLE"
        const val ACTION_STATUS = "com.mjthakur.screencapture.action.STATUS"
        const val ACTION_SAMPLE_SAVED = "com.mjthakur.screencapture.action.SAMPLE_SAVED"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_STATUS = "extra_status"
        const val EXTRA_SAMPLE_PATH = "extra_sample_path"

        private const val CHANNEL_ID = "mj_screen_capture"
        private const val NOTIFICATION_ID = 1001
    }
}
