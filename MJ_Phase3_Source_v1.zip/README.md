# MJ Screen Capture APK — Phase 2

## Baseline
Phase 1 was completed and tested: the APK built, installed and launched on the target Android phone. Phase 2 keeps that baseline and adds only the actual screen-capture pipeline.

## Phase 2 Goal
Verify a real MediaProjection session from the phone screen:

START CAPTURE → Android consent → foreground service → MediaProjection → VirtualDisplay → ImageReader → receive frames → STOP CAPTURE → clean shutdown.

## Included
- MediaProjection permission flow
- Foreground service with `mediaProjection` type
- VirtualDisplay
- ImageReader frame reception
- Frame counter/status
- MediaProjection stop callback
- Proper VirtualDisplay/ImageReader/thread/service cleanup
- Fresh consent for each capture session

## Not included yet
- Automatic card detection
- Right/Left area detection
- Automatic screenshot/crop saving
- Duplicate suppression
- Calibration
- SQLite/history
- OCR
- YOLO
- Card-name/suit recognition
- Cloud AI/API

## Final Product Requirement Preserved
The final APK will automatically capture one crop when a card appears in a monitored fixed Right/Left area, avoid duplicates while it remains visible, re-arm after the area becomes empty, and save in actual appearance order. Card identity will not be recognized.

## Important implementation check
The Android consent result code is `Activity.RESULT_OK` (`-1`), so validation must compare equality with `Activity.RESULT_OK`; it must not reject every negative result code. This correction is included in this source archive.

## Phase 2 Success Test
1. Install APK.
2. Tap START CAPTURE.
3. Grant Android screen-capture permission.
4. Confirm status changes to capture running and frame count increases.
5. Tap STOP CAPTURE.
6. Confirm capture stops without a crash.
7. Start a second capture session and confirm Android asks for consent again and frames are received.

Do not start Phase 3 until all Phase 2 tests pass on the target phone.

## Phase 3 — Capture Area Setup

Phase 3 preserves the successful Phase 2 MediaProjection capture, frame counter, permission flow, and Stop Capture behavior.

Added only for Phase 3:
- Capture Area uses the latest calibration frame received by the active MediaProjection session. This allows the user to switch to the video source and then return to the app before opening Capture Area; the capture service continues receiving frames in the background.
- The selected frame is saved privately as a temporary calibration sample.
- AreaSetupActivity displays the frozen sample.
- User can set Right Area and Left Area by dragging rectangles.
- Rectangles are stored as normalized coordinates (0.0–1.0) so they are not tied to one absolute pixel size.
- Save Areas and Reset Areas are included.
- No card recognition, OCR, YOLO, automatic detection, automatic screenshot saving, SQLite, or History logic is added in Phase 3.
